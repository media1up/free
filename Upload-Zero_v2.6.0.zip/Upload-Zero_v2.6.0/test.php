<?php 
  echo $settings['plans'][0]['max_size'];
    



?>






<br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br>