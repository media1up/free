<?php
ob_start();
session_start();
include 'page/classes/database.php';
include 'page/functions/gFunction.php';
include 'page/classes/class.user.php';
include 'page/classes/class.page.php';


ini_set('display-errors','off');

if(!file_exists("page/classes/config.php")){
    header('location: install/page/start');
    exit();
}

if(!isset($_SESSION['app_2']['info'])) include 'page/info_site.php';
include 'res/lang.php';
$lang = $_SESSION['app_2']['lang'];
$settings = $_SESSION['app_2'];




$theme = "res/themes/".$settings['theme'];
if(isset($_GET['theme'])) {
    $theme = "res/themes/".$_GET['theme'];
    $_SESSION['app_2']['theme'] = $_GET['theme'];
}

include $theme.'/html/function.php';
include $theme.'/html/header.php';

$p = new Pages();
$p->setSettings();

    if($_GET['p'] == "index.php" || $_GET['p'] == "") include $theme.'/components/home.php';
elseif($_GET['p'] == "home") include $theme.'/components/home.php';
elseif($_GET['p'] == "payout-rates") include $theme.'/components/payout-rates.php';
elseif($_GET['p'] == "proof") include $theme.'/components/proof-of-payments.php';
elseif($_GET['p'] == "upload") include $theme.'/components/upload.php';
elseif($_GET['p'] == "404") include $theme.'/components/404.php';
elseif($_GET['p'] == "login") Redirect("page/login");
elseif($_GET['p'] == "sign-up") Redirect("page/register");
elseif($_GET['p'] == "forgot-password") Redirect("page/forgot-password");
elseif($_GET['p'] == "admin") Redirect("page/admin/");
elseif($_GET['p'] == "terms") include $theme.'/components/terms-of-use.php';
elseif($_GET['p'] == "contact-us") include $theme.'/components/contact-us.php';
elseif($_GET['p'] == "privacy") include $theme.'/components/privacy-policy.php';
elseif($_GET['p'] == "terms") include $theme.'/components/terms-of-use.php';
elseif($_GET['p'] == "dmca") include $theme.'/components/dmca.php';
elseif($_GET['p'] == "copyright") include $theme.'/components/copyright.php';
elseif($_GET['p'] == "report") include $theme.'/components/report.php';
elseif($_GET['p'] == "test") include 'test.php';
elseif($_GET['p'] == "dashboard") Redirect("page/member/dashboard");
else include $theme.'/components/download-file.php';




include $theme.'/html/footer.php';
include $theme.'/html/scripts.php';

?>