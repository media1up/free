
        </center>
    <!-- Essential javascripts for application to work-->
    <script src="../../page/includes/js/jquery-3.2.1.min.js"></script>
    <script src="../../page/includes/js/popper.min.js"></script>
    <script src="../../page/includes/js/bootstrap.min.js"></script>
    <script src="../../page/includes/s/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="../page/includes/js/plugins/pace.min.js"></script>
   
    
  </body>
</html>