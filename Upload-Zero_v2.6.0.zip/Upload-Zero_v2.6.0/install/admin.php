<div class="col-md-3">
            <div class="tile" style="margin-top:30%">
            <h3 class="tile-title">Step3 : Create Admin User</h3>
            <div class="tile-body">
                <form method="post">
                    <div class="form-group">
                        <input class="form-control" type="text" name="usernameP" placeholder="[Codester/Ayelscript] Username" >
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" name="username" placeholder="Username" >
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="pass1" placeholder="Password">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="pass2" placeholder="Re-Password">
                    </div>

                    <div class="tile-footer">
                        <button class="btn btn-info" style="width:100%" type="submit" name="admin" >Submit</button>
                    </div>
                    <hr>
                    <p class="footer-text text-center">AyelScripts © <?php echo date("Y")?> . All rights reserved.</p>
                </form>
            </div>
            
            </div>
        </div>
        