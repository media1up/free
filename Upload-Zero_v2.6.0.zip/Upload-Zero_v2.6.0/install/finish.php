
        <div class="col-md-3">
            <div class="tile" style="margin-top:30%">
            <h3 class="tile-title">Installation Successful</h3>
            <div class="tile-body" >
                <form>
                <div class="tile-footer">
                    <a href="../../page/login.php" target="_blank" class="btn btn-info" style="width:100%">User Dashboard</a>
                    <br>
                    <br>

                    <a href="../../page/admin/" target="_blank" class="btn btn-warning" style="width:100%">Admin Dashboard</a>
                </div>
                <hr>
                <p class="footer-text text-center">AyelScripts © <?php echo date("Y")?> . All rights reserved.</p>
                </form>
            </div>
            
            </div>
        </div>
        