<div class="col-md-3">
            <div class="tile" style="margin-top:30%">
            <h3 class="tile-title">Step1 : Database</h3>
            <div class="tile-body">
                <form method="post">
                    <div class="form-group">
                        <input class="form-control" type="text" name="host" placeholder="Database Host" >
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" name="user" placeholder="Database Username" >
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="pass" placeholder="Database Password">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" name="name" placeholder="Database Name">
                    </div>
                    <div class="tile-footer">
                        <button class="btn btn-info" style="width:100%" type="submit" name="database" >Submit</button>
                    </div>
                    <hr>
                        <p class="footer-text text-center">AyelScripts © <?php echo date("Y")?> . All rights reserved.</p>
                </form>
            </div>
            
            </div>
        </div>
        