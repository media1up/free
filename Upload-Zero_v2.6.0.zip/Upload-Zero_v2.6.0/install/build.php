<div class="col-md-3">
            <div class="tile" style="margin-top:30%">
            <h3 class="tile-title">Step2 : Build Database</h3>
            <div class="tile-body">
                <form method="post">
                    <div class="tile-footer">
                         <button class="btn btn-info" style="width:100%" type="submit" name="build" >build</button>
                    </div>
                    <hr>
                    <p class="footer-text text-center">AyelScripts © <?php echo date("Y")?> . All rights reserved.</p>
            
                </form>
            </div>
            
            </div>
        </div>
        