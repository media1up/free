<?php
    function isLogged(){
        if(!isset($_SESSION['app_2']['username'])){
            echo '
                <li class="nav-item"><a class="nav-link js-scroll-trigger" href="login">'.$_SESSION['app_2']['lang']['login'].'</a></li>
                <li class="nav-item"><a class="nav-link js-scroll-trigger" href="sign-up">'.$_SESSION['app_2']['lang']['sign_up'].'</a></li>
            ';
        }
        else{
            echo '<li class="nav-item"><a class="nav-link js-scroll-trigger" href="dashboard">'.$_SESSION['app_2']['lang']['dashboard'].'</a></li>';
        }
    }

    function includeFlag(){
        if($_GET['p'] == "payout-rates"){
            echo '<link rel="stylesheet" href="//cdn.rawgit.com/lipis/flag-icon-css/2.8.0/css/flag-icon.min.css"/>';
        }
    }

    function UploadCss(){
        GLOBAL $theme;
        if($_GET['p'] == "upload") {
            echo '<link rel="stylesheet" href="'.$theme.'/files/css/dropify.min.css" type="text/css">';
            include $theme.'/html/upload.php';
        }
    }

    function Logo(){
        if($_SESSION['app_2']['logo_active'] == "yes") echo "<img src='".$_SESSION['app_2']['logo']."' height='30'>"; 
        else echo $_SESSION['app_2']['SiteName'];
    }

?>