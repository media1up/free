  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo $theme?>/files/vendor/jquery/jquery.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="<?php echo $theme?>/files/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="<?php echo $theme?>/files/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  
  <!-- Contact form JavaScript -->
  <script src="<?php echo $theme?>/files/js/jqBootstrapValidation.js"></script>
  <script src="<?php echo $theme?>/files/js/contact_me.js"></script>
  <!-- Custom scripts for this template -->
  <script src="<?php echo $theme?>/files/js/agency.min.js"></script>

  <script src="<?php echo $theme?>/files/js/dropify.min.js"></script>
<script>
      $(document).ready(function(){
          // Basic
          $('.dropify').dropify();

          // Translated
          $('.dropify-fr').dropify({
              messages: {
                  default: 'Glissez-déposez un fichier ici ou cliquez',
                  replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                  remove:  'Supprimer',
                  error:   'Désolé, le fichier trop volumineux'
              }
          });

          // Used events
          var drEvent = $('#input-file-events').dropify();

          drEvent.on('dropify.beforeClear', function(event, element){
              return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
          });

          drEvent.on('dropify.afterClear', function(event, element){
              alert('File deleted');
          });

          drEvent.on('dropify.errors', function(event, element){
              console.log('Has Errors');
          });

          var drDestroy = $('#input-file-to-destroy').dropify();
          drDestroy = drDestroy.data('dropify')
          $('#toggleDropify').on('click', function(e){
              e.preventDefault();
              if (drDestroy.isDropified()) {
                  drDestroy.destroy();
              } else {
                  drDestroy.init();
              }
          })
      });
</script>
<script>
    function _(el) {
    return document.getElementById(el);
    }

    function uploadFile() {
    _("info_upload").style.display="inline-block";
    var file = _("input-file-max-fs").files[0];
    var formdata = new FormData();
    formdata.append("input-file-max-fs", file);
    var ajax = new XMLHttpRequest();
    ajax.upload.addEventListener("progress", progressHandler, false);
    ajax.addEventListener("load", completeHandler, false);
    ajax.addEventListener("error", errorHandler, false);
    ajax.addEventListener("abort", abortHandler, false);
    ajax.open("POST", "page/ajax.php");
    ajax.send(formdata);
    }

    function uploadFile_URL() {
    _("info_upload").style.display="inline-block";
    var file = _("input_file_url").value;
    var formdata = new FormData();
    formdata.append("input_file_url", file);
    var ajax = new XMLHttpRequest();
    ajax.upload.addEventListener("progress", progressHandler, false);
    ajax.addEventListener("load", completeHandler, false);
    ajax.addEventListener("error", errorHandler, false);
    ajax.addEventListener("abort", abortHandler, false);
    ajax.open("POST", "page/ajax.php");
    ajax.send(formdata);
    }

    function progressHandler(event) {
    var percent = (event.loaded / event.total) * 100;
    _("progressBar").style.width = Math.round(percent) + '%';
    _("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
    }

    function completeHandler(event) {
    _("status_final").innerHTML = event.target.responseText;
    _("progressBar").value = 0;
    _("info_upload").style.display="none";
    }

    function errorHandler(event) {
    _("status").innerHTML = "Upload Failed";
    _("info_upload").style.display="none";
    }

    function abortHandler(event) {
    _("status").innerHTML = "Upload Aborted";
    _("info_upload").style.display="none";
    }
    function changeUpload(id){
    _("upload_1").style.display="none";
    _("upload_2").style.display="none";
    _("btn_1").style.display="none";
    _("btn_2").style.display="none";

    _("upload_"+id).style.display="inline";
    _("btn_"+id).style.display="inline";
    }

    
</script>



</body>
</noscript>
<div style="text-align: center;"><div style="position:relative; top:0; margin-right:auto;margin-left:auto; z-files:99999">

</div></div>
</html>