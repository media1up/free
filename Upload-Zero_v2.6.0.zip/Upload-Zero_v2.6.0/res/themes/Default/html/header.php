<?php
    if(!file_exists("page/classes/config.php")){
        //('location: install/page/start');
        //exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="<?php echo $settings["Des"]?>">
<meta name="keywords" content="<?php echo $settings["Keywords"]?>">
<meta name="og:title" content="<?php echo $settings["SiteMetaTitle"]?>">
<meta name="og:description" content="<?php echo $settings["Des"]?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="author" content="ayelscripts.com">
  
<link href="<?php echo $settings["favicon"]?>" type="image/x-icon" rel="icon" />

<title><?php echo $settings['SiteName']." | ". getTitleHome($_GET['p'])?>  </title>

<?php includeFlag();?>

<!-- Bootstrap core CSS -->
<link href="<?php echo $theme?>/files/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
<link href="<?php echo $theme?>/files/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

<!-- Custom styles for this template -->
<link rel="stylesheet" href="<?php echo $theme?>/files/css/agency.min.php" type="text/css">
<link rel="stylesheet"  href="<?php echo $theme?>/files/css/component.php" type="text/css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php UploadCss()?>
</head>
