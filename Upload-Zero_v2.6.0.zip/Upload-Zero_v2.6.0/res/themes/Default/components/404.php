  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
    <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="home"><?php Logo(); ?></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">


        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="home"><?php echo $lang['home']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="payout-rates"><?php echo $lang['payout_rates']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="proof"><?php echo $lang['proof_of_payments']?></a>
          </li>
          
          <?php isLogged();?>
            
          
        </ul>
      </div>
    </div>
  </nav>
    <!-- Header -->
    <header class="masthead">
        <div class="container">
        <div class="intro-text" style="padding-top:150px;padding-bottom:100px">
            <div class="intro-lead-in"><?php echo $lang['file404_1']?></div>
        </div>
        </div>
    </header>
    <br><br>

    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-offset-5" style="border:1px solid black;margin-top:200px;padding-bottom:50px;width:500px;margin:auto;background-color:#F8F9FA">
                <br><br>
                
                    <div class="text-wrap">


                        <h5 style="color: #a94442;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo $lang['file404_1']?></h5>

                        <p style="margin: 0 0 5px;"><?php echo $lang['file404_2']?></p>
                        <p style="margin: 0;"><?php echo $lang['file404_3']?></p>

                        <ul>
                            <li><i class="fa fa-long-arrow-right"></i><?php echo $lang['file404_4']?></li>
                            <li><i class="fa fa-long-arrow-right"></i><?php echo $lang['file404_5']?></li>
                            <li><i class="fa fa-long-arrow-right"></i><?php echo $lang['file404_6']?></li>
                        </ul>

                    </div>
                
            </div>
        </div>
    </div>

    <div style="margin-bottom:100px"></div>


<!-- Footer -->
