

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="home"><?php Logo(); ?></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#start"><?php echo $lang['start']?></a></li>
          <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#payout"><?php echo $lang['payout_rates']?></a></li>
          <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#proof"><?php echo $lang['proof_of_payments']?></a></li>
          <?php isLogged();?>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Header -->
  <header class="masthead">
    <div class="container">
      <div class="intro-text">
        <div class="intro-lead-in"><?php echo $lang['home_1']?></div>
        <div class="intro-heading text-uppercase"><?php echo $lang['home_2']?></div>
        
        <div class="page-error tile">

            <br>
            <input class="btn btn-primary btn-xl" type="button" value="<?php echo $lang['home_3']?>" onclick="window.location.href='upload'">
            <br>
            
        </div>
        
    
        
      </div>
    </div>
  </header>

  <!-- Start -->
  <section id="start">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h3 class="section-heading text-uppercase"><?php echo $lang['home_4']?></h3>
          <br>
        </div>
      </div>
      <div class="row text-center">
        <div class="col-md-4">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-upload fa-stack-1x fa-inverse"></i>
          </span>
          <h5 class="service-heading" style="margin-top:20px"><?php echo $lang['home_5']?> <?php echo $settings['SiteName']?>?</h5>
          <p class="text-muted"><?php echo $settings['SiteName']?> <?php echo $lang['home_7']?></p>

          
        </div>
        <div class="col-md-4">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-users fa-stack-1x fa-inverse"></i>
          </span>
          <h5 class="service-heading" style="margin-top:20px"><?php echo $lang['home_6']?></h5>
          <p class="text-muted"><?php echo $lang['home_8']?></p>

          
        </div>
        <div class="col-md-4">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-envelope fa-stack-1x fa-inverse"></i>
          </span>
          <h5 class="service-heading" style="margin-top:20px"><?php echo $lang['home_9']?></h5>
          <p class="text-muted"><?php echo $lang['home_10']?></p>
        </div>

        
      </div>
    </div>
  </section>

  <section class="bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h3 class="section-heading text-uppercase"><?php echo $lang['home_11']?></h3>
          <br>
        </div>
      </div>
      <div class="row text-center">
        <div class="col-md-3">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-user fa-stack-1x fa-inverse"></i>
          </span>
          <h5 class="service-heading" style="margin-top:20px"><?php echo $lang['home_12']?></h5>
          <p class="text-muted"><?php echo $lang['home_13']?></p>

          
        </div>
        <div class="col-md-3">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-upload fa-stack-1x fa-inverse"></i>
          </span>
          <h5 class="service-heading" style="margin-top:20px"><?php echo $lang['home_14']?></h5>
          <p class="text-muted"><?php echo $lang['home_15']?></p>

          
        </div>
        <div class="col-md-3">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-dollar-sign fa-stack-1x fa-inverse"></i>
          </span>
          <h5 class="service-heading" style="margin-top:20px"><?php echo $lang['home_16']?></h5>
          <p class="text-muted"> <?php echo $lang['home_17']?></p>
        </div>

        <div class="col-md-3">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-money-bill-alt fa-stack-1x fa-inverse"></i>
          </span>
          <h5 class="service-heading" style="margin-top:20px"><?php echo $lang['home_18']?></h5>
          <p class="text-muted"><?php echo $lang['home_19']?></p>
        </div>
      </div>
    </div>
  </section>

  <!-- payout -->
  <section id="payout">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h3 class="section-heading text-uppercase"><?php echo $lang['home_20']?></h3>
          <p><?php echo $settings['SiteName'] ?> <?php echo $lang['home_21']?></p>
          <br>
        </div>
      </div>
      
      <div class="clearfix"></div>
        <div class="col-lg-12 text-center">
          
            <button class="btn btn-primary btn-xl text-uppercase" onclick="window.location.href='payout-rates'"><?php echo $lang['payout_rates']?></button>
        </div>
      
    </div>
  </section>

   <!-- proof -->
   <section id="proof" class="bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase"><?php echo $lang['proof_of_payments']?></h2>
          <br>
        </div>
      </div>
      <div class="clearfix"></div>
        <div class="col-lg-12 text-center">
            <button class="btn btn-primary btn-xl text-uppercase" onclick="window.location.href='proof'"><?php echo $lang['proof_of_payments']?></button>
        </div>
    </div>
  </section>

<!-- Statistics -->
  <section >
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase"><?php echo $lang['home_22']?></h2>
          <h3 class="section-subheading text-muted"><?php echo $lang['home_23']?></h3>
        </div>  
      </div>  


      <div class="row text-center">
        <div class="col-md-3">
            <span class="fa-stack fa-4x">
              <i class="fas fa-circle fa-stack-2x text-primary"></i>
              <i class="fas fa-file fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading" style="margin-top:20px"><?php echo $settings['tFiles'];?></h4>
            <p class="text-muted"><?php echo $lang['home_24']?></p>
        </div>

        <div class="col-md-3">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-download fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading" style="margin-top:20px"><?php echo $settings['tDownloads'];?></h4>
          <p class="text-muted"><?php echo $lang['home_25']?></p>
        </div>

        <div class="col-md-3">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-users fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading" style="margin-top:20px"><?php echo $settings['tUsers'];?></h4>
          <p class="text-muted"><?php echo $lang['home_26']?></p>
        </div>

        <div class="col-md-3">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-dollar-sign fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading" style="margin-top:20px"><?php echo $settings['currency'].round($settings['tPaid'], 2);?></h4>
          <p class="text-muted"><?php echo $lang['home_27']?></p>
        </div>
        
        

      
      </div>
      
    </div>
  </section>

   <!-- Contact -->
   <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase"><?php echo $lang['home_28']?></h2>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <form method="post">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group" onclick="funtz()">
                  <input class="form-control" id="name" type="text" name="name" placeholder="Your Name *" required="required" data-validation-required-message="Please enter your name.">
                  <p class="help-block text-danger"></p>
                </div>
                <div class="form-group">
                  <input class="form-control" id="email" type="email" name="email" placeholder="Your Email *" required="required" data-validation-required-message="Please enter your email address.">
                  <p class="help-block text-danger"></p>
                </div>
                <div class="form-group">
                  <input class="form-control" id="phone" type="text" name="subject" placeholder="Your subject *" required="required" data-validation-required-message="Please enter subject.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <textarea class="form-control" id="message"  name="message" placeholder="Your Message *" required="required" data-validation-required-message="Please enter a message."></textarea>
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="clearfix"></div>
              <div class="col-lg-12 text-center">
                <?php if(isset($_POST['submit'])){
                          $page = new Pages();
                          $page->sendMsg($_POST['name'],$_POST['email'],$_POST['subject'],$_POST['message']);
                      }
                ?>
                <button class="btn btn-primary btn-xl text-uppercase" type="submit" name="submit"><?php echo $lang['home_29']?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
  

  

  <!-- Footer -->
