  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
    <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="home"><?php Logo(); ?></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">


          <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="home"><?php echo $lang['home']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="payout-rates"><?php echo $lang['payout_rates']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="proof"><?php echo $lang['proof_of_payments']?></a>
          </li>
          
          <?php isLogged();?>
            
          
        </ul>
      </div>
    </div>
  </nav>
    <!-- Header -->
    <header class="masthead">
        <div class="container">
        <div class="intro-text" style="padding-top:150px;padding-bottom:100px">
            <div class="intro-lead-in"><?php echo $lang['home_30']?></div>
        </div>
        </div>
    </header>


    <div class="container">
        <div class="row" style="margin-bottom: 2rem;">
            <div class="col-lg-12">
                <br><br>
                <div class="bs-component">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade active show" id="visit">
                            <table class="table table-hover">
                                <thead>
                                    <tr>              
                                        <th style="width:50%"><?php echo $lang['home_31']?></th>
                                        <th style="text-align:center"> <?php echo $lang['home_32']?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $p->showRates_file();?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- Footer -->
