  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
    <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="home"><?php Logo(); ?></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="home"><?php echo $lang['home']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="payout-rates"><?php echo $lang['payout_rates']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="proof"><?php echo $lang['proof_of_payments']?></a>
          </li>
          
          <?php isLogged();?>
            
          
        </ul>
      </div>
    </div>
  </nav>
    <!-- Header -->
    <header class="masthead">
        <div class="container">
        <div class="intro-text" style="padding-top:150px;padding-bottom:100px">
          <div class="intro-lead-in"><?php echo $lang['proof_of_payments']?></div>
          <span style="font-size:20px"><?php echo $lang['home_27']?> : <?php echo $settings['currency'].round($settings['tPaid'],2);?><span>
        </div>
        </div>
    </header>

    <br>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <div class="table-responsive">

                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo $lang['home_33']?></th>
                                    <th><?php echo $lang['home_34']?></th>
                                    <th><?php echo $lang['home_35']?></th>
                                    <th><?php echo $lang['home_36']?></th>
                                    <th><?php echo $lang['home_37']?></th>
                                    <th><?php echo $lang['home_38']?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $p->showAllPayment();?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>


<!-- Footer -->
