
<body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
    <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="home"><?php Logo(); ?></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">


        <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="home">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="payout-rates">Payout Rates</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="proof">Proof of payments</a>
          </li>
          <?php isLogged();?>
          
        </ul>
      </div>
    </div>
  </nav>


  <!-- Header -->
  <header class="masthead">
    <div class="container">
      <div class="intro-text" style="padding:100px 0px 30px 0px">
        <div class="intro-lead-in"><?php echo $lang['home_14']?></div>
      </div>
    </div>
  </header>

  <div class="container">
    <form method="post" enctype="multipart/form-data">
      <div class="intro-text" style="padding:0px 0px 40px 0px">
        
      </div>

        <center>
        <table>
        <tr>
          <td><input style="padding:10px" class="btn btn-primary btn-xl" type="button" value="<?php echo $lang['file_upload']?>" onclick="changeUpload('1')"></td>
          <td><input style="padding:10px" class="btn btn-primary btn-xl" type="button" value="<?php echo $lang['remote_url_upload']?>" onclick="changeUpload('2')"></td>
        </tr>
        </table>
        </center>

      <br>

      <div class="row">
          <div class="col-md-12">
                <div class="">
                    <div style="" id="upload_1">
                        <div class="row">
                            <div class="col-sm-12">
                                <input type="file" id="input-file-max-fs" name="file1" class="dropify" data-max-file-size="<?php echo $_SESSION['app_2']['plans'][0]['max_size']?>M" />
                            </div>
                        </div>
                    </div>

                    <div style="display:none" id="upload_2">
                        <div class="row">
                            <div class="col-sm-12">
                                <textarea class="form-control" id="input_file_url" name="input_file_url" rows="8" style="height:200px;"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            
          </div>
          
      </div>
    <br>
      <span id="status_final" ></span>

      <div id="info_upload" style="width:100%;display:none">
        <div style="width:100%">
            <div class="bs-component">
                <div class="progress mb-2" style="height:20px;">
                    <div class="progress-bar progress-bar-striped progress-bar-animated active" id="progressBar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:0%;height:20px;">
                        <span id="status"></span>
                    </div>
                </div>
            </div>
        </div>
      </div>

      
      <center>
        <br>
        <input style="padding:10px" class="btn btn-primary btn-xl" id="btn_1" type="button" value="<?php echo $lang['upload']?>" onclick="uploadFile()">
        <input class="btn btn-primary btn-xl" id="btn_2" type="button" value="<?php echo $lang['upload']?>" onclick="uploadFile_URL()" style="display:none;padding:10px">
        <br>
        <h6 style="padding-top:10px;padding-bottom: 60px;">(<?php echo $lang['Max_Upload_size']?>: <?php echo $_SESSION['app_2']['plans'][0]['max_size'] . " MB"?> )</h6>
      </center>
    </form>
  </div>



  
  
  <div style="margin-bottom:100px"></div>

  <!-- Header -->
    <header class="masthead">
      <div class="container">
        <div class="intro-text" style="padding:50px 0px 0px 0px">
          
        </div>
      </div>
    </header>
