<body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
    <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="home"><?php Logo(); ?></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">


        <li class="nav-item">
        
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="home"><?php echo $lang['home']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="payout-rates"><?php echo $lang['payout_rates']?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="proof"><?php echo $lang['proof_of_payments']?></a>
          </li>
          <?php isLogged();?>
          
        </ul>
      </div>
    </div>
  </nav>

  <!-- Header -->
  <header class="masthead">
    <div class="container">
      <div class="intro-text" style="padding-top:150px;padding-bottom:100px">
        <div class="intro-lead-in"><?php echo $lang['report_abuse']?></div>
      </div>
    </div>
  </header>
  
    <br><br><br>

    <div style="margin:auto;width:800px">
    <div class="row">
    <div class="col-md-12 col-md-offset-2">
    <div class="page-wrap">
    <?php
        $file_name = $p->getFileName($_GET['file']);
        if(isset($_POST['send'])) $p->sendReportAbuse($file_name,$_POST['name'],$_POST['email'],$_POST['reason'],$_POST['info']);
        
    ?>
    
    <form method="post">
        <table class="table">
            <tbody>
            <tr><td align="right"><b>Filename</b></td><td><?php echo $file_name;?></td></tr>
            <tr><td align="right"><b>Your Name</b></td><td><input type="text" class="form-control" name="name"></td></tr>
            <tr><td align="right"><b>Your E-mail</b></td><td><input type="email" class="form-control" name="email"></td></tr>
            <tr><td align="right"><b>Reason</b></td><td>
                <select name="reason" class="form-control">
                    <option value="Content copyright restriction">Content copyright restriction</option>
                    <option value="File corrupt">File corrupt</option>
                    <option value="Virus / Malware">Virus / Malware</option>
                    <option value="Other">Other</option>
                </select>
            </td></tr>
            <tr><td align="right"><b>Information</b></td><td><textarea name="info" class="form-control" rows="5" cols="20"></textarea></td></tr>
            <tr><td align="center"></td><td>
            <div class="g-recaptcha" data-sitekey="<?php echo $settings['CaptchaSiteKey']?>"></div>
            </td></tr>
            

            <tr><td align="center"></td><td>
            <input type="submit" class="btn btn-primary" name="send" value="Send File Report">
            </td></tr>
            
            </tbody>
        </table>
    
    </form>
    </div>
    </div>
    </div>
    </div>

    <br><br><br>

    


    



<!-- Footer -->
