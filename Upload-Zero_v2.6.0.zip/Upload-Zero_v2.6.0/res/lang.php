<?php

// home page - header
$_SESSION['app_2']['lang']['home'] = "HOME";
$_SESSION['app_2']['lang']['start'] = "Start";
$_SESSION['app_2']['lang']['payout_rates'] = "PAYOUT RATES";
$_SESSION['app_2']['lang']['proof_of_payments'] = "PROOF OF PAYMENTS";
$_SESSION['app_2']['lang']['login'] = "LOGIN";
$_SESSION['app_2']['lang']['sign_up'] = "SIGN UP";
$_SESSION['app_2']['lang']['dashboard'] = "Dashboard";
//Pages
$_SESSION['app_2']['lang']['dmca'] = "DMCA";
$_SESSION['app_2']['lang']['privacy_policy'] = "PRIVACY POLICY";
$_SESSION['app_2']['lang']['trems_of_use'] = "TERMS OF USE";
$_SESSION['app_2']['lang']['copyright'] = "Copyright Policy";
$_SESSION['app_2']['lang']['report_abuse'] = "REPORT ABUSE";
//links
$_SESSION['app_2']['lang']['link_1'] = "Privacy Policy";
$_SESSION['app_2']['lang']['link_2'] = "Terms of Use";
$_SESSION['app_2']['lang']['link_3'] = "DMCA";
$_SESSION['app_2']['lang']['link_4'] = "Copyright Policy";

// home page 
$_SESSION['app_2']['lang']['home_1'] = "UPLOAD FILES";
$_SESSION['app_2']['lang']['home_2'] = "TO EARN MONEY";
$_SESSION['app_2']['lang']['home_3'] = "START UPLOAD NOW";
$_SESSION['app_2']['lang']['home_4'] = "WHAT MAKES YOU CHOOSE US?";
$_SESSION['app_2']['lang']['home_5'] = "What is";
$_SESSION['app_2']['lang']['home_6'] = "Earnings Referrals";
$_SESSION['app_2']['lang']['home_7'] = "is a free and secure system to upload files and make money";
$_SESSION['app_2']['lang']['home_8'] = "You can earn up to ".$_SESSION['app_2']['ReferralRate']."% by referring your friends to the site through your referral link.";
$_SESSION['app_2']['lang']['home_9'] = "Support";
$_SESSION['app_2']['lang']['home_10'] = "Quick support and ready to answer your questions 24/7.";
$_SESSION['app_2']['lang']['home_11'] = "HOW YOU START?";
$_SESSION['app_2']['lang']['home_12'] = "CREATE AN ACCOUNT";
$_SESSION['app_2']['lang']['home_13'] = "Easily create your free account";
$_SESSION['app_2']['lang']['home_14'] = "UPLOAD FILES";
$_SESSION['app_2']['lang']['home_15'] = "Start uploading files and don't forget to share them with your friends.";
$_SESSION['app_2']['lang']['home_16'] = "EARN MONEY";
$_SESSION['app_2']['lang']['home_17'] = "Make money for all of these Downloads";
$_SESSION['app_2']['lang']['home_18'] = "GET YOU PAID";
$_SESSION['app_2']['lang']['home_19'] = "High CPM Rates With Global Coverage .. With timed payments";
$_SESSION['app_2']['lang']['home_20'] = "PAY PER DOWNLOAD (PPD)";
$_SESSION['app_2']['lang']['home_21'] = "PPD program is the simplest program allows you to earn every time your files are downloaded";
$_SESSION['app_2']['lang']['home_22'] = "FAST GROWING";
$_SESSION['app_2']['lang']['home_23'] = "Numbers Speak For Themselves";
$_SESSION['app_2']['lang']['home_24'] = "Total Files";
$_SESSION['app_2']['lang']['home_25'] = "Total Downloads";
$_SESSION['app_2']['lang']['home_26'] = "Total Users";
$_SESSION['app_2']['lang']['home_27'] = "Total Paid";
$_SESSION['app_2']['lang']['home_28'] = "CONTACT US";
$_SESSION['app_2']['lang']['home_29'] = "Send Message";
$_SESSION['app_2']['lang']['home_30'] = "PUBLISHER RATES";
$_SESSION['app_2']['lang']['home_31'] = "Country";
$_SESSION['app_2']['lang']['home_32'] = "Earnings per 1000 Downloads";
$_SESSION['app_2']['lang']['home_33'] = "ID";
$_SESSION['app_2']['lang']['home_34'] = "Username";
$_SESSION['app_2']['lang']['home_35'] = "Date";
$_SESSION['app_2']['lang']['home_36'] = "Payment Method";
$_SESSION['app_2']['lang']['home_37'] = "Amount";
$_SESSION['app_2']['lang']['home_38'] = "Status";
$_SESSION['app_2']['lang']['home_39'] = "Account";
$_SESSION['app_2']['lang']['home_40'] = "Publisher Earnings";
//File not found 404
$_SESSION['app_2']['lang']['file404_1'] = " File Not Found";
$_SESSION['app_2']['lang']['file404_2'] = "The file you were looking for could not be found, sorry for any inconvenience.";
$_SESSION['app_2']['lang']['file404_3'] = "Possible causes of this error could be:";
$_SESSION['app_2']['lang']['file404_4'] = "The file expired.";
$_SESSION['app_2']['lang']['file404_5'] = "The file was deleted by its owner.";
$_SESSION['app_2']['lang']['file404_6'] = "The file was deleted by administration because it didn't comply with our Terms of Use.";

// Login & Register & Forgot Password
$_SESSION['app_2']['lang']['stay_signed_in'] = "Stay Signed in";
$_SESSION['app_2']['lang']['sign_in'] = "SIGN IN";
$_SESSION['app_2']['lang']['username'] = "USERNAME";
$_SESSION['app_2']['lang']['password'] = "PASSWORD";
$_SESSION['app_2']['lang']['forgot_password?'] = "Forgot Password ?";
$_SESSION['app_2']['lang']['register_new'] = "Register a new membership";
$_SESSION['app_2']['lang']['email'] = "EMAIL";
$_SESSION['app_2']['lang']['already_membership'] = "I already have a membership";
$_SESSION['app_2']['lang']['i_agree'] = "I agree to the";
$_SESSION['app_2']['lang']['and'] = "and";
$_SESSION['app_2']['lang']['forgot_password'] = "Forgot Password";
$_SESSION['app_2']['lang']['back_login'] = "Back to login";
$_SESSION['app_2']['lang']['reset_password'] = "Reset Password";
$_SESSION['app_2']['lang']['error_login_1'] = "invalid username and password ! try again";
$_SESSION['app_2']['lang']['error_login_2'] = "Your account has been blocked";
$_SESSION['app_2']['lang']['error_login_3'] = "Username is Required And Minimum Length 5";
$_SESSION['app_2']['lang']['error_login_4'] = "Password is Required And Minimum Length 5";
$_SESSION['app_2']['lang']['error_login_5'] = "The two passwords do not match";
$_SESSION['app_2']['lang']['error_login_6'] = "Email is Required";
$_SESSION['app_2']['lang']['error_login_7'] = "Username already exists";
$_SESSION['app_2']['lang']['error_login_8'] = "Email already exists";
$_SESSION['app_2']['lang']['error_login_9'] = "Username is required";
$_SESSION['app_2']['lang']['error_login_10'] = "Email is required";
$_SESSION['app_2']['lang']['error_login_11_0'] = "Username";
$_SESSION['app_2']['lang']['error_login_11_1'] = "with e-mail";
$_SESSION['app_2']['lang']['error_login_11_2'] = "could not be found. Please, try again!";
$_SESSION['app_2']['lang']['error_login_12'] = "Your account has been blocked";
$_SESSION['app_2']['lang']['error_login_13'] = "Incorrect Current password";
$_SESSION['app_2']['lang']['error_login_14'] = "The two Emails do not match";

//User Dashboard
//SideBar
$_SESSION['app_2']['lang']['SideBar_0'] = "balance";
$_SESSION['app_2']['lang']['SideBar_1'] = "Dashboard";
$_SESSION['app_2']['lang']['SideBar_2'] = "Upload Files";
$_SESSION['app_2']['lang']['SideBar_3'] = "Upload";
$_SESSION['app_2']['lang']['SideBar_4'] = "My Files";
$_SESSION['app_2']['lang']['SideBar_5'] = "Upgrade";
$_SESSION['app_2']['lang']['SideBar_6'] = "Withdraw";
$_SESSION['app_2']['lang']['SideBar_7'] = "Referrals";
$_SESSION['app_2']['lang']['SideBar_8'] = "Settings";
$_SESSION['app_2']['lang']['SideBar_9'] = "Change Password";
$_SESSION['app_2']['lang']['SideBar_10'] = "Change Email";
$_SESSION['app_2']['lang']['SideBar_11'] = "Withdrawal";
$_SESSION['app_2']['lang']['SideBar_12'] = "Contact Us";
$_SESSION['app_2']['lang']['SideBar_13'] = "Logout";
$_SESSION['app_2']['lang']['SideBar_14_'] = "You have";
$_SESSION['app_2']['lang']['SideBar_14'] = "new notifications.";
$_SESSION['app_2']['lang']['SideBar_15'] = "See all notifications.";

//Dashboard
$_SESSION['app_2']['lang']['today_earnings'] = "Today Earnings";
$_SESSION['app_2']['lang']['this_month_earnings'] = "This Month Earnings";
$_SESSION['app_2']['lang']['referral_earnings'] = "Referral Earnings";
$_SESSION['app_2']['lang']['used_space'] = "Used Space";
$_SESSION['app_2']['lang']['last_10_days'] = "Last 10 days";
$_SESSION['app_2']['lang']['date'] = "date";
$_SESSION['app_2']['lang']['download'] = "Downloads";
$_SESSION['app_2']['lang']['referrals'] = "Referrals";
$_SESSION['app_2']['lang']['total'] = "Total";
//upload files
$_SESSION['app_2']['lang']['file_upload'] = "FILE UPLOAD";
$_SESSION['app_2']['lang']['upload'] = "UPLOAD";
$_SESSION['app_2']['lang']['remote_url_upload'] = "REMOTE URL UPLOAD";
$_SESSION['app_2']['lang']['Max_Upload_size'] = "Max Upload size";
$_SESSION['app_2']['lang']['upload_1'] = "Extension not allowed for file";
$_SESSION['app_2']['lang']['upload_2'] = "There was a problem uploading file";


//My files
$_SESSION['app_2']['lang']['file_1'] = "File Name";
$_SESSION['app_2']['lang']['file_2'] = "Size";
$_SESSION['app_2']['lang']['file_3'] = "Uploaded On";
$_SESSION['app_2']['lang']['file_4'] = "Download";
$_SESSION['app_2']['lang']['file_5'] = "Earnings";
$_SESSION['app_2']['lang']['file_6'] = "Options";
//Upgrade
$_SESSION['app_2']['lang']['up_1'] = "Current Plan";
$_SESSION['app_2']['lang']['up_2'] = "Expiration Date";
$_SESSION['app_2']['lang']['up_3'] = "FREE";
$_SESSION['app_2']['lang']['up_4'] = "Buy Now";
$_SESSION['app_2']['lang']['up_5'] = "Plus";
$_SESSION['app_2']['lang']['up_6'] = "Pro";
$_SESSION['app_2']['lang']['up_7'] = "Never";
$_SESSION['app_2']['lang']['up_8'] = "Days";
$_SESSION['app_2']['lang']['up_9'] = "after last download";
$_SESSION['app_2']['lang']['up_10'] = "month";
$_SESSION['app_2']['lang']['up_11'] = "Month";
$_SESSION['app_2']['lang']['up_12'] = "Year";
$_SESSION['app_2']['lang']['up_13'] = "Max Upload File Size";
$_SESSION['app_2']['lang']['up_14'] = "Referral earnings";
$_SESSION['app_2']['lang']['up_15'] = "Earnings per 1000 Downloads";
$_SESSION['app_2']['lang']['up_16'] = "When are your files deleted?";
$_SESSION['app_2']['lang']['up_17'] = "Remove ads";
$_SESSION['app_2']['lang']['up_18'] = "No downloads delay";
$_SESSION['app_2']['lang']['up_19'] = "Remove captcha";

//Withdraw
$_SESSION['app_2']['lang']['Withdraw_1'] = "Available Balance";
$_SESSION['app_2']['lang']['Withdraw_2'] = "Pending Withdraw";
$_SESSION['app_2']['lang']['Withdraw_3'] = "Total Withdraw";
$_SESSION['app_2']['lang']['Withdraw_4'] = "Payments History";
$_SESSION['app_2']['lang']['Withdraw_5'] = "Withdraw";
//Referrals
$_SESSION['app_2']['lang']['ref_1'] = "referral program is a great way to spread the word of this great service and to earn even more money with your files ! Refer friends and receive";
$_SESSION['app_2']['lang']['ref_2'] = "of their earnings for life!";
$_SESSION['app_2']['lang']['ref_3'] = "My Referrals";
//Settings
$_SESSION['app_2']['lang']['set_1'] = "Current Password";
$_SESSION['app_2']['lang']['set_2'] = "New Password";
$_SESSION['app_2']['lang']['set_3'] = "Re-New Password";
$_SESSION['app_2']['lang']['set_4'] = "Current Email";
$_SESSION['app_2']['lang']['set_5'] = "New Email";
$_SESSION['app_2']['lang']['set_6'] = "Re-New Email";
$_SESSION['app_2']['lang']['set_7'] = "Withdrawal Info";
$_SESSION['app_2']['lang']['set_8'] = "Withdrawal Method";
$_SESSION['app_2']['lang']['set_9'] = "Minimum Withdrawal Amount";
$_SESSION['app_2']['lang']['set_10'] = "Withdrawal Account";
$_SESSION['app_2']['lang']['set_11'] = "Save";
//Contact Us
$_SESSION['app_2']['lang']['contact_1'] = "Subject";
$_SESSION['app_2']['lang']['contact_2'] = "Message";
$_SESSION['app_2']['lang']['contact_3'] = "Send";
/////////////////////////////
$_SESSION['app_2']['lang']['payment_cancelled'] = "Payment Cancelled";
$_SESSION['app_2']['lang']['payment_su'] = "Successful Payment";
$_SESSION['app_2']['lang']['not_found'] = "Page Not Found";
$_SESSION['app_2']['lang']['and_1'] = "Withdrawal Account is Required";
$_SESSION['app_2']['lang']['and_2'] = "Withdrawal Account has been Updated";
$_SESSION['app_2']['lang']['and_3'] = "Withdraw amount should be equal or greater than";
$_SESSION['app_2']['lang']['and_4'] = "Please Add new Method Payment";
$_SESSION['app_2']['lang']['and_5'] = "Thank you for contacting us. We have recieved your query, you will get a reply from us within the next 24 hours.";
$_SESSION['app_2']['lang']['and_6'] = "All fields must be filled";
$_SESSION['app_2']['lang']['and_7'] = "The CAPTCHA was incorrect. Try again";







































//Admin Panel
//Dashboard
$_SESSION['app_2']['lang']['publisher_earnings_today'] = "Publisher Earnings - Today";
$_SESSION['app_2']['lang']['publisher_earnings'] = "Publisher Earnings";
$_SESSION['app_2']['lang']['publisher_earnings_total'] = "Publisher Earnings - Total";
$_SESSION['app_2']['lang']['total_download'] = "Total Downloads";
$_SESSION['app_2']['lang']['total_files'] = "Total Files";
$_SESSION['app_2']['lang']['total_download_today'] = "Total Downloads Today";
$_SESSION['app_2']['lang']['total_file_size'] = "Total Files Size";
$_SESSION['app_2']['lang']['top5_Countries'] = "Top 5 Countries - This Month";







?>