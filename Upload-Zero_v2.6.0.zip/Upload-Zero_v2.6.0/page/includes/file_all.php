<?php 
if(isset($_GET['id'])){
  $file_up = new Upload();
  $file_up->delete($_GET['id'],$username);
}
?>
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-upload"></i><?php echo $lang['SideBar_4']?></h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered table-responsive" id="sampleTable">
                <thead>
                  <tr>
                    <th style="width:10%">#</th>
                    <th style="width:10%"><?php echo $lang['file_1']?></th>
                    <th style="width:10%"><?php echo $lang['file_2']?></th>
                    <th style="width:10%"><?php echo $lang['file_3']?></th>
                    <th style="width:10%"><?php echo $lang['file_4']?></th>
                    <th style="width:10%"><?php echo $lang['file_5']?></th>
                    <th style="width:10%"><?php echo $lang['file_6']?></th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                      $file_up = new Upload();
                      $file_up->showFiles($username);
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</main>
<script>
      

      function Confi(id,path,user) {
          var r = confirm("Are you sure?");
          if (r == true) {
            window.location.href="files&id="+id;
          }
      }
      
</script>
    
    