<?php
    ob_start();
    session_start();
    header('Content-type: text/css; charset:UTF-8');
    $image = $_SESSION["Background"];
    // color
    if($_SESSION["Design"] == "green"){
        $color1 = "#009688"; // refe => [#009688] : navbar header
    }
    elseif($_SESSION["Design"] == "light green"){
        $color1 = "#28A745"; // refe => [#009688] : navbar header
    }
    elseif($_SESSION["Design"] == "red"){
        $color1 = "#DC3545"; // refe => [#009688] : navbar header
    }
    elseif($_SESSION["Design"] == "grey"){
        $color1 = "#6B757D"; // refe => [#009688] : navbar header
    }
    elseif($_SESSION["Design"] == "blue"){
        $color1 = "#16A2B8"; // refe => [#009688] : navbar header
    }
    elseif($_SESSION["Design"] == "yellow"){
        $color1 = "#FFC107"; // refe => [#009688] : navbar header
    }else{
        $color1 = "#16A2B8"; // refe => [#009688] : navbar header
    }

   
   
    
    
?>
.js .inputfile {
    width: 0.1px;
    height: 0.1px;
    opacity: 0;
    overflow: hidden;
    position: absolute;
    z-index: -1;
}

.inputfile + label {
    max-width: 80%;
    font-size: 1rem;
    /* 20px */
    font-weight: 700;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
    display: inline-block;
    overflow: hidden;
    padding: 0.625rem 1.25rem;
    /* 10px 20px */
}

.no-js .inputfile + label {
    display: none;
}

.inputfile:focus + label,
.inputfile.has-focus + label {
    outline: 1px dotted #000;
    outline: -webkit-focus-ring-color auto 5px;
}

.inputfile + label * {
    /* pointer-events: none; */
    /* in case of FastClick lib use */
}

.inputfile + label svg {
    width: 1em;
    height: 1em;
    vertical-align: middle;
    fill: currentColor;
    margin-top: -0.25em;
    /* 4px */
    margin-right: 0.25em;
    /* 4px */
}


/* style 6 */

.inputfile-6 + label {
    color: <?=$color1?>;
}

.inputfile-6 + label {
    border: 1px solid <?=$color1?>;
    background-color: #f1e5e6;
    padding: 0;
}

.inputfile-6:focus + label,
.inputfile-6.has-focus + label,
.inputfile-6 + label:hover {
    border-color: <?=$color1?>;
}

.inputfile-6 + label span,
.inputfile-6 + label strong {
    padding: 0.42rem 1.25rem;
    /* 10px 20px */
}

.inputfile-6 + label span {
    width: 500px;
    min-height: 2em;
    display: inline-block;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    vertical-align: top;
}

.inputfile-6 + label strong {
    height: 100%;
    color: #f1e5e6;
    background-color: <?=$color1?>;
    display: inline-block;
}

.inputfile-6:focus + label strong,
.inputfile-6.has-focus + label strong,
.inputfile-6 + label:hover strong {
    background-color: <?=$color1?>;
}

@media screen and (max-width: 50em) {
	.inputfile-6 + label strong {
		display: block;
	}
}
