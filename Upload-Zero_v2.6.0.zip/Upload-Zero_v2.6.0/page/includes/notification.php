
    <main class="app-content">
      <div class="row user">
        <div class="col-md-12">
          <div class="tab-content">
            <div class="tab-pane active" id="user-timeline">
              <?php $user->showAllNotic($username)?>
            </div>            
          </div>
        </div>
      </div>
    </main>
    
