
    <main class="app-content">
      <div class="row user">
        <?php 

                $accountPay = $user->showPaymentAccount($username);
                if(empty($accountPay)){
                    $accountPay ="";
                }

                if(isset($_POST['submit_payment'])){
                    $user->addPaymentAccount($username,$_POST['methods'],$_POST['account']);
                }
                
        ?>
        <div class="col-md-3">
          <div class="tile p-0">
            <ul class="nav flex-column nav-tabs user-tabs">
              <li class="nav-item"><a class="nav-link active" href="#change-password" data-toggle="tab"><?php echo $lang['SideBar_9']?></a></li>
              <li class="nav-item"><a class="nav-link" href="#change-email" data-toggle="tab"><?php echo $lang['SideBar_10']?></a></li>
              <li class="nav-item"><a class="nav-link" href="#Withdrawal" data-toggle="tab"><?php echo $lang['SideBar_11']?></a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-9">
          <div class="tab-content">
            
            

            <div class="tab-pane active" id="change-password">
                <div class="tile user-settings">
                    <h4 class="line-head"><?php echo $lang['SideBar_9']?></h4>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-8 mb-4">
                                <label><?php echo $lang['set_1']?></label>
                                <input class="form-control" type="password" name="currentP">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-8 mb-4">
                                <label><?php echo $lang['set_2']?></label>
                                <input class="form-control" type="password" name="newP">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-8 mb-4">
                                <label> <?php echo $lang['set_3']?></label>
                                <input class="form-control" type="password" name="renewP">
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_pa"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $lang['set_11']?></button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane pade" id="change-email">
                <div class="tile user-settings">
                    <h4 class="line-head"><?php echo $lang['SideBar_10']?></h4>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-8 mb-4">
                                <label> <?php echo $lang['set_4']?></label>
                                <input class="form-control" type="email" name="current_email" disabled>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-8 mb-4">
                                <label> <?php echo $lang['set_5']?></label>
                                <input class="form-control" type="email" name="new_email">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-8 mb-4">
                                <label> <?php echo $lang['set_6']?></label>
                                <input class="form-control" type="email" name="renew_email">
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_e"><i class="fa fa-fw fa-lg fa-check-circle"></i> <?php echo $lang['set_11']?></button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane pade" id="Withdrawal">
                <div class="tile user-settings">
                    <h4 class="line-head"><?php echo $lang['SideBar_11']?></h4>
                    <form method="post">
                        <div class="row">
                            
                            <div class="col-md-8 mb-4">
                                <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width:60%"><?php echo $lang['set_7']?></th>
                                        <th style="width:40%"><?php echo $lang['set_8']?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $user->showMethod();?>
                                </tbody>
                                </table>
                                
                            </div>
                            <div class="col-md-8 mb-4">
                                <label><?php echo $lang['set_9']?></label>
                                <select class="form-control" id="exampleSelect1" name="methods">
                                    <?php $user->showlistMethod();?>
                                </select>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-8 mb-4">
                                <label> <?php echo $lang['set_10']?></label>
                                <input class="form-control" type="text" name="account" placeholder="<?php echo $accountPay;?>">
                            </div>
                           
                            <div class="clearfix"></div>
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_payment"><i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo $lang['set_11']?></button>
                        </div>
                    </div>
                </form>
              </div>
            </div>
          
        
        </div>
        </div>
      </div>
    </main>

    <script src="../includes/js/jquery-3.2.1.min.js"></script>
    <script src="../includes/js/popper.min.js"></script>
    <script src="../includes/js/bootstrap.min.js"></script>
    <script src="../includes/js/main.js"></script>
    <script src="../includes/js/plugins/pace.min.js"></script>
    <script src="../includes/js/plugins/bootstrap-notify.min.js"></script>
	<script src="../includes/js/plugins/sweetalert.min.js"></script>
    <?php
        $succe= array();$debug= array();

        if(isset($_POST['submit_p'])){
            $values = array($_POST['fname'],$_POST['lname'],$_POST['address1'],$_POST['address2'],$_POST['country'],$_POST['state'],$_POST['city'],$_POST['phone'],$_POST['zip']);
            $col_nm = array('fname','lname','adress1','adress2','country','state','city','phone_number','code_postal');
            $debug = $user->edit($col_nm,$values,$username);
            $type_edit = " Profile";
            $succe[0]="succe";
        }

        if(isset($_POST['submit_pa'])){
            $currentP = $_POST['currentP'];
            $newP = $_POST['newP'];
            $renewP = $_POST['renewP'];
            $debug = $user->changePassword($currentP,$rows['password'],$newP,$renewP,$username);
            $type_edit = " Password";
            $succe[0]="succe";
        }

        if(isset($_POST['submit_e'])){
            $newE = $_POST['new_email'];
            $renewE = $_POST['renew_email'];
            $debug = $user->changeEmail($newE,$renewE,$username);
            $type_edit = " Email";
            $succe[0]="succe";
        }
    ?>
    <?php
      if(count($debug) !=0 ){
    ?>
    <script type="text/javascript">
      $('#error').ready(function(){
      	$.notify({
      		title: " <?php echo $debug[0]?>",
          message: ""
          ,
      		icon: 'fa fa-exclamation-triangle' 
      	},{
      		type: "danger"
      	});
      });
      </script>
    <?php } ?>

    <?php
      if(count($succe) !=0 && count($debug) == 0){
    ?>
    <script type="text/javascript">
      $('#error').ready(function(){
      	$.notify({
      		title: " <?php echo $type_edit;?> has been updated",
          message: ""
          ,
      		icon: 'fa fa-check' 
      	},{
      		type: "success"
      	});
      });
      </script>
    <?php } ?>
