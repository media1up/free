<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-envelope"></i><?php echo $lang['SideBar_12']?></h1>
        </div>
        
      </div>
      <?php $ads->showBannerMember($banner);?>
      <div class="row">
      
        <div class="col-md-12">
          <div class="tile">
            <div class="row">
              <div class="col-lg-12">
                <?php
                    if(isset($_POST['send'])){
                        $subject = Remove_er_sql($_POST['subject']);
                        $msg = Remove_er_sql($_POST['msg']);
                        $type="";
                        $user->sendMsg($username,$type,$subject,$msg);
                    }
                ?>
                <form method="post">
                  <div class="form-group">
                    <label for="exampleInputEmail1"><?php echo $lang['contact_1']?></label>
                    <input class="form-control" id="exampleInputEmail1" type="name" aria-describedby="emailHelp" name="subject">
                  </div>
                  <div class="form-group">
                    <label for="exampleTextarea"><?php echo $lang['contact_2']?></label>
                    <textarea class="form-control" id="exampleTextarea" rows="6" name="msg"></textarea>
                  </div>
                
              </div>
              
            </div>
            
                <div class="tile-footer">
                <button class="btn btn-primary" type="submit" name="send"><?php echo $lang['contact_3']?></button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </main>