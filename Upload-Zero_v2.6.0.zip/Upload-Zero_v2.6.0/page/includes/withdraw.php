
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dollar"></i> <?php echo UPPER_1ST_ELEMENT($lang['SideBar_6']);?></h1>
    </div>
    
  </div>
  <div class="row">
  <?php
  if(isset($_POST['submit'])){
    $user->getPayment($username);
  }
?>
    <div class="col-md-6 col-lg-4">
      <div class="widget-small primary coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $settings['currency'].$balance?></b>
          <p><b><?php echo $lang['Withdraw_1']?></b></p>
        </div>
      </div>
    </div>
    
    <div class="col-md-6 col-lg-4">
      <div class="widget-small danger coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $settings['currency'].$pending_payment?></b>
          <p><b> <?php echo $lang['Withdraw_2']?></b></p>
          
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-4">
      <div class="widget-small info coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
        <div class="info" >
          <b style="font-size:20px"><?php echo $settings['currency'].$total_payment?></b>
          <p><b><?php echo $lang['Withdraw_3']?></b></p>
        </div>
      </div>
    </div>
  </div>
  
    <form method="post">
        <center><button class="btn btn-primary" name="submit" style="padding:9px 14px 9px 14px"><?php echo $lang['Withdraw_5']?></button></center>
        <br>
    </form>

  <div class="row">
  <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title"><?php echo $lang['Withdraw_4']?></h3>
            <div class="table-responsive">
              <table class="table">
              <thead>
                  <tr>
                    <th>#</th>
                    <th><?php echo $lang['home_35']?></th>
                    <th><?php echo $lang['home_36']?></th>
                    <th><?php echo $lang['home_39']?></th>
                    <th><?php echo $lang['home_40']?></th>
                    <th><?php echo $lang['referral_earnings']?></th>
                    <th><?php echo $lang['total']?></th>
                    <th><?php echo $lang['home_38']?></th>
                  </tr>
                </thead>
                <tbody>
                      <?php $user->showPayment($username)?>
                </tbody>
                </table>
                

                
            </div>
          </div>
        </div>
  </div>
</main>
