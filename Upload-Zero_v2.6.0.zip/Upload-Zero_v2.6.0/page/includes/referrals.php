
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-retweet"></i> <?php echo UPPER_1ST_ELEMENT($lang['SideBar_7']);?></h1>
    </div>
    
  </div>
  <?php $ads->showBannerMember($banner);?>
  <div class="row">
  
        <div class="col-md-12">
            <div class="tile">
                <p><?php echo $settings['SiteName']?> <?php echo $lang['ref_1']?> <span style="color:#009689"><?php echo $settings['ReferralRate']?>% <?php echo $lang['ref_2']?></span></p>
                
                <?php 
                    ShowShort($settings['HTTP_s']."/page/ref"."/".$username,"100%");
                ?>
                
            </div>
        </div>
    </div>
  
  

    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <h5 class="tile-title"><?php echo $lang['ref_3']?></h5>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo $lang['home_34']?></th>
                                <th><?php echo $lang['home_35']?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $user->allReferrals($username)?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
