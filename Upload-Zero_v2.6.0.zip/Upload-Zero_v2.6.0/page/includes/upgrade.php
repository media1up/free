
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-arrow-circle-up"></i> <?php echo UPPER_1ST_ELEMENT($lang['SideBar_5']);?></h1>
    </div>
    
  </div>
  <?php
  if(isset($_POST['plan_plus']) || isset($_POST['plan_pro']))
  {
    include 'payments/paypal_ipn.php';
  }
?>
<h4><?php echo $lang['up_1']?> : <?php echo $upgrade_name?></h4>
<h5><?php echo $lang['up_2']?> : <?php echo $uprage_date?></h5>
  <section class="pricing py-5"><form method="post" id="paypal_form">
  <div class="container">
    <div class="row">

      <!-- Free Tier -->
      <div class="col-lg-4">
        <div class="card mb-5 mb-lg-0">
          <div class="card-body">
            <h5 class="card-title text-muted text-uppercase text-center"><?php echo $lang['up_3']?></h5>
            
            <?php $user->Plans("1");?>
             <br>
            <a href="#" class="btn btn-block btn-primary text-uppercase" style="cursor: not-allowed;"><?php echo $lang['up_3']?></a>
          </div>
        </div>
      </div>
      <!-- Plus Tier -->
      <div class="col-lg-4">
        <div class="card mb-5 mb-lg-0">
          <div class="card-body">
            <h5 class="card-title text-muted text-uppercase text-center"><?php echo $lang['up_5']?></h5>
            
            <?php $user->Plans("2");?>
             <br>
                <input type="hidden" name="cmd" value="_xclick" />
                <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
                <input type="hidden" name="item_number" value="123456" />
            <button class="btn btn-block btn-primary text-uppercase" type="submit" name="plan_plus"><?php echo $lang['up_4']?> </button>
          </div>
        </div>
      </div>
      <!-- Pro Tier -->
      <div class="col-lg-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title text-muted text-uppercase text-center"><?php echo $lang['up_6']?></h5>
            
            <?php $user->Plans("3");?>
             <br>
            <button class="btn btn-block btn-primary text-uppercase" type="submit" name="plan_pro"><?php echo $lang['up_4']?> </button>
          </div>
        </div>
      </div>
      
    </div>
  </div></form>
</section>
 
  
   

  <div class="row">
  
</main>


