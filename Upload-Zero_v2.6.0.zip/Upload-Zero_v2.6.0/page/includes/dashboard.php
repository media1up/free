<?php $user->GetDataUser($username)?>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i> <?php echo UPPER_1ST_ELEMENT($lang['SideBar_1']);?></h1>
    </div>
    
  </div>
  <?php $ads->showBannerMember($banner);?>

  <div class="row">
    <div class="col-md-6 col-lg-3">
      <div class="widget-small primary coloured-icon"><i class="icon fa fa-line-chart fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $settings['currency']. $balance_today?></b>
          <p><b><?php echo $lang['today_earnings']?></b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small warning coloured-icon"><i class="icon fa fa-suitcase fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $settings['currency']. $balance_month?></b>
          <p><b><?php echo $lang['this_month_earnings']?></b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small info coloured-icon"><i class="icon fa fa-exchange fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $settings['currency']. $balance_ref?></b>
          <p><b><?php echo $lang['referral_earnings']?></b></p>
          
        </div>
      </div>
    </div><div class="col-md-6 col-lg-3">
      <div class="widget-small danger coloured-icon"><i class="icon fa fa-pie-chart fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $user->TotalFilesSize($username)?></b>
          <p><b><?php echo $lang['used_space']?></b></p>
        </div>
      </div>
    </div>
    
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title"><?php echo $lang['last_10_days']?></h3>
        <div class="embed-responsive embed-responsive-16by9">
          <canvas class="embed-responsive-item" id="lineChartDemo"></canvas>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title"><?php echo $lang['last_10_days']?></h3>
        <div class="embed-responsive embed-responsive-16by9">
          <canvas class="embed-responsive-item" id="pieChartDemo"></canvas>
        </div>
      </div>
    </div>
    
  </div>

  <div class="row">
  <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title"><?php echo $lang['reports']?></h3>
            <div class="table-responsive">
              <table class="table">
              <thead>
                  <tr>
                    <th><?php echo $lang['date']?></th>
                    <th><?php echo $lang['download']?></th>

                    <th>eCPM</th>
                    <th><?php echo $lang['referrals']?></th>
                    <th><?php echo $lang['total']?></th>
                  </tr>
                </thead>
                <tbody id="txtHint">

                  <script>
                    function report(p){
                      var xmlhttp = new XMLHttpRequest();
                        xmlhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("txtHint").innerHTML = this.responseText;
                            }
                        }
                        xmlhttp.open("GET", "../ajax.php?p="+p, true);
                        xmlhttp.send();
                    }
                      report(1);
                  </script>
                </tbody>
                </table>
                <div id="n"></div>

                <script>
                  function pagi(p){
                    var xmlhttp = new XMLHttpRequest();
                      xmlhttp.onreadystatechange = function() {
                          if (this.readyState == 4 && this.status == 200) {
                              document.getElementById("n").innerHTML = this.responseText;
                          }
                      }
                      xmlhttp.open("GET", "../ajax.php?n="+p, true);
                      xmlhttp.send();
                  }
                    pagi(1);
                </script>
            </div>
          </div>
        </div>
  </div>
</main>
