<?php
  $count_notice = $user->countNotic($username);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo UPPER_1ST_ELEMENT($page);?></title>
    <?php $nav = Active_nav_pub($page);?>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- main.css.php-->
    <link rel="stylesheet" type="text/css" href="<?php echo $css."main.css.php";?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $css."zero.css";?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $css."component.php";?>">
    <link rel="stylesheet" href="<?php echo $css."dropify.min.css";?>">
    
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <script>
      function show(id){
        var xmlhttp = new XMLHttpRequest();
          xmlhttp.open("GET", "../ajax.php?notice="+id, true);
          xmlhttp.send();
          window.location.href="notification";
      }

    </script>
</head>
<body class="app sidebar-mini rtl">
    <!-- Navbar-->

    
    <header class="app-header"><a class="app-header__logo" href="#"><?php echo $settings['SiteName']?></a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!--Notification Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Show notifications"><i class="fa fa-bell-o fa-lg"></i>
          <?php
            if($count_notice != 0){
              echo '<span class="badge badge-pill badge-danger">'.$count_notice.'</span>';
            }
          ?>
        </a>
          <ul class="app-notification dropdown-menu dropdown-menu-right">
            <li class="app-notification__title"> <?php echo $lang['SideBar_14_']?><?php echo $count_notice;?> <?php echo $lang['SideBar_14']?></li>
            <div class="app-notification__content">
              <?php 
                $user->showNotic($username);
              ?>
              
            </div>
            <li class="app-notification__footer"><a href="notification"><?php echo $lang['SideBar_15']?></a></li>
          </ul>
        </li>
        
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="profile"><i class="fa fa-cog fa-lg"></i><?php echo $lang['SideBar_8']?></a></li>
            <li><a class="dropdown-item" href="logout"><i class="fa fa-sign-out fa-lg"></i><?php echo $lang['SideBar_13']?></a></li>
          </ul>
        </li>
      </ul>
    </header>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="<?php echo $img."user1.png";?>" width="48"  alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?php echo $username;?></p>
          <p class="app-sidebar__user-designation"><?php echo $lang['SideBar_0']?> : <?php echo $settings['currency'].$balance?></p>
        </div>
      </div>
      <ul class="app-menu">

        <!-- Dashboard-->
        <li><a class="app-menu__item <?php echo $nav[0];?>" href="dashboard"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label"><?php echo $lang['SideBar_1']?></span></a></li>
        

       

        <!-- Upload Files-->
        <li class="treeview"><a class="app-menu__item <?php echo $nav[2];?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-upload"></i><span class="app-menu__label"><?php echo $lang['SideBar_2']?></span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="upload"><?php echo $lang['SideBar_3']?></a></li>
            <li><a class="treeview-item" href="files"><?php echo $lang['SideBar_4']?></a></li>

            <!-- <li><a class="treeview-item" href="sell"> Upload & Sell</a></li>
            <li><a class="treeview-item" href="Sfiles">Sales Files</a></li> -->

          </ul>
        </li>

        

        <!-- Upgrade Account-->
        <li><a class="app-menu__item <?php echo $nav[3];?>" href="upgrade"><i class="app-menu__icon fa fa-arrow-circle-up"></i><span class="app-menu__label"><?php echo $lang['SideBar_5']?></span></a></li>
        
        <!-- Withdraw-->
        <li><a class="app-menu__item <?php echo $nav[4];?>" href="withdraw"><i class="app-menu__icon fa fa-dollar"></i><span class="app-menu__label"><?php echo $lang['SideBar_6']?></span></a></li>

        <!-- Referrals-->
        <li><a class="app-menu__item <?php echo $nav[5];?>" href="referrals"><i class="app-menu__icon fa fa-retweet"></i><span class="app-menu__label"><?php echo $lang['SideBar_7']?></span></a></li>

        <!-- Settings-->
        <li class="treeview"><a class="app-menu__item <?php echo $nav[6];?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-cog"></i><span class="app-menu__label"><?php echo $lang['SideBar_8']?></span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="profile"> <?php echo $lang['SideBar_9']?></a></li>
            <li><a class="treeview-item" href="profile"> <?php echo $lang['SideBar_10']?></a></li>
            <li><a class="treeview-item" href="profile"> <?php echo $lang['SideBar_11']?></a></li>
          </ul>
        </li>

       

        <!-- Contact Us-->
        <li><a class="app-menu__item <?php echo $nav[8];?>" href="contact"><i class="app-menu__icon fa fa-envelope"></i><span class="app-menu__label"><?php echo $lang['SideBar_12']?></span></a></li>

      </ul>
    </aside>
    