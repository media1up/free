var timeleft = 5;
var Timer = setInterval(function(){
  timeleft--;
  document.getElementById("countdown").textContent = timeleft +"s";
  if(timeleft <= 0){
    clearInterval(Timer);
    
  }
},1000);