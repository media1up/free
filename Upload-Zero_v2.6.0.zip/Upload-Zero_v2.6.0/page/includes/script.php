
<?php
$settings = $_SESSION['app_2'];
	if($page!="profile" ){
 ?>
    <script src="<?php echo $js."jquery-3.2.1.min.js";?>"></script>
    <script src="<?php echo $js."popper.min.js";?>"></script>
    <script src="<?php echo $js."bootstrap.min.js";?>"></script>
    <script src="<?php echo $js."main.js";?>"></script>
	<!-- The javascript plugin to display page loading on top-->
<?php
	}
	if($page=="links" || $page=="files"){
 ?>
 	<script type="text/javascript" src="<?php echo $js."plugins/jquery.dataTables.min.js";?>"></script>
	<script type="text/javascript" src="<?php echo $js."plugins/dataTables.bootstrap.min.js";?>"></script>
	<script type="text/javascript">$('#sampleTable').DataTable();</script>
<?php

	}
	// Get last 10 Days
	$days = array();
	for($i=1;$i<11;$i++){
		$date=date_create(date("Y-m-d"));
		date_add($date,date_interval_create_from_date_string("-$i days"));
		$d = explode('-',date_format($date,"Y-m-d"));
		$days[] = end($d);
	}
	$label = '';
	$g = '';
	for($j=9;$j>=0;$j--){
		$label .= $days[$j].', ';
	}

	// Get Download And Views Chart
	

	if($page=="dashboard" || $page=="statistics" || $page=="reports"){
?>
    <script src="<?php echo $js."plugins/pace.min.js";?>"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="<?php echo $js."plugins/chart.js";?>"></script>
    <script type="text/javascript">
	// 30 days
	
      var data = {
		
      	labels: [<?php echo $label;?>],
      	datasets: [
      		{
      			label: "Views links",
      			fillColor: "rgba(220,220,220,0.2)",
      			strokeColor: "rgba(220,220,220,1)",
      			pointColor: "rgba(220,220,220,1)",
      			pointStrokeColor: "#fff",
      			pointHighlightFill: "#fff",
      			pointHighlightStroke: "rgba(220,220,220,1)",
      			data: [<?php echo $_SESSION['app_2']['dataset0'];?>]
      		}
      	]
      };
	  
	  // dashboard
      var pdata = [
      	{
      		value: <?php echo $_SESSION['app_2']['pieChart0'];?>,
      		color: "#DBDBDB",
      		highlight: "#DBDBD0",
      		label: "Downloads Files"
      	}
      ]
      

      var ctxl = $("#lineChartDemo").get(0).getContext("2d");
      var lineChart = new Chart(ctxl).Line(data);

	  //var ctxl1 = $("#lineChartDemo1").get(0).getContext("2d");
      //var lineChart1 = new Chart(ctxl1).Line(data1);
      
      var ctxp = $("#pieChartDemo").get(0).getContext("2d");
      var pieChart = new Chart(ctxp).Pie(pdata);

    </script>
    
<?php } ?>
<?php
	if($page =="upload"){
?>
		<script src="<?php echo $js."dropify.min.js";?>"></script>
        <script>
            $(document).ready(function(){
                // Basic
                $('.dropify').dropify();

                // Translated
                $('.dropify-fr').dropify({
                    messages: {
                        default: 'Glissez-déposez un fichier ici ou cliquez',
                        replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                        remove:  'Supprimer',
                        error:   'Désolé, le fichier trop volumineux'
                    }
                });

                // Used events
                var drEvent = $('#input-file-events').dropify();

                drEvent.on('dropify.beforeClear', function(event, element){
                    return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
                });

                drEvent.on('dropify.afterClear', function(event, element){
                    alert('File deleted');
                });

                drEvent.on('dropify.errors', function(event, element){
                    console.log('Has Errors');
                });

                var drDestroy = $('#input-file-to-destroy').dropify();
                drDestroy = drDestroy.data('dropify')
                $('#toggleDropify').on('click', function(e){
                    e.preventDefault();
                    if (drDestroy.isDropified()) {
                        drDestroy.destroy();
                    } else {
                        drDestroy.init();
                    }
                })
            });
        </script>
	

<?php } ?>
