<main class="app-content">
<div class="app-title">
        <div>
            <h1><?php echo $lang['not_found']?></h1>
        </div>
        
      </div>
    <h1><?php echo $lang['not_found']?></h1>
</main>