<?php
    class ads {
        private $db;
        public function __construct(){
            $this->db = new database();
        }


        public function GeneratorAds_link($page){
            // v1.0.0

            $ads_active = array();

            $query = $this->db->Query("SELECT * FROM campaigns WHERE status ='Active' And adsType='Visitor'");
            while($data = mysqli_fetch_array($query)){
                $ads_active[] = $data["id"]; 
            }

            // 3 banner ads
            $ads_Show = array();
            if(count($ads_active) < 3){
                $nAds = count($ads_active);
            }else{
                $nAds = 3;
            }
            $rand = array_rand($ads_active,$nAds);
            for($j=0;$j<$nAds;$j++){
                $ads_Show[] = $ads_active[$rand[$j]];
            }

            return $ads_Show;

        }

        public function showBanner($id){
            $RequestBannerSql = $this->db->Query("SELECT * FROM campaigns WHERE id = '$id'");
            $data = mysqli_fetch_array($RequestBannerSql);
            $banner = $data['HtmlText'];
            if($banner == "--"){
                $img = $data['Banner'];
                $link = $data['Url'];
                $banner = "<a href='$link' target='_blank'>";
                $banner .= "<img src='res/rsc_upload/banner/$img'>";
                $banner .= "</a>";
            }
            
            if($_SESSION['fisrt_ads'] == true){
                $col = array("views");
                $val = array(1);
                $this->db->Incerement("campaigns",$col,$val,"id",$id);
            }
                
            return $banner;
        }

        public function GeneratorAds_link_Member(){
            // v1.0.0
            $ads_active = array();

            $query = $this->db->Query("SELECT * FROM campaigns WHERE status ='Active' And adsType='Member Area ad'");
            while($data = mysqli_fetch_array($query)){
                $ads_active[] = $data["id"]; 
            }

            // 1 banner ads
            $rand = rand(0,count($ads_active)-1);
            $banner_id = $ads_active[$rand];
            return $banner_id;
        }

        public function showBannerMember($id){
            $RequestBannerSql = $this->db->Query("SELECT * FROM campaigns WHERE id = '$id'");
            $data = mysqli_fetch_array($RequestBannerSql);
            $banner = $data['HtmlText'];
            if($banner == "--"){
                $img = $data['Banner'];
                $link = $data['Url'];
                $banner = "<a href='$link' target='_blank'>";
                $banner .= "<img src='../../res/rsc_upload/banner/$img'>";
                $banner .= "</a>";
            }
            
            if($_SESSION['member_ads'] % 5 == 0){
                $col = array("views");
                $val = array(1);
                $this->db->Incerement("campaigns",$col,$val,"id",$id);
            }
            
            echo "<center>";
            echo $banner;
            echo "</center><br>";
        }

        public function showIntertaital(){
        }

        public function showPopUp(){   
        }

        public function getCPM_pub($type,$Code){
            $query = $this->db->Query("SELECT * FROM rates WHERE code='$Code' AND Pub_file != '0'");
            $row = mysqli_num_rows($query);
            if($row == 0){
                $data = $this->getAllCountries();
            }else{
                $data = mysqli_fetch_array($query); 
            }
            if($type == "link"){
                $cpm = $data['Pub_link'];
            }else if($type == "file"){
                $cpm = $data['Pub_file'];
            }
            return $cpm/1000;
        }

        public function getAllCountries(){
            $query = $this->db->Query("SELECT * FROM rates WHERE code='ZZ'");
            $data = mysqli_fetch_array($query);
            return $data;

        }

        public function GeneratorAds_file($page,$country,$category="Upload Files"){
            // v1.0.0

            $ads_active = array();
            $ads_active_type = array();


            $query = $this->db->Query("SELECT * FROM campaigns WHERE status ='active' AND CampaignBudget > cost AND DailyBudget > costToday");
            while($data = mysqli_fetch_array($query)){
                $categories = explode(',',$data['categories']);
                $countries = explode(',',$data['countries']);
                if((in_array($category,$categories) && in_array($country,$countries)) || (in_array("All Categories",$categories) && in_array("All Countries",$countries))){
                    $ads_active[] = $data['id'];
                    $ads_active_type[] = $data['CampaignType'];
                    //$ads_active_type[] = substr($data['CampaignType'],0,6);

                }
                
            }

            if($page == 0){
                // 3 banner ads
                $ads_alowed = array();
                for($i=0;$i<count($ads_active_type);$i++){
                    if($ads_active_type[$i] == "Banner 300 x 250"){
                        $ads_alowed[] = $ads_active[$i];
                    }
                }

                $ads_Show = array();
                if(count($ads_alowed) < 3){
                    $nAds = count($ads_alowed);
                }else{
                    $nAds = 3;
                }
                $rand = array_rand($ads_alowed,$nAds);
                for($j=0;$j<$nAds;$j++){
                    $ads_Show[] = $ads_alowed[$rand[$j]];
                }
                
                
            }else if($page == 1){
                // 3 banner ads

                $ads_alowed = array();
                for($i=0;$i<count($ads_active_type);$i++){
                    if(substr($ads_active_type[$i],0,6) == "Banner"){
                        $ads_alowed[] = $ads_active[$i];
                    }
                }

                $ads_Show = array();
                if(count($ads_alowed) < 3){
                    $nAds = count($ads_alowed);
                }else{
                    $nAds = 3;
                }
                $rand = array_rand($ads_alowed,$nAds);
                for($j=0;$j<$nAds;$j++){
                    $ads_Show[] = $ads_alowed[$rand[$j]];
                }

                

            }else{
                // 2 banner ads

                $ads_alowed = array();
                for($i=0;$i<count($ads_active_type);$i++){
                    if(substr($ads_active_type[$i],0,6) == "Banner"){
                        $ads_alowed[] = $ads_active[$i];
                    }
                }

                $ads_Show = array();
                if(count($ads_alowed) < 2){
                    $nAds = count($ads_alowed);
                }else{
                    $nAds = 2;
                }
                $rand = array_rand($ads_alowed,$nAds);
                for($j=0;$j<$nAds;$j++){
                    $ads_Show[] = $ads_alowed[$rand[$j]];
                }
            }
            
            return $ads_Show;

            
        
            
            

                
            

            //return $ads_array;
        }

        public function showBanner1($id,$CountryCode){
            $RequestBannerSql = $this->db->Query("SELECT * FROM campaigns WHERE id = '$id'");
            $data = mysqli_fetch_array($RequestBannerSql);
            $banner = $data['HtmlText'];
            if($banner == "--"){
                $img = $data['Banner'];
                $link = $data['link'];
                $banner = "<a href='$link' target='_blank'>";
                $banner .= "<img src='../../res/rsc_upload/banner/$img'>";
                $banner .= "</a>";
            }
            
            if($_SESSION['fisrt_ads'] == true){
                $col = array("views","cost","viewsToday","viewsThisMonth","costToday","costThisMonth");
                $cost = $this->getCPM_adv("Banner",$CountryCode);
                $val = array(1,$cost,1,1,$cost,$cost);
                $this->db->Incerement("campaigns",$col,$val,"id",$id);
            }
                
            return $banner;
        }

    }
?>