<?php
include 'config.php';

    class database{
        private $dbhost;
        private $user;
        private $pass;
        private $dbname;

        public $con;

        public function __construct(){  
            global $db_;
            global $user_;
            global $pass_;
            global $name_;
            
            $this->dbhost = $db_;
            $this->user=$user_;
            $this->pass=$pass_;
            $this->dbname=$name_;
            $this->con = mysqli_connect($this->dbhost, $this->user, $this->pass, $this->dbname);  
            if(!$this->con)  
            {  
                echo 'Database Connection Error ' . mysqli_connect_error($this->con);  
            }  
        }

        public function Select($table_name,$where_col,$where_value){
            $array = array();  
            $query = "SELECT * FROM ".$table_name."";
            if($where_col != null && $where_value != null && count($where_col)==count($where_value)){
                $query.=" WHERE ";
                for($i=0;$i<count($where_col);$i++){
                    $query.="$where_col[$i] = $where_value[$i]";
                    if($i<count($where_col)-1){
                        $query.=" AND ";
                    }
                }
            }
            $result = mysqli_query($this->con, $query);  
            while($row = mysqli_fetch_array($result))  
            {  
                 $array[] = $row;  
            }  
            
            return $array;
        }

        public function Insert($table_name,$col_name,$value_name){
            $query = "INSERT INTO `$table_name` (";
            for($i=0;$i<count($col_name);$i++){
                $query.= "`$col_name[$i]`";
                if($i < count($col_name)-1){
                    $query.=",";
                }
            }
            $query.= ") VALUES (";
            for($j=0;$j<count($value_name);$j++){
                $query.= "'$value_name[$j]'";
                if($j < count($value_name)-1){
                    $query.=",";
                }
            }
            $query.= ")";
            mysqli_query($this->con,$query);
        }

        public function Delete($table_name,$col_name,$id){
            $query = "DELETE FROM ".$table_name." WHERE ".$col_name."=".$id;
            $result = mysqli_query($this->con,$query);  
        }

        public function Update($table_name,$col_name,$value,$where_col,$where_value){
            $query ="UPDATE `$table_name` SET";
            if(count($col_name) == count($value)){
                for($i=0;$i<count($col_name);$i++){
                    $query.="`$col_name[$i]` = '$value[$i]'";
                    if($i<count($col_name)-1){
                        $query.=",";
                    }
                }
            }
            $query.="WHERE `$table_name`.`$where_col`='$where_value'";
            $result = mysqli_query($this->con,$query);
        }

        public function isExists($table_name,$col_name,$value){
            $result = mysqli_query($this->con,"SELECT * FROM `$table_name` WHERE `$col_name`='$value'");
            $num_rows = mysqli_num_rows($result);
            if($num_rows == 0){
                return false;   // no result
            }else{
                return true;    // with result
            }

        }

        public function Query($query){
            return mysqli_query($this->con,$query);
        }

        public function MultiQuery($query){
            return mysqli_multi_query($this->con,$query);
        }

        public function Incerement($table_name,$col_name,$value,$where_col,$where_value){
            $query ="UPDATE `$table_name` SET";
            if(count($col_name) == count($value)){
                for($i=0;$i<count($col_name);$i++){
                    $query.="`$col_name[$i]` = $col_name[$i]+'$value[$i]'";
                    if($i<count($col_name)-1){
                        $query.=",";
                    }
                }
            }
            $query.="WHERE `$table_name`.`$where_col`='$where_value'";
            $result = mysqli_query($this->con,$query);
        }

        public function IncStr($table_name,$col_name,$value,$where_col,$where_value){
            $query ="UPDATE `$table_name` SET";
            if(count($col_name) == count($value)){
                for($i=0;$i<count($col_name);$i++){
                    $query.="`$col_name[$i]` = CONCAT($col_name[$i], '$value[$i]')";
                    if($i<count($col_name)-1){
                        $query.=",";
                    }
                }
            }
            $query.="WHERE `$table_name`.`$where_col`='$where_value'";
            $result = mysqli_query($this->con,$query);
        }

        
    }
?>