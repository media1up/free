<?php
    class Pages {
        private $db;
        private $u;
        private $settings;
        private $lang;
        public function __construct(){
            $this->db = new database();
        }

        public function setSettings(){
            $this->u = new user();
            $this->settings = $_SESSION['app_2'];
            $this->lang = $_SESSION['app_2']['lang'];
        }

        public function addReports(){
            $this->u->addReport();
        }

        public function TotalUsers(){
            $q = "SELECT count(`id`) as gtotal FROM users ";
            $result = $this->db->Query($q);
            $row=mysqli_fetch_array($result);
            return $row['gtotal'];
        }

        public function TotalFiles(){
            $q = "SELECT count(`id`) as gtotal FROM files ";
            $result = $this->db->Query($q);
            $row=mysqli_fetch_array($result);
            return $row['gtotal'];
        }

        public function TotalDownloads(){
            $t=0;
            $result = $this->db->Query("SELECT sum(`download`) as gtotal_files FROM files");
            $row=mysqli_fetch_array($result);
            $result1 = $this->db->Query("SELECT sum(`download`) as gtotal_reportsnonview FROM reportsnonview");
            $row1=mysqli_fetch_array($result1);

            $t = $row['gtotal_files'] + $row1['gtotal_reportsnonview'];
            return $t;
        }

        public function showlistMethod(){
            $res = $this->db->Query("SELECT * FROM withdraw WHERE status = 'on'");
            while($data = mysqli_fetch_assoc($res)){
                $id = $data['id'];
                echo "<option value='$id'>".$data['method']." - ".$this->settings['currency'].$data['amount'] ."</option>";
            } 
        }

        public function addMethod($method,$amount){
            if(!empty($method) && !empty($amount)){
                $method = Remove_er_sql($method);
                $amount = Remove_er_sql($amount);
                $this->db->Insert("withdraw",array("method","amount"),array($method,$amount));
                Success("Success","100%");
            }else{
                Alert("Errro","100%");
            }
        }

        public function deleteMethod($id){
            $this->db->delete("withdraw","id",$id);
        }

        public function getFileName($p){
            $result = $this->db->Query("SELECT * FROM files WHERE alias = '$p'");
            $data = mysqli_fetch_assoc($result);
            $row = mysqli_num_rows($result);
            if($row == 0) Redirect("404");
                
            return $data['name'];
        }

        public function sendReportAbuse($file_name,$name,$email,$reason,$info){
            if(!empty($name) && !empty($email)){

                $name = Remove_er_sql($name);
                $email = Remove_er_sql($email);
                $reason = Remove_er_sql($reason);
                $info = Remove_er_sql($info);

                require('page/reCaptcha/autoload.php');
                if(isset($_POST['g-recaptcha-response'])) {
                    $recaptcha = new \ReCaptcha\ReCaptcha($this->settings["CaptchaSecretKey"]);
                    $resp = $recaptcha->verify($_POST['g-recaptcha-response']);
                    if ($resp->isSuccess()) {
                        $message = "Name : ".$name."<br>";
                        $message .= "Email : ".$email."<br>";
                        $message .= "Reason : ".$reason."<br>";
                        $message .= "Information : ".$info;

                        $subject = "Report Abuse for file [$file_name]";

                        $col = array("admin","title","subject","message","date","icon","color");
                        $val = array("admin","Report Abuse",$subject,$message,date("d-m-Y H:i:s"),"fa-envelope","danger");
                        $this->db->Insert("admin_notification",$col,$val);
                        Success("Report abuse has been sent","100%");
                        
                    }
                    else AlertCenter("<center> ".$this->lang['and_7']." </center>","100%");
                }
                else AlertCenter("<center> ".$this->lang['and_7']." </center>","100%");
            }

        }

        public function sendMsg($name,$email,$subject,$message){
            if(!empty($subject) && !empty($message) && $_SESSION['j'] <= 3){
                $name = Remove_er_sql($name);
                $email = Remove_er_sql($email);
                $subject = Remove_er_sql($subject);
                $message = Remove_er_sql($message);

                $msg  = "Name : ".$name."<br>";
                $msg .= "Email : ".$email."<br>";
                $msg .= "Messgae : ".$message;
                $col = array("username","type","subject","message","date");
                $val = array($name,"",$subject,$msg,date("d-m-Y H:i:s"));
                $this->db->Insert("msg",$col,$val);
                Success($this->lang['and_5'],"100%");
                $_SESSION['j']++;
            }
            else{
                Alert($this->lang['and_6'],"100%");
            }
        }
        
        public function showRates_file(){
            $result = $this->db->Query("SELECT * FROM rates WHERE status = 'on' AND Pub_file != '0'  ORDER BY Pub_file DESC");
            while($data = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td><span class='flag-icon flag-icon-".strtolower($data['code'])."'></span> ".$data['country']."</td>";
                $payout = $data['Pub_file'];
                if(strlen($data['Pub_file'])<=2){
                    $payout = $data['Pub_file'].".00";
                }else if(strlen($data['Pub_file'])==3){
                    $payout = $data['Pub_file']."0";
                }
                
                echo "<td style='text-align: center;'>".$this->settings['currency'].$payout."</td>";
                echo "</tr>";
            }
        }

        public function ShowPages($title){
            //title = privacy_policy / terms_of_use
            $result = $this->db->Query("SELECT * FROM pages where title='$title'");
            while($data = mysqli_fetch_array($result)){
                echo $data['content'];
            }

        }

        public function showAllPayment(){
            $result = $this->db->Query("SELECT * FROM payments ORDER BY id DESC");
            while($data = mysqli_fetch_array($result))  
            {  
                echo "<tr>";
                echo "<td>".$data["id"]."</td>";
                echo "<td>".$data["username"]."</td>";
                echo "<td>".$data["date"]."</td>";
                echo "<td>".$data["method"]."</td>";
                echo "<td>".$this->settings['currency'].$data["amount"]."</td>";
                echo "<td>".$data["status"]."</td>";

                echo "</tr>";
            }  
        }  


    }
?>