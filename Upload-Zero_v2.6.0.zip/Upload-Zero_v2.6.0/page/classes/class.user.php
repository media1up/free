<?php
    class user {
        private $db;
        private $settings;
        private $lang;
        public function __construct(){
            $this->db = new database();
            $this->settings = $_SESSION['app_2'];
            $this->lang = $_SESSION['app_2']['lang'];
        }

        public function login($username,$password){

            $username = Remove_er_sql(strtolower($username));
            $password = Remove_er_sql(strtolower($password));
            
            
            $debug = array();
            if(empty($username)){
                array_push($debug,$this->lang['error_login_9']);
            }
            if(empty($password)){
                array_push($debug,$this->lang['error_login_10']);
            }

            if(count($debug) == 0){
                $password = md5($password);
                $result = $this->db->Query("SELECT * FROM users WHERE username='$username' AND password='$password'");
                $row=mysqli_fetch_array($result);
                $check = mysqli_num_rows($result);
                if($check == 0){
                    array_push($debug,$this->lang['error_login_1']);
                }else{
                    
                    if($row['status'] =='block'){
                        array_push($debug,$this->lang['error_login_12']);
                    }else{
                        //($table_name,$col_name,$value,$where_col,$where_value)
                        $this->db->Update("users",array("login_day","login_day_ip"),array(date("Y-m-d"),get_ip()),"username",$username);
                        //$this->addReport();
                        $this->GetDataUser($username);
                        $this->getDataSet($username);
                        $this->getTypeTraffic($username);
                        
                        $_SESSION['app_2']['login']=true;
                        $_SESSION['app_2']['username'] = $username;
                        //Redirect_Success();
                        Redirect("member/dashboard");
                    }
                    
                }
            }
            return $debug;
        }

        public function register($username,$email,$password,$re_password,$ip){

            $username = Remove_er_sql(strtolower($username));
            $email = Remove_er_sql(strtolower($email));
            $password = Remove_er_sql(strtolower($password));
            $re_password = Remove_er_sql(strtolower($re_password));
            $ref = isset($_SESSION['ref'])?$_SESSION['ref']:"-";

            $debug = array();
            if(empty($username) || strlen($username) < 5) array_push($debug,$this->lang['error_login_3']);
            if(empty($password) || strlen($password) < 5) array_push($debug,$this->lang['error_login_4']);
            if($password != $re_password) array_push($debug,$this->lang['error_login_5']);
            if(empty($email)) array_push($debug,$this->lang['error_login_6']);
            if($this->db->isExists("users","username",$username) == true){
                array_push($debug,$this->lang['error_login_7']);
            }
            if($this->db->isExists("users","email",$email) == true){
                array_push($debug,$this->lang['error_login_8']);
            }

            if(count($debug) == 0){
                $date_ref ="";
                if($ref != "-") $date_ref = date("Y-m-d");
                session_unset();
                session_destroy();
                $password = md5($password);
                $date_reg = date("Y-m-d");
                $col = array("username","password","email","login_day","login_day_ip","reg_ip","reg_day","referral","date");
                $val = array($username,$password,$email,$date_reg,$ip,$ip,$date_reg,$ref,$date_ref);
                $this->db->Insert("users",$col,$val);
            }

            return $debug;
        }

        public function ResetPassword($username,$email){
            if($this->settings['demo'] == false ){
            $username = Remove_er_sql(strtolower($username));
            $email = Remove_er_sql(strtolower($email));
            
            
            $debug = array();
            if(empty($username)){
                array_push($debug,$this->lang['error_login_9']);
            }
            if(empty($email)){
                array_push($debug,$this->lang['error_login_10']);
            }

            if(count($debug) == 0){
                //$password = md5($password);
                $result = $this->db->Query("SELECT * FROM users WHERE username='$username' AND email='$email'");
                $row=mysqli_fetch_array($result);
                $check = mysqli_num_rows($result);
                if($check == 0){
                    array_push($debug,"<center>". $this->lang['error_login_11_0']." '".$username."' ".$this->lang['error_login_11_1']." '".$email."' ".$this->lang['error_login_11_2']."</center>");
                }else{
                    if($row['status'] =='block'){
                        array_push($debug,$this->lang['error_login_12']);
                    }else{
                        //genrate new password 
                        $new_pass    = GenerateALpha(10);
                        $new_pass_md = md5($new_pass);
                        //Update to table users
                        $this->db->Update("users",array("password"),array($new_pass_md),"username",$username);
                        //Send Mail to user 
                        
                        $email_site = $this->settings['Email'];
                        $site = GetDomain($this->settings['HTTP_s']);
                        $url = $this->settings['HTTP_s']."/page/login";//$settings['domain']
                        $site_plus_email = $site . "<noreply@".$site.">";
                        
                        $from = $email; // $email
                        $subject = "Reset your password for ".$site; //$settings['domain']
                        $message = "<p>We recieved a password reset request. </p>";
                        $message .="<p>Your temporary password is: <span style='color:tomato'>".$new_pass."</span></p>";
                        $message .="<p>Please, change your password after you <a href='$url' traget='_blank'>sign in.</a></p>";
                        
                        $headers = "From: ".$site_plus_email." \r\n";
                        $headers .= "Reply-To: ".$email_site." \r\n";
                        $headers .= "MIME-Version: 1.0\r\n";
                        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                        
                        mail($from, $subject, $message, $headers);
                        
                    }
                    
                }
            }
            return $debug;
            }else Alert("This request is disabled into demo mode.","100%");
        }

        public function logout(){
            $_SESSION['app_2']['login']=false;
            session_destroy();
            unset($_SESSION['app_2']['username']);
		    header("location: home");
            exit;
        }

        public function GetDataUser($username){
            $data = array("username","balance_ref","balance","balance_today","balance_month","pending_payment","total_payment","upgrade","upgrade_finish");
            $result = $this->db->Query("SELECT * FROM users WHERE username='$username'");
            $sfa = mysqli_fetch_array($result);
            for($i=0;$i<count($data);$i++){
                $a = $data[$i];
                $_SESSION['app_2'][$a] = $sfa[$a];
            }
            $_SESSION['time'] = time(); 
        }

        public function edit($col_name,$values,$col_val){
            $er = false;$error = array();
            for($i=0;$i<count($values);$i++){
                if($values[$i] != ""){
                    $values[$i] = Remove_er_sql(strtolower($values[$i]));
                }else{
                    $er = true;
                }
            }
            if($er == true) array_push($error,"All fields must be filled");
            else 
            $this->db->Update("users",$col_name,$values,"username",$col_val);

            return $error;
            
        }
        
        public function changePassword($currentP,$password,$newP,$renewP,$username){
            $error = array();
            $currentP = Remove_er_sql($currentP);
            $newE = Remove_er_sql($newP);
            $renewP = Remove_er_sql($renewP);
            if(md5($currentP) == $password){
                if(!empty($username) || strlen($username) >= 5){
                    $newP = md5($newP);
                    $this->db->Update("users",array("password"),array($newP),"username",$username);
                }else{
                    array_push($error,$this->lang['error_login_3']);
                }
            }else{
                array_push($error,$this->lang['error_login_13']);
            }
            return $error;
        }

        public function changeEmail($newE,$renewE,$username){ 
            $error = array();
            $newE = Remove_er_sql(strtolower($newE));
            $renewE = Remove_er_sql(strtolower($renewE));
            if($newE == $renewE && !empty($newE) && !empty($renewE)){
                $this->db->Update("users",array("email"),array($newE),"username",$username);
            }else{
                array_push($error,$this->lang['error_login_14']);
            }
            return $error;
        }

        public function selectInfo($username){
            $result = $this->db->Query("SELECT * FROM users WHERE username='$username'");
            $rows=mysqli_fetch_array($result);
            return $rows;
        }

        public function showPaymentAccount($username){
            $result = $this->db->Query("SELECT * FROM users WHERE username='$username'");
            $rows=mysqli_fetch_array($result);
            return $rows['payment_account'] ." (".$rows['payment_type'].")";
        }

        public function showMethod(){
            $res = $this->db->Query("SELECT * FROM withdraw WHERE status = 'on'");
            while($data = mysqli_fetch_assoc($res)){
                echo "<tr>";
                echo "<td>".$data['method']."</td>";
                echo "<td>".$this->settings['currency'].$data['amount']."</td>";
                echo "</tr>";
            } 
        }

        public function showlistMethod(){
            $res = $this->db->Query("SELECT * FROM withdraw WHERE status = 'on'");
            while($data = mysqli_fetch_assoc($res)){
                $id = $data['method'];
                echo "<option value='$id'>".$data['method']."</option>";
            } 
        }

        public function addPaymentAccount($username,$method,$account){
            $account = Remove_er_sql(strtolower($account));
            if(empty($account)) Alert($this->lang['and_1'],"100%");
            else{
                $this->db->Update("users",array("payment_type","payment_account"),array($method,$account),"username",$username);
                Success($this->lang['and_2'],"100%");
                
            }
        }

        public function getPayment($username){
            $res = $this->db->Query("SELECT * FROM users inner join withdraw 
                                    on users.payment_type=withdraw.method where users.username='$username'");
            $data=mysqli_fetch_array($res);
            if(!empty($data['payment_account'])){
                $t_balance = $data['balance_ref'] + $data['balance'];
                if($data['amount'] <= $t_balance){
                    $col = array("username","date","method","account","balance","ref_balance","amount");
                    $val = array($username,date("Y-m-d h:i:s a"),$data['method'],$data['payment_account'],$data['balance'],$data['balance_ref'],$t_balance);
                    $this->db->Insert("payments",$col,$val);
                    $this->db->Update("users",array("balance_ref","balance"),array("0","0"),"username",$username);
                    $this->db->Incerement("users",array("pending_payment"),array($t_balance),"username",$username);
                    $_SESSION['app_2']['pending_payment'] += $t_balance;
                    $_SESSION['app_2']['balance_ref'] = 0;
                    $_SESSION['app_2']['balance'] = 0;
                }
                else{
                    Alert($this->lang['and_3']." ".$this->settings['currency'].$data['amount'],"100%");
                }
            }
            else{
                Alert($this->lang['and_4'],"100%");
            }


        }

        public function showPayment($username){
            $result = $this->db->Query("SELECT * FROM payments WHERE username='$username' ORDER BY id DESC");
            while($data = mysqli_fetch_array($result))  
            {  
                echo "<tr>";
                echo "<td>".$data["id"]."</td>";
                echo "<td>".$data["date"]."</td>";
                echo "<td>".$data["method"]."</td>";
                echo "<td>".$data["account"]."</td>";
                echo "<td>".$this->settings['currency'].$data["balance"]."</td>";
                echo "<td>".$this->settings['currency'].$data["ref_balance"]."</td>";
                echo "<td>".$this->settings['currency'].$data["amount"]."</td>";
                echo "<td>".$data["status"]."</td>";

                echo "</tr>";
            }  
        }

        public function getPagesReport($username){
            $result = $this->db->Query("SELECT * FROM reports WHERE username='$username'");
            $data = mysqli_fetch_array($result);
            $report =  explode(',',$data["date"]);
            return count($report);
                
        }

        public function reports($username,$page){
            $result = $this->db->Query("SELECT * FROM reports WHERE username='$username'");
            $data = mysqli_fetch_array($result);
            $num_rows = mysqli_num_rows($result);
            $report = array();

            if($num_rows==1){

                for($j=2;$j<8;$j++){
                    $report[] = explode(',',$data[$j]);
                }

                $NumRowToShow = 10;
                $rows = $page * $NumRowToShow;
                $EndRows = count($report[0]) - $rows;
                $startRows = $EndRows + $NumRowToShow;
                $end = GetInt($EndRows);
                if($end == 1) $end =0;
                
                for($i=$startRows-1;$i>=$end;$i--)
                {
                    echo "<tr>";
                    echo "<td>".$report[0][$i]."</td>";                                   //date
                    echo "<td>".$report[1][$i]." / ".$this->settings['currency'].$report[2][$i]."</td>";            //Views-Link
                    echo "<td>".$this->settings['currency'].Show4Num($report[3][$i],4)."</td>";                     //eCPM
                    echo "<td>".$this->settings['currency'].$report[4][$i]."</td>";                               //Referrals
                    echo "<td>".$this->settings['currency'].$report[5][$i]."</td>";                                 //Total
                    echo "</tr>";
                }
            }
        }

        public function getTypeTraffic($username){
            $result = $this->db->Query("SELECT download FROM reports WHERE username='$username'");
            $data = mysqli_fetch_array($result);
            $num_rows = mysqli_num_rows($result);
            $set = array();

            if($num_rows==1){
                $set[] = explode(',',$data["download"]);
                $set[0] = Last_10_Days_Circle($set[0]);
            }

            $_SESSION['app_2']['pieChart0'] = $set[0];

        }

        public function getDataSet($username){
            $result = $this->db->Query("SELECT download FROM reports WHERE username='$username'");
            $data = mysqli_fetch_array($result);
            $num_rows = mysqli_num_rows($result);
            $set = array();

            if($num_rows==1){
                $set[] = explode(',',$data["download"]);
                $set[0] = Last_10_Days_Report($set[0]);
              
            }

            $_SESSION['app_2']['dataset0'] = $set[0];
        }
        
        // Message 
        public function sendMsg($username,$type,$subject,$message){
            if(!empty($subject) && !empty($message)){
                $col = array("username","type","subject","message","date");
                $val = array($username,$type,$subject,$message,date("d-m-Y H:i:s"));
                $this->db->Insert("msg",$col,$val);
                Success($this->lang['and_5'],"100%");
            }
            else{
                Alert($this->lang['and_6'],"100%");
            }
        }

        // Notification
        public function showNotic($username){
            $result = $this->db->Query("SELECT * FROM notification WHERE user='$username' AND status='0' ORDER BY id DESC");
            while($data = mysqli_fetch_array($result)){
                $id = $data['id'];
                echo '<li><a class="app-notification__item" href="#" onclick="show('.$id.')"><span class="app-notification__icon">
                <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-'.$data['color'].'"></i>
                <i class="fa '.$data['icon'].' fa-stack-1x fa-inverse"></i></span></span>';
                echo '<div><p class="app-notification__message">'.$data['title'].'</p>';
                echo '<p class="app-notification__meta">'.get_time_ago($data['date']).'</p>';
                echo '</div></a></li>';
            

            }
        }

        public function countNotic($username){
            $result = $this->db->Query("SELECT * FROM notification WHERE user='$username' AND status='0' ORDER BY id DESC");
            return mysqli_num_rows($result);
        }

        public function showAllNotic($username){
            $result = $this->db->Query("SELECT * FROM notification WHERE user='$username' ORDER BY id DESC");
            $cpt=0;
            while($data = mysqli_fetch_array($result)){
                echo '<div class="timeline-post"><div class="post-media"><a href="#">';
                echo '<div class="content">';
                echo '<h5><a href="#">'.$data['subject'].'</a></h5>';
                echo '<p class="text-muted"><small>'.$data['date'].'</small></p></div></div>';
                echo '<div class="post-content"><p>'.$data['message'].'</p></div></div>';
                $cpt++;
                if($cpt==10) break;
            }
        }

        public function activeNotice($user_notice){
            $this->db->Update("notification",array("status"),array("1"),"id",$user_notice);
        }

        //Reports
        public function addFirstReport($username){
            //download
            //earnings_download
            $col =array("username","date","download","earnings_download","cpm","referrals","total");
            $val =array($username,date("d-m-Y"),"0","0","0","0","0");
            $this->db->Insert("reportsday",$col,$val);
            $val =array($username,getNextDay("-1"),"0","0","0","0","0");
            $this->db->Insert("reports",$col,$val);
        }

        public function updateReportDay($username){
            $col =array("date","download","earnings_download","cpm","referrals","total");
            $val =array(date("d-m-Y"),"0","0","0","0","0");
            $this->db->Update("reportsday",$col,$val,"username",$username);
        }
        
        public function updateNewDay($username){
            $q = $this->db->Query("SELECT * FROM items WHERE title='time_server'");
            $data = mysqli_fetch_array($q);
            $check_date = explode('-',$data['item1']);
            if($check_date[0] != date("d")){
                $this->db->Query("UPDATE users SET balance_today='0'");
                if($check_date[1] != date("m")){
                    $this->db->Query("UPDATE users SET balance_month='0'");
                }
                $d=date("d-m");
                $this->db->Query("UPDATE items SET item1='$d' WHERE title='time_server'");
            }
            
        }

        public function addReport(){
            $q = $this->db->Query("SELECT * FROM items WHERE title='time_server'");
            $data = mysqli_fetch_array($q);
            $check_date = explode('-',$data['item1']);
            if($check_date[0] != date("d")){
                $query = "UPDATE users SET balance_today='0';";
                AddNewReport("2");
                if(date("d") == "15" || date("d") == "28") 
                if($check_date[1] != date("m")){
                    $query .= "UPDATE users SET balance_month='0';";
                }
                $d=date("d-m");
                $dt = date("d-m-Y");

                $query .= "UPDATE items SET item1='$d' WHERE title='time_server';";    
                $query .= "INSERT INTO reportsnonview (date,download,earnings_download,cpm,total) VALUES ('$dt','0','0','0','0');";
                $query .= "INSERT INTO q_country(date,country,qte) SELECT date,country,count(country) as qte FROM visitor GROUP BY country;";
                $query .= "INSERT INTO referre (date,alias,source,country) SELECT date,alias,source,country FROM visitor;";
                $query .= "DELETE FROM visitor";
                
                $this->deleteAllFiles();

                $e = $this->db->Query("SELECT * FROM users WHERE status='on'");
                while($dr = mysqli_fetch_array($e)) {
                    $username = $dr['username'];
                    $upgrade = $dr['upgrade'];
                    if($upgrade != "0"){
                        $upgrade_finish = $dr['upgrade_finish'];
                        $diff_upgrade = dateDiff($dt,$upgrade_finish);
                        if(substr($diff_upgrade,0,1) == "-" ){
                            $col = array("upgrade","upgrade_start","upgrade_finish");
                            $val = array("0","0","0");
                            $this->db->update("users",$col,$val,"username",$username);
                        }
                    }
                    $quer = $this->db->Query("SELECT * FROM reportsday WHERE username='$username'");
                    $data = mysqli_fetch_array($quer);
                    $check_date = $data['date'];
                    $col_name = array("date","download","earnings_download","cpm","referrals","total");
                    $value = array(",".$check_date);
                    for($j=1;$j<count($col_name);$j++){
                        $value[] = ",".$data[$col_name[$j]];
                    }
                    $this->db->IncStr("reports",$col_name,$value,"username",$username);
                    $this->updateReportDay($username);
                }
                $this->db->MultiQuery($query);     
            }
        }

        //Referrals
        public function allReferrals($username){
            $cpt = 1;
            $result = $this->db->Query("SELECT username,referral,date FROM users WHERE referral!='-' AND referral='$username'");
            while($data = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$cpt."</td>";
                echo "<td>".$data['username']."</td>";
                echo "<td>".$data['date']."</td>";

                echo "</tr>";
                $cpt++;
            }
        }

        public function TotalFilesSize($username){
            $total = 0; //GB
            $res = $this->db->Query("SELECT size FROM files where username='$username'");
            while($us = mysqli_fetch_array($res)){
                $ar = explode(' ',$us['size']);
                $type = end($ar);
                if($type == "MB") $total += ($ar[0]/1024);
                elseif($type == "KB") $total += ($ar[0]/1048576);
                elseif($type == "B") $total += ($ar[0]/1073741824);
                
            }

            return round($total,4) . " GB";
        }

        public function delete($id,$username){
            $this->db->Delete("files","id",$id);
            $this->db->Incerement("users",array("total_files"),array(-1),"username",$username);
        }

        public function deleteAllFiles(){
            $result = $this->db->Query("SELECT * FROM files ORDER BY id ASC");
            while($data = mysqli_fetch_array($result)){
                $id             = $data['id'];
                $username       = $data['username'];
                $file           = $data['namefile'];
                $plan           = $data['plan'];
                $last_download  = $data['last_download'];
                $days_to_delete = $this->settings['plans'][$plan]['delete_files'];
                //getError($days_to_delete);

                if($days_to_delete != 0){
                    $date_to_delete = getNextDay($days_to_delete*(-1));
                    $date_to_delete = DateFormat($date_to_delete);
                    $diff = dateDiff($date_to_delete,$last_download);
                    //getError("last".$last_download." date delete:".$date_to_delete. " DIFF:".$diff );
                    
                    if(substr($diff,0,1) == "-" ){
                        $this->db->Delete("files","id",$id);
                        $this->db->Incerement("users",array("total_files"),array(-1),"username",$username);
                        unlink("res/rsc_upload/files/".$file);
                    }
                    
                }

                
            }

        }

        public function addPaymentsPaypal($custom,$amount,$date,$status,$payer_email,$txn_id,$item_name){
            if($this->db->isExists("transaction_plan","txn_id",$txn_id) == false){
                $colu_payment = array("custom","amount","payments_date","payments_status","payer_email","txn_id","item_name");
                $data_payment = array($custom,$amount,$date,$status,$payer_email,$txn_id,$item_name);
                $this->db->Insert("transaction_plan",$colu_payment,$data_payment);
                $date = date("Y-m-d");
                $plan_array = explode('-',$item_name);
                $name = $plan_array[0];
                $time = $plan_array[1];
                if($name =="Plan_Plus") $up = 1;
                elseif($name =="Plan_Pro") $up = 2;
                if($time =="Month") $t="30";
                elseif($time =="Year") $t="365";
                
                $date1=date_create(date("d-m-Y"));
                date_add($date1,date_interval_create_from_date_string("$t days"));
                $finish =  date_format($date1,"d-m-Y");
                $col = array("upgrade","upgrade_start","upgrade_finish");
                $val = array($up,$date,$finish);
                $this->db->Update("users",$col,$val,"username",$custom);

            }
        }

        //Upgrade
        public function Plans($plan){
            $req = $this->db->Query("SELECT * FROM membership_plan WHERE id='$plan'");
            $data = mysqli_fetch_array($req);
            $max_size = $data['max_size'];
            $DaysToDelete = $data['delete_files'];
            if($DaysToDelete == "0") $DaysToDelete = $this->lang['up_7']." </strong>";
            else $DaysToDelete .= $this->lang['up_8']." </strong> ".$this->lang['up_9']."</li>";

            echo '<h6 class="card-price text-center">'.$this->settings['currency'].$data['month'].'<span class="period">/'.$this->lang['up_10'].'</span></h6>
                    <hr>';

            echo '<ul class="fa-ul">';
            echo '<li><span class="fa-li"><i class="fa fa-check"></i></span>'.$this->lang['up_13'].' <strong> '.$max_size.' MB</strong></li>';
            echo '<li><span class="fa-li"><i class="fa fa-check"></i></span>'.$this->lang['up_14'].'</li>';
            echo '<li><span class="fa-li"><i class="fa fa-check"></i></span>'.$this->lang['up_15'].' <strong>x '.$data['cpm'].'</strong></li>';
            echo '<li><span class="fa-li"><i class="fa fa-check"></i></span>'.$this->lang['up_16'].'<br><strong>'.$DaysToDelete;
            
            if($data['remove_ads'] == "No") echo '<li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>'.$this->lang['up_17'].'</li>';
            else echo '<li><span class="fa-li"><i class="fa fa-check"></i></span>'.$this->lang['up_17'].'</li>';
            
            if($data['download_delay'] == "No") echo '<li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>'.$this->lang['up_18'].'</li>';
            else echo '<li><span class="fa-li"><i class="fa fa-check"></i></span>'.$this->lang['up_18'].'</li>';

            if($data['captcha'] == "No") echo '<li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>'.$this->lang['up_19'].'</li>';
            else echo '<li><span class="fa-li"><i class="fa fa-check"></i></span>'.$this->lang['up_19'].'</li>';

            echo '</ul>';

            
            if($plan == "1"){
                echo '
                    <select class="form-control" id="exampleSelect1">
                        <option>'.$this->settings['currency'].'0/'.$this->lang['up_11'].' </option>
                        <option>'.$this->settings['currency'].'0/'.$this->lang['up_12'].' </option>
                    </select>
                ';
            }elseif($plan == "2"){
                echo '
                    <select class="form-control" id="exampleSelect1" name="plan_plus_time">
                        <option>'.$this->settings['currency'].$data['month'].'/'.$this->lang['up_11'].' </option>
                        <option>'.$this->settings['currency'].$data['year'].'/'.$this->lang['up_12'].' </option>
                    </select>
                ';
            }elseif($plan == "3"){
                echo '
                    <select class="form-control" id="exampleSelect1" name="plan_pro_time">
                        <option>'.$this->settings['currency'].$data['month'].'/'.$this->lang['up_11'].' </option>
                        <option>'.$this->settings['currency'].$data['year'].'/'.$this->lang['up_12'].' </option>
                    </select>
                ';
            }
            
        }
        
    }
?>