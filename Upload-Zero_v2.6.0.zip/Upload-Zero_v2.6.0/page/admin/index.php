<?php
ob_start();
session_start();
    include '../functions/gFunction.php';
    include '../functions/aFunction.php';
    include '../classes/class.admin.php';
    include '../classes/class.page.php';
    include '../classes/class.user.php';
    include '../classes/database.php';

    //ini_set('display_errors','off');
    $css="../includes/css/";
    $js="../includes/js/";
    $img = "../image/";

    if(!isset($_SESSION['app_2']['info']))include '../info_site.php';
    $settings = $_SESSION['app_2'];
    

    $debug = array();
    if(isset($_POST['login'])){

        $admin_ = $_POST['admin'];
        $password = $_POST['password'];

        $admin = new Admin();
        $debug = $admin->AdminLogin($admin_,$password);
        
    }

    

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- main.css.php-->
    <link rel="stylesheet" type="text/css" href="<?php echo $css."main.css.php";?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $css."zero.css";?>">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title><?php echo UPPER_1ST_ELEMENT("login");?></title>
  </head>
  <body>
    
    <section class="login-content">
     
      <div class="login-box" style="margin-top: -10%;height:430px">
        <form class="login-form" method="post">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN ADMIN</h3>
          <div class="form-group">
            <label class="control-label">ADMIN</label>
            <input class="form-control" type="text" placeholder="Admin" name="admin" >
            
          </div>
          

          <div class="form-group">
            <label class="control-label">PASSWORD</label>
            <input class="form-control" type="password" placeholder="Password" name="password" >
            
          </div>
          
          <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                <label>
                  <input type="checkbox"><span class="label-text">Stay Signed in</span>
                </label>
              </div>
              
            </div>
            
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block" name ="login" id="error"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
          </div>
          
        </form>
        
      </div>
    </section>
    <!-- Essential javascripts for application to work-->

    <script src="<?php echo $js."jquery-3.2.1.min.js";?>"></script>
    <script src="<?php echo $js."popper.min.js";?>"></script>
    <script src="<?php echo $js."bootstrap.min.js";?>"></script>
    <script src="<?php echo $js."main.js";?>"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo $js."plugins/pace.min.js";?>"></script>
    <!-- Page specific javascripts-->
    <script src="<?php echo $js."plugins/bootstrap-notify.min.js";?>"></script>
    <script src="<?php echo $js."plugins/sweetalert.min.js";?>"></script>
    
    <?php
      if(count($debug) !=0 ){
    ?>
    <script type="text/javascript">
      $('#error').ready(function(){
      	$.notify({
      		title: " Sorry ! you have errors :",
          message: "<?php
          for($i=0;$i<count($debug);$i++){
            echo "<br><span style='padding-left:20px;'>".$debug[$i]."<span>";
          }
          ?>",
      		icon: 'fa fa-exclamation-triangle' 
      	},{
      		type: "danger"
      	});
      });
      </script>
    <?php } ?>
  </body>
</html>