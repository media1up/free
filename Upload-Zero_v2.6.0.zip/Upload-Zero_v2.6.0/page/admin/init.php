<?php
//session 
ob_start();
session_start();
    include '../functions/gFunction.php';
    include '../functions/aFunction.php';
    include '../classes/class.admin.php';
    include '../classes/class.user.php';
    include '../classes/class.page.php';
    include '../classes/class.upload.php';
    include '../classes/database.php';

    //GLOBAL $settings;
    $settings = $_SESSION['app_2'];

    $css="../../includes/css/";
    $js="../../includes/js/";
    $img = "../../image/";

    ini_set('display_errors','off');

    // check admin connected
    if(!isset($_SESSION['app_2']['admin'])){
        header("location: ../index.php");
        exit;
    }else{
        $admin_ = $_SESSION['app_2']['admin'];
    }

    // pages of admin
    $ar_page = array("dashboard" => "dashboard",
                    "reports" => "reports",

                    "users" => "users/all_users",
                    "referrals" => "users/referrals",
                    "view" => "users/view",
                    "edit" => "users/edit",
                    "block" => "users/block_users",
                    "premium" => "users/premium",
                    
                    "campaigns" => "campaigns",
                    "createads" => "createads",
                    "ads" => "ads",
                    "plans" => "plans",
                    "files" => "file_all",
                    "upgrade" => "upgrade",
                    "withdraws" => "withdraws",

                    "Privacy" => "privacy",
                    "Terms" => "terms_of_use",
                    "dmca" => "dmca",
                    "copyright" => "copyright",

                    "transactions" => "transactions",

                    "notification" => "folder/notification",
                    "settings" => "settings",
                    "PagesWithdraw" => "page_Withdraw",
                    
                    "mailbox" => "mailbox"
    );

    if(!isset($_SESSION['app_2']['info']))include '../info_site.php';
    
    

    $admin = new Admin();
    $p = new Pages();
    $p->setSettings();

?>