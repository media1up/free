<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-envelope-o"></i> Mailbox</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3"><a class="mb-2 btn btn-primary btn-block" href="">Compose Mail</a>

      <div class="tile mb-4">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-header" >
                <div id="res">

                    <h4 class="tile-title">Compose Mail</h4>
                    <?php
                      if(isset($_POST['send'])){
                        $from = $_POST['from'];
                        $sub = $_POST['subject'];
                        $msg = $_POST['message'];
                        $admin->sendNotic($from,"Admin sent you a message",$sub,$msg,"fa-envelope","primary");
                      }
                      if(isset($_POST['notice'])){
                        $sub = $_POST['subject'];
                        $msg = $_POST['message'];
                        $admin->sendAnno("New Announcement",$sub,$msg,"fa-bullhorn","info");
                      }
                    ?>
                    <div class="tile-body">
                    <form method="post">
                        <div class="form-group">
                          <input class="form-control" type="text" placeholder="Enter Username" list="users" name="from">
                          <datalist id="users">
                            <?php $admin->selectAllUsers();?>
                          </datalist>
                        </div>

                        <div class="form-group">
                          <input class="form-control" type="text" placeholder="Enter Subject" name="subject">
                        </div>
                        
                        <div class="form-group">
                          <textarea class="form-control" rows="6" placeholder="Enter your Message                                                                   [Send] => Send a message to one user                                          [Notice ] =>Send a message to all users" name="message"></textarea>
                        </div>

                      

                      <div class="tile-footer">
                        <button class="btn btn-primary" type="submit" name="send"><i class="fa fa-fw fa-lg fa-check-circle"></i>Send</button>
                        <button class="btn btn-info" type="submit" name="notice"><i class="fa fa-fw fa-lg fa-check-circle"></i>Notice</button>
                        
                        
                      </div>
                    </form>
                    </div>
        
                </div>
              </div>
            </div>
          </div>
      </div>

        </div>
        <div class="col-md-9">
          <div class="tile">
            <div class="mailbox-controls">
              <div class="animated-checkbox">
                <label>
                  <input type="checkbox"><span class="label-text"></span>
                </label>
              </div>
              <div class="btn-group">
                <form method="post">
                  <button class="btn btn-primary btn-sm" type="submit" name="submit"><i class="fa fa-trash-o"></i></button>
                  <button class="btn btn-primary btn-sm" type="submit"><i class="fa fa-refresh"></i></button>
                
                    
              </div>
            </div>
            <div class="table-responsive mailbox-messages">
              <table class="table table-hover">
                <tbody>
                  <?php
                    $admin->showAllMsg();
                  ?>
                </tbody>
            </form>
                <?php
                      if(isset($_POST['submit'])){
                        
                          $ar = array();
                          foreach($_POST['box'] as $selected){
                              $ar[] = $selected;
                          }
                          $admin->deleteMsg($ar);
                        
                      }
                    ?>
              </table>
            </div>
            <div class="text-right"><span class="text-muted mr-2">Showing 1-15 out of 60</span>
              <div class="btn-group">
                <button class="btn btn-primary btn-sm" type="button"><i class="fa fa-chevron-left"></i></button>
                <button class="btn btn-primary btn-sm" type="button"><i class="fa fa-chevron-right"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

    <script>
      function showMsg(id){
        var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                  document.getElementById("res").innerHTML = this.responseText;
              }
          }
          xmlhttp.open("GET", "../../ajax.php?msg="+id, true);
          xmlhttp.send();
          //alert(id);
      }
      
                  
      
</script>