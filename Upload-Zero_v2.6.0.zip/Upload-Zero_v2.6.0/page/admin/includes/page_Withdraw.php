    
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-upload"></i> Withdrawal Methods</h1>
        </div>
        
    </div>
    <div class="row">
        

        <div class="col-md-4">
            <div class="tile">
                <div class="tile-body">
                <form method="post">
                    <?php
                        if(isset($_POST['submit'])){
                            $p->addMethod($_POST['method'],$_POST['amount']);
                        }

                        if(isset($_POST['delete'])){
                            $p->deleteMethod($_POST['list_withdraw']);
                        }

                    ?>
                   
                    <hr>
                    <div class="form-group">
                        <select class="form-control" name="list_withdraw" >
                            <?php $p->showlistMethod()?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="Method Payments" name="method">
                        <br>
                        <input class="form-control" type="text" placeholder="Amount" name="amount">
                        <hr>
                        <button class="btn btn-primary" type="submit" name="submit" style="width:100%">Add New Method</button>
                        <hr>
                        <button class="btn btn-info" type="submit" name="submi1" style="width:100%">Edit Method</button>
                        <hr>
                        <button class="btn btn-danger" type="submit" name="delete" style="width:100%">Delete Method</button>
                  </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</main>

    