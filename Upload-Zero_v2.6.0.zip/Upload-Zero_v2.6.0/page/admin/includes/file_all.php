<?php 
if(isset($_GET['id']) && isset($_GET['user']) && isset($_GET['file'])){
  $admin->delete($_GET['id'],$_GET['user'],$_GET['file']);
}
?> 
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-upload"></i> Manage Files</h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>File Name</th>
                    <th>Size</th>
                    <th>Uploaded On</th>
                    <th>Last download</th>
                    <th>Download</th>
                    <th>Earnings</th>
                    <th>Options</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                      $admin->showAllFiles();
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</main>
<script>
      

      function Confi(id,file,user) {
          var r = confirm("Are you sure?");
          if (r == true) {
              window.location.href="files&id="+id+"&user="+user+"&file="+file;
          }
      }

      
</script>
    
    