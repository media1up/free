    
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-line-chart"></i> Reports</h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
        
            <div style="float:right">
                <form method="post">
                    <input class="form-control-date" type="date" name="date1">
                    <span> to </span>
                    <input class="form-control-date" type="date" name="date2">
                    <button class="btn btn-primary" style="margin-bottom: 3px;" name="show">Show</button>
                </form>
            </div>
            
            <br><br><br>

            <table class="table table-sm table-hover">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Downloads</th>
                  <th>CPM</th>
                  <th>Referrals</th>
                  <th>Total</th>
                </tr>
              </thead>

              <tbody>
                    <?php
                    if(isset($_POST["show"])){
                        $admin->EarningReports($_POST["date1"],$_POST["date2"]);
                    }else{
                        $admin->EarningReports(getNextDay("-1"),date("d-m-Y"));
                    }
                        
                    ?>
              </tbody>

            </table>
          
          </div>
        </div>
    </div>
</main>

    
    