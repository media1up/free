<?php
if(isset($_GET['pay_id_approve']) && isset($_GET['user']) && isset($_GET['amount'])) $admin->PayApprove($_GET['pay_id_approve'],$_GET['user'],$_GET['amount']);
if(isset($_GET['pay_id_cancel']) && isset($_GET['user']) && isset($_GET['amount']))  $admin->PayCancel($_GET['pay_id_cancel'],$_GET['user'],$_GET['amount']);
if(isset($_GET['pay_id_return']) && isset($_GET['user']) && isset($_GET['amount']))  $admin->PayReturn($_GET['pay_id_return'],$_GET['user'],$_GET['amount']);
?>
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-dollar"></i> Withdraws</h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered " id="sampleTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Date</th>
                    <th>Withdrawal Method</th>
                    <th>Withdrawal Account</th>
                    <th>Publisher Earnings</th>
                    <th>Referral Earnings</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Options</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                        $admin->showAllWithdraws();
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</main>
<script>


    

      function approve(list) {
        var r = confirm("Are you sure?");
          if (r == true) {
              window.location.href="withdraws&pay_id_approve="+list[0]+"&user="+list[1]+"&amount="+list[2];
          }
      }

      function cancel(list) {
          var r = confirm("Are you sure?");
          if (r == true) {
              window.location.href="withdraws&pay_id_cancel="+list[0]+"&user="+list[1]+"&amount="+list[2];
          }
      }
      
      function return100(list) {
          var r = confirm("Are you sure?");
          if (r == true) {
              window.location.href="withdraws&pay_id_return="+list[0]+"&user="+list[1]+"&amount="+list[2];
          }
      }

      


      

     

      
      
</script>
