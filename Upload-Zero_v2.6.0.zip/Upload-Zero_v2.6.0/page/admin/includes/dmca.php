    
<main class="app-content">
    <div class="app-title">
        <div>
          <h1>DMCA </h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
        <?php
            if(isset($_POST['submit'])){
                $admin->UpdatePages("dmca",$_POST['content']);
            }
        ?>
          <div class="tile">
            <div class="tile-body">
                <form method="post">
                    <div class="form-group" >
                        <textarea class="form-control"  rows="10" name="content"><?php echo $admin->ShowPages("dmca")?></textarea>
                        
                    </div>

                    <div class="tile-footer">
                    <p>don't add this char ( ' ) and use this tool => https://html-online.com/editor/</p>
                        <button class="btn btn-primary" type="submit" name="submit">Save</button>
                    </div>
                </form>
              
            </div>
          </div>
        </div>
    </div>
</main>

    
    