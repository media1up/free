
<?php
  $count_notice = $admin->countNotic_admin($admin_);
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <title><?php echo UPPER_1ST_ELEMENT($page);?></title>
    <?php $nav = Active_nav_admin($page);?>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- main.css.php-->
    <link rel="stylesheet" type="text/css" href="<?php echo $css."main.css.php";?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $css."zero.css";?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $css."component.css";?>"> 
    
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
    <script>
      function show(id){
        var xmlhttp = new XMLHttpRequest();
          xmlhttp.open("GET", "../../ajax.php?notice_admin="+id, true);
          xmlhttp.send();
          window.location.href="notification";
      }
    </script>
</head>
<body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="index.html"><?php echo $settings['SiteName']?></a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!--Notification Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Show notifications"><i class="fa fa-bell-o fa-lg"></i>
          <?php
            if($count_notice != 0){
              echo '<span class="badge badge-pill badge-danger">'.$count_notice.'</span>';
            }
          ?>
        </a>
          <ul class="app-notification dropdown-menu dropdown-menu-right">
            <li class="app-notification__title">You have <?php echo $count_notice;?> new notifications.</li>
            <div class="app-notification__content">
              <?php 
                $admin->showNotic_admin($admin_);
              ?>
              
            </div>
            <li class="app-notification__footer"><a href="notification">See all notifications.</a></li>
          </ul>
        </li>
        
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="settings"><i class="fa fa-cog fa-lg"></i> Settings</a></li>
            <li><a class="dropdown-item" href="logout"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>




    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="<?php echo $img."user1.png";?>" width="48"  alt="User Image">
        <div>
          <p class="app-sidebar__user-name">Admin Panel</p>
          <p class="app-sidebar__user-designation"><?php echo $admin_;?></p>
        </div>
      </div>
      <ul class="app-menu">

        <!-- Dashboard-->
        <li><a class="app-menu__item <?php echo $nav[0];?>" href="dashboard"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>

        <!-- Earnings Reports-->
        <li><a class="app-menu__item <?php echo $nav[10];?>" href="reports"><i class="app-menu__icon fa fa-line-chart"></i><span class="app-menu__label">Earnings Reports</span></a></li>
        

        <!-- MAnager Users-->
        <li class="treeview"><a class="app-menu__item <?php echo $nav[1];?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Users</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="users"> List</a></li>
            <li><a class="treeview-item" href="referrals"> Referrals</a></li>
            <li><a class="treeview-item" href="block"> Block Users</a></li>
            <li><a class="treeview-item" href="premium"> Premium Users</a></li>

          </ul>
        </li>

        <!-- Manager Campaigns-->
        <li class="treeview"><a class="app-menu__item <?php echo $nav[2];?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-bullhorn"></i><span class="app-menu__label">Campaigns</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="campaigns">List</a></li>
            <li><a class="treeview-item" href="createads"> Create banner</a></li>
          </ul>
        </li>

        

        <!-- Plans-->
        <li><a class="app-menu__item <?php echo $nav[12];?>" href="plans"><i class="app-menu__icon fa fa-pencil-square-o"></i><span class="app-menu__label">Membership Plans</span></a></li>

        <!-- Price ADS-->
        <li><a class="app-menu__item <?php echo $nav[3];?>" href="ads"><i class="app-menu__icon fa fa-database"></i><span class="app-menu__label">Manage Rates</span></a></li>

        <!-- Manager Links-->
        <li><a class="app-menu__item <?php echo $nav[4];?>" href="files"><i class="app-menu__icon fa fa-upload"></i><span class="app-menu__label">Manage Files</span></a></li>
        
        <!-- withdraws-->
        <li><a class="app-menu__item <?php echo $nav[6];?>" href="withdraws"><i class="app-menu__icon fa fa-dollar"></i><span class="app-menu__label">Withdraws</span></a></li>

         <!--Pages-->
        <li class="treeview"><a class="app-menu__item <?php echo $nav[11];?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-book"></i><span class="app-menu__label">Pages</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="Privacy">Privacy Policy</a></li>
            <li><a class="treeview-item" href="Terms">Terms of Use</a></li>
            <li><a class="treeview-item" href="dmca">DMCA</a></li>
            <li><a class="treeview-item" href="copyright">Copyright Policy</a></li>
          </ul>
        </li>

        <!-- transactions-->
        <li><a class="app-menu__item <?php echo $nav[13];?>" href="transactions"><i class="app-menu__icon fa fa-play"></i><span class="app-menu__label">Transactions</span></a></li>

        <!-- Settings-->
        <li class="treeview"><a class="app-menu__item <?php echo $nav[7];?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-cog"></i><span class="app-menu__label">Settings</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="settings"> Settings</a></li>
            <li><a class="treeview-item" href="PagesWithdraw"> Withdrawal Methods</a></li>
          </ul>
        </li>

        <!-- Store
        <li><a class="app-menu__item <?php //echo $nav[8];?>" href="store"><i class="app-menu__icon fa fa-cart-plus"></i><span class="app-menu__label">Store</span></a></li>-->

        <!-- Mail Box-->
        <li><a class="app-menu__item <?php echo $nav[9];?>" href="mailbox"><i class="app-menu__icon fa fa-envelope"></i><span class="app-menu__label">MailBox</span></a></li>

        
      </ul>
    </aside>
    