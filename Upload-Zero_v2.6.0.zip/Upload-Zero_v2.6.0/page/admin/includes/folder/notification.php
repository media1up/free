
    <main class="app-content">
      <div class="row user">
        <div class="col-md-12">
          <div class="tab-content">
            <div class="tab-pane active" id="user-timeline">
              <?php $admin->showAllNotic_admin($admin_)?>
            </div>            
          </div>
        </div>
      </div>
    </main>
    
