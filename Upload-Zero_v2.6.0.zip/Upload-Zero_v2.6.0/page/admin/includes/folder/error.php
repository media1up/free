<main class="app-content">
<div class="app-title">
        <div>
            <h1>Page Not Found</h1>
        </div>
        
      </div>
    <h1>Page Not Found</h1>
</main>