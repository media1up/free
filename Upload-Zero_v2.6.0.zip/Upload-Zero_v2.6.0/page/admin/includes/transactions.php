<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-play"></i> Transactions</h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered " id="sampleTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Plan</th>
                    <th>Transaction ID</th>
                    <th>Payment Account</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                        $admin->Transactions();
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</main>

