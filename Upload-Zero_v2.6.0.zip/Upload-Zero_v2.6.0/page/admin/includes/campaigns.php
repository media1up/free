<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-bullhorn"></i>  Campaigns</h1>
        </div>
        
    </div>

    <div class="row">
    <?php if(isset($_GET['active'])) $admin->activeCampaign($_GET['active']);
      if(isset($_GET['delete']) && isset($_GET['banner'])) $admin->DeleteCampaign($_GET['delete'],$_GET['banner']);
      if(isset($_GET['inactive'])) $admin->InactiveCampaign($_GET['inactive']);    
    ?>
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Website URL</th>
                    <th>Impressions</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                        $admin->AllCampaign();
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</main>
<script>
      

      function active(id) {
          var r = confirm("Are you sure?");
          if (r == true) {
              window.location.href="campaigns&active="+id;
          }
      }

      function inactive(id) {
          var r = confirm("Are you sure?");
          if (r == true) {
              window.location.href="campaigns&inactive="+id;
          }
      }

      function dlt(id,banner) {
          var r = confirm("Are you sure?");
          if (r == true) {
              window.location.href="campaigns&delete="+id+"&banner="+banner;
          }
      }
      
</script>
    
    