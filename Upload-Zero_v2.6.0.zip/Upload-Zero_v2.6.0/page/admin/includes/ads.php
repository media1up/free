    
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-upload"></i> Manage Rates</h1>
        </div>
    
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <form method="post">
                <table class="table table-hover table-bordered" id="sampleTable1">
                    <thead>
                      <tr>
    
                        <th>#</th>
                        <th>Code</th>
                        <th>Country</th>
                        <th>Cost 1000 Download</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $ids = $admin->showAllADS(); ?>
                    </tbody>
                </table>
                <button class='btn btn-info btn-sm' type='submit' name='btn-ss'>Update</button>
                
                <?php if(isset($_POST['btn-ss']))$admin->updateADS($ids);?>
              </form>
            </div>
          </div>
          

        </div>
    </div>
</main>
<script>
      

   
      
</script>
    
    