<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-bullhorn"></i> Create New Campaign</h1>
        </div>
        
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="row">
              <div class="col-lg-12">
                <form method="post" enctype="multipart/form-data">

            <h4>Step 1 Campaign Details </h4>
            
            <hr>
            <?php
                    if(isset($_POST['submit'])){
                        
                        $name = $_POST['name'];
                        $type = $_POST['type'];
                        $url = $_POST['url'];

                        //$file = array();
                        $file1 = $_FILES['file_banner']['name'];
                        $file2 = $_FILES['file_banner']['tmp_name'];
                        
                        $code = $_POST['code'];

                        $admin->CreateCampaign($name,$type,$url,$file1,$file2,$code);
  
                    }
                ?>
                <!-- CAMPAIGN NAME  -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Campaign Name</label>
                    <input class="form-control"  type="text" placeholder="Provide your campaign name" name="name">
                </div>

                
                <div class="form-group">
                    <label>type</label>
                    <select class="form-control" name="type">
                        <option values="visitor">Visitor</option>
                        <option values="member">Member Area ad</option>
                    </select>
                </div>

            <br>
            
            <h4>Step 2 Ad / Banner </h4>
            <hr>


                
                <div class="form-group">
                    <label for="exampleInputPassword1">Landing Url</label>
                    <input class="form-control" id="url" type="url" value="http://example.com" name="url">
                </div>
            
            <div>
                <div class="form-group" >
                    <label for="exampleInputPassword1">Upload Banner</label>
                    <input class="form-control" type="file" name="file_banner">
                </div>

                <label for="exampleTextarea"  >OR :</label>

                <div class="form-group" >
                    <label for="exampleTextarea">Html/js</label>
                    <textarea class="form-control"  rows="4" name="code"></textarea>
                </div>
            </div>

                

                
                
                <div class="tile-footer">
                    <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                </div>
                
                

                  
                  
                  
                </form>
              </div>
              
            </div>
            
          </div>
        </div>
      </div>
    </main>

    


