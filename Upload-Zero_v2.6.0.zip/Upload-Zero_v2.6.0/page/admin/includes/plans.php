
    <main class="app-content">
    <?php
    
        if(isset($_POST['submit_free'])){
            $admin->UpdatePlans("1");
        }

        if(isset($_POST['submit_plus'])){
            $admin->UpdatePlans("2");
        }

        if(isset($_POST['submit_pro'])){
            $admin->UpdatePlans("3");
        }


    ?>
   
      <div class="row user">
        <div class="col-md-3">
          <div class="tile p-0">
            <ul class="nav flex-column nav-tabs user-tabs">
              <li class="nav-item"><a class="nav-link active" href="#free" data-toggle="tab">Free</a></li>
              <li class="nav-item"><a class="nav-link" href="#plus" data-toggle="tab">Plus</a></li>
              <li class="nav-item"><a class="nav-link" href="#pro" data-toggle="tab">Pro</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-9">
          <div class="tab-content">

            <div class="tab-pane active" id="free">
                <div class="tile user-settings">
                    <h4 class="line-head">Free</h4>
                    <?php $free = $admin->Plans("1");?>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label>Monthly Price</label>
                                <input class="form-control" type="text" value="0" disabled>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Yearly Price</label>
                                <input class="form-control" type="text" value="0" disabled>
                            </div>
                            

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Max Upload Size (MB)</label>
                                <input class="form-control" type="text" name="max_size_f" value="<?php echo $free['max_size']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Earnings per 1000 Downloads x ?</label>
                                <input class="form-control" type="text" name="cpm_f" value="<?php echo $free['cpm']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Delete files that haven't been downloaded in the last <?php echo $free['delete_files']?> days</label>
                                <input class="form-control" type="text" name="delete_files_f" value="<?php echo $free['delete_files']?>">
                                <label>0 = NEVER</label>
                            </div>

                            

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Ads</label>
                                <select class="form-control" id="exampleSelect1" name="remove_ads_f">
                                        <option><?php echo $free['remove_ads']?></option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Download Delay</label>
                                <select class="form-control" id="exampleSelect1" name="download_delay_f">
                                        <option><?php echo $free['download_delay']?></option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Captcha</label>
                                <select class="form-control" id="exampleSelect1" name="captcha_f">
                                        <option><?php echo $free['captcha']?></option >
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            

                            
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-6">
                            <button class="btn btn-primary" type="submit" name="submit_free"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane" id="plus">
                <div class="tile user-settings">
                    <h4 class="line-head">Plus</h4>
                    <?php $plus = $admin->Plans("2");?>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label>Monthly Price</label>
                                <input class="form-control" type="text" name="month_p" value="<?php echo $plus['month']?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Yearly Price</label>
                                <input class="form-control" type="text" name="year_p" value="<?php echo $plus['year']?>">
                            </div>
                            

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Max Upload Size (MB)</label>
                                <input class="form-control" type="text" name="max_size_p" value="<?php echo $plus['max_size']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Earnings per 1000 Downloads x ?</label>
                                <input class="form-control" type="text" name="cpm_p" value="<?php echo $plus['cpm']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Delete files that haven't been downloaded in the last <?php echo $plus['delete_files']?> days</label>
                                <input class="form-control" type="text" name="delete_files_p" value="<?php echo $plus['delete_files']?>">
                                <label>0 = NEVER</label>
                            </div>

                            

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Ads</label>
                                <select class="form-control" id="exampleSelect1" name="remove_ads_p">
                                        <option><?php echo $plus['remove_ads']?></option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Download Delay</label>
                                <select class="form-control" id="exampleSelect1" name="download_delay_p">
                                        <option><?php echo $plus['download_delay']?></option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Captcha</label>
                                <select class="form-control" id="exampleSelect1" name="captcha_p">
                                        <option><?php echo $plus['captcha']?></option >
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>
                                </select>
                            </div>

                            

                            
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-6">
                            <button class="btn btn-primary" type="submit" name="submit_plus"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane" id="pro">
                <div class="tile user-settings">
                    <h4 class="line-head">Pro</h4>
                    <?php $pro = $admin->Plans("3");?>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label>Monthly Price</label>
                                <input class="form-control" type="text" name="month_pr" value="<?php echo $pro['month']?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Yearly Price</label>
                                <input class="form-control" type="text" name="year_pr" value="<?php echo $pro['year']?>">
                            </div>
                            

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Max Upload Size (MB)</label>
                                <input class="form-control" type="text" name="max_size_pr" value="<?php echo $pro['max_size']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Earnings per 1000 Downloads x ?</label>
                                <input class="form-control" type="text" name="cpm_pr" value="<?php echo $pro['cpm']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Delete files that haven't been downloaded in the last <?php echo $pro['delete_files']?> days</label>
                                <input class="form-control" type="text" name="delete_files_pr" value="<?php echo $pro['delete_files']?>">
                                <label>0 = NEVER</label>
                            </div>

                            

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Ads</label>
                                <select class="form-control" id="exampleSelect1" name="remove_ads_pr">
                                        <option><?php echo $pro['remove_ads']?></option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Download Delay</label>
                                <select class="form-control" id="exampleSelect1" name="download_delay_pr">
                                        <option><?php echo $pro['download_delay']?></option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-6 mb-4">
                                <label>Remove Captcha</label>
                                <select class="form-control" id="exampleSelect1" name="captcha_pr">
                                        <option><?php echo $pro['captcha']?></option >
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                </select>
                            </div>

                            

                            
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-6">
                            <button class="btn btn-primary" type="submit" name="submit_pro"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

           
          
        
        </div>
        </div>
      </div>
    </main>

    <script src="../includes/js/jquery-3.2.1.min.js"></script>
    <script src="../includes/js/popper.min.js"></script>
    <script src="../includes/js/bootstrap.min.js"></script>
    <script src="../includes/js/main.js"></script>
    <script src="../includes/js/plugins/pace.min.js"></script>
    <script src="../includes/js/plugins/bootstrap-notify.min.js"></script>
	<script src="../includes/js/plugins/sweetalert.min.js"></script>
    