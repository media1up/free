
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i> <?php echo UPPER_1ST_ELEMENT($page);?></h1>
    </div>
    
  </div>
  
  <div class="row">
    <div class="col-md-6 col-lg-3">
      <div class="widget-small danger coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
        <div class="info" >
        <b style="font-size:20px"><?php echo $settings['currency'].$admin->showStatic('balance_today')?> </b>
          <p><b>Publisher Earnings - Today</b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small warning coloured-icon"><i class="icon fa fa-suitcase fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $settings['currency']. $admin->showStatic('balance_month')?> </b>
          <p><b>Publisher Earnings ( <?php echo date("M");?> )</b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small primary coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
        <div class="info">
        <b style="font-size:20px"><?php echo $settings['currency'].$admin->showStatic('balance')?> </b>
          <p><b>Publisher Earnings - Total</b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small info coloured-icon"><i class="icon fa fa-exchange fa-3x"></i>
        <div class="info">
        <b style="font-size:20px"><?php echo $settings['currency'].$admin->showStatic('balance_ref')?> </b>
          <p><b>Referral Earnings</b></p>
          
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-3">
      <div class="widget-small danger coloured-icon"><i class="icon fa fa-download fa-3x"></i>
        <div class="info" >
        <b style="font-size:20px"><?php echo $settings['tDownloads']?></b>
          <p><b>Total Downloads</b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small warning coloured-icon"><i class="icon fa fa-file fa-3x"></i>
        <div class="info">
          <b style="font-size:20px"><?php echo $settings['tFiles']?></b>
          <p><b>Total Files</b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small primary coloured-icon"><i class="icon fa fa-download fa-3x"></i>
        <div class="info">
        <b style="font-size:20px"><?php echo $admin->showStaticPro('download','reportsday')?></b>
          <p><b>Total Downloads Today</b></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="widget-small info coloured-icon"><i class="icon fa fa-pie-chart fa-3x"></i>
        <div class="info">
        <b style="font-size:20px"><?php echo $admin->TotalFilesSize()?></b>
          <p><b>Total File Size</b></p>
          
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title">Last 10 days</h3>
        <div class="embed-responsive embed-responsive-16by9">
          <canvas class="embed-responsive-item" id="lineChartDemo"></canvas>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title">Top 5 Countries - This Month</h3>
        <div class="embed-responsive embed-responsive-16by9">
          <canvas class="embed-responsive-item" id="pieChartDemo"></canvas>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
  <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Reports</h3>
            <div class="table-responsive">
              <table class="table">
              <thead>
                  <tr>
                    <th>date</th>
                    <th>Downloads</th>
                    <th>eCPM</th>
                    <th>Referrals</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody id="txtHint">

                  <script>
                    function report(p){
                      var xmlhttp = new XMLHttpRequest();
                        xmlhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("txtHint").innerHTML = this.responseText;
                            }
                        }
                        xmlhttp.open("GET", "../../ajax.php?p_admin="+p, true);
                        xmlhttp.send();
                    }
                      report(1);
                  </script>
                </tbody>
                </table>
                <div id="n"></div>

                <script>
                  function pagi(p){
                    var xmlhttp = new XMLHttpRequest();
                      xmlhttp.onreadystatechange = function() {
                          if (this.readyState == 4 && this.status == 200) {
                              document.getElementById("n").innerHTML = this.responseText;
                          }
                      }
                      xmlhttp.open("GET", "../../ajax.php?n_admin="+p, true);
                      xmlhttp.send();
                  }
                    pagi(1);
                </script>
            </div>
          </div>
        </div>
  </div>
</main>
