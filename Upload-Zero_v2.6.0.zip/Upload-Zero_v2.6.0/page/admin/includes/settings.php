
    <main class="app-content">
    <?php
        if(isset($_POST['submit_General'])){
            $array_items = array($_POST['SiteName'],$_POST['SiteMetaTitle'],$_POST['Keywords'],$_POST['Des'],$_POST['chance'],$_POST['VisitPerIpParDay']
                            ,$_POST['Email'],$_POST['DurationSkipLink'],$_POST['HTTP_s'],$_POST['ReferralRate'],$_POST['AllowAdBlock'],$_POST['ShowAllFiles'],$_POST['currency']);
            $admin->EditGeneral();
        }

        if(isset($_POST['submit_design'])){
            $admin->EditDesign();
        }

        if(isset($_POST['submit_Captcha'])){
            $array_items = array($_POST['captcha'],$_POST['CaptchaSiteKey'],$_POST['CaptchaSecretKey']);
            $admin->EditCaptcha();
        }

        if(isset($_POST['submit_upgrade'])){
            $array_items = array($_POST['paypal']);
            $admin->EditUpgrade();
        }

        if(isset($_POST['submit_SocialMedia'])){
            $array_items = array($_POST['Facebook'],$_POST['Youtube'],$_POST['Twitter'],$_POST['GooglePlus']);
            $admin->EditSocialMedia();
        }

        if(isset($_POST['submit_new_admin'])){
            $admin->newAdmin($_POST['admin'],$_POST['pass1'],$_POST['pass2']);
        }


    ?>
   
      <div class="row user">
        <div class="col-md-3">
          <div class="tile p-0">
            <ul class="nav flex-column nav-tabs user-tabs">
              <li class="nav-item"><a class="nav-link active" href="#General" data-toggle="tab">General</a></li>
              <li class="nav-item"><a class="nav-link" href="#Design" data-toggle="tab">Design</a></li>
              <li class="nav-item"><a class="nav-link" href="#Captcha" data-toggle="tab">Captcha</a></li>
              <li class="nav-item"><a class="nav-link" href="#upgrade" data-toggle="tab">Upgrade</a></li>
              <li class="nav-item"><a class="nav-link" href="#SocialMedia" data-toggle="tab">Social Media</a></li>
              <li class="nav-item"><a class="nav-link" href="#NewAdmin" data-toggle="tab">New Admin</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-9">
          <div class="tab-content">
            <div class="tab-pane active" id="General">
                <div class="tile user-settings">
                    <h4 class="line-head">General</h4>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <label>Site Name</label>
                                <input class="form-control" type="text" name="SiteName" value="<?php echo $settings['SiteName']?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Site Meta Title</label>
                                <input class="form-control" type="text" name="SiteMetaTitle" value="<?php echo $settings['SiteMetaTitle']?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Keywords</label>
                                <input class="form-control" type="text" name="Keywords" value="<?php echo $settings['Keywords']?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Site Description</label>
                                <textarea class="form-control" type="text" name="Des" ><?php echo $settings['Des']?></textarea>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Main Domain</label>
                                <input class="form-control" type="text" name="HTTP_s" value="<?php echo $settings['HTTP_s']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Show All Files </label>
                                <select class="form-control" id="exampleSelect1" name="ShowAllFiles">
                                        <option><?php echo $settings['ShowAllFiles']?></option>
                                        <option value="yes">Yes (All files without users) </option>
                                        <option value="no">No (just users files)</option>
                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>The success rate of the download <?php SuccesRateLink($settings['chance'])?></label>
                                <input class="form-control" type="number" min="50" max="100" name="chance" value="<?php echo $settings['chance']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>The number of downloads per IP par day</label>
                                <input class="form-control" type="text" name="VisitPerIpParDay" value="<?php echo $settings['VisitPerIpParDay']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Duration to skip the link</label>
                                <input class="form-control" type="text" name="DurationSkipLink" value="<?php echo $settings['DurationSkipLink']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Allow AdBlock</label>
                                <select class="form-control" id="exampleSelect1" name="AllowAdBlock">
                                        <option><?php echo $settings['AllowAdBlock']?></option>
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>

                                </select>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Referral Percentage</label>
                                <input class="form-control" type="text" name="ReferralRate" value="<?php echo $settings['ReferralRate']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Currency</label>
                                <input class="form-control" type="text" name="currency" value="<?php echo $settings['currency']?>">
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Email</label>
                                <input class="form-control" type="text" name="Email" value="<?php echo $settings['Email']?>">
                            </div>

                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_General"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane pade" id="Design">
                <div class="tile user-settings">
                    <h4 class="line-head">Design</h4>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <label>Theme</label>
                                <select class="form-control" id="exampleSelect1" name="theme">
                                    <option value="<?php echo $settings['theme']?>">Current : <?php echo $settings['theme']?></option>
                                    <?php
                                    $dir    = '../../res/themes/';
                                    $files = scandir($dir);
                                    for($i=0;$i<count($files);$i++){
                                        if($files[$i] !='.' && $files[$i] != '..'){
                                            echo $folder = "<option value='".$files[$i]."'>".$files[$i]."</option>";
                                        }
                                    }
                                    ?>
                                </select>
                                 Add new<a href="https://ayelscripts.com/marketplace-category?c=2&s=Upload-Zero" target="_blank"> Theme</a>
                            </div>
                            
                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Design</label>
                                <select class="form-control" id="exampleSelect1" name="Design">
                                        <option><?php echo $settings['Design']?></option>
                                        <option value="blue">Blue</option>
                                        <option value="red">Red</option>
                                        <option value="grey">Grey</option>
                                        <option value="yellow">Yellow</option>
                                        <option value="green">Green</option>
                                        <option value="light green">Light Green</option>
                                </select>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Background</label>
                                <input class="form-control" type="text" name="Background" value="<?php echo $settings['Background']?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Favicon URL</label>
                                <input class="form-control" type="text" name="favicon" value="<?php echo $settings['favicon']?>">
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Active Logo</label>
                                <select class="form-control" name="logo_active">
                                    <option><?php echo $settings['logo_active']?></option>
                                    <option value="yes">Yes</option>
                                    <option value="no">No</option>
                                </select>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>Logo</label>
                                <input class="form-control" type="text" name="logo" value="<?php echo $settings['logo']?>">
                            </div>
                            
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_design"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane pade" id="Captcha">
                <div class="tile user-settings">
                    <h4 class="line-head">reCAPTCHA Settings</h4>
                    <form method="post">
                        <div class="row">

                            <div class="col-md-12 mb-4">
                                <label>Enable Captcha</label>
                                <select class="form-control" id="exampleSelect1" name="Captcha">
                                        <option><?php echo $settings['Captcha']?></option>
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
                                </select>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>reCAPTCHA Site key</label>
                                <input class="form-control" type="text" name="CaptchaSiteKey" value="<?php echo $settings['CaptchaSiteKey']?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 mb-4">
                                <label>reCAPTCHA Secret key</label>
                                <input class="form-control" type="text" name="CaptchaSecretKey" value="<?php echo $settings['CaptchaSecretKey']?>">
                            </div>
                            
                            
                            
                            
                           
                            <div class="clearfix"></div>
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_Captcha"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane pade" id="upgrade">
                <div class="tile user-settings">
                    <h4 class="line-head">Upgrade Settings</h4>
                    <form method="post">
                        <div class="row">

                            <div class="col-md-12 mb-4">
                                <label>You PayPal IPN:</label>
                                <input class="form-control" type="text" name="CaptchaSiteKey" value="<?php echo $settings['HTTP_s']."/page/payments/paypal_ipn.php"?>" disabled>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Enable PayPal</label>
                                <select class="form-control" id="exampleSelect1" name="">
                                        <option value="yes">Yes</option>
                                </select>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Payment Business Email (PayPal) </label>
                                <input class="form-control" type="text" name="paypal" value="<?php echo $settings['paypal']?>">
                            </div>
                           
                            <div class="clearfix"></div>
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_upgrade"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane pade" id="SocialMedia">
                <div class="tile user-settings">
                    <h4 class="line-head">Social Media</h4>
                    <form method="post">
                        <div class="row">

                            
                            <div class="col-md-12 mb-4">
                                <label>Facebook Page URL</label>
                                <input class="form-control" type="text" name="Facebook" value="<?php echo $settings['Facebook']?>">
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Youtube Channel URL</label>
                                <input class="form-control" type="text" name="Youtube" value="<?php echo $settings['Youtube']?>">
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Twitter Profile URL</label>
                                <input class="form-control" type="text" name="Twitter" value="<?php echo $settings['Twitter']?>">
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Google Plus URL</label>
                                <input class="form-control" type="text" name="GooglePlus" value="<?php echo $settings['GooglePlus']?>">
                            </div>
                            
                            
                            
                            
                           
                            <div class="clearfix"></div>
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_SocialMedia"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>

            <div class="tab-pane pade" id="NewAdmin">
                <div class="tile user-settings">
                    <h4 class="line-head">Add New Admin</h4>
                    <form method="post">
                        <div class="row">

                            
                            <div class="col-md-12 mb-4">
                                <label>admin</label>
                                <input class="form-control" type="text" name="admin" >
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Password</label>
                                <input class="form-control" type="password" name="pass1" >
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12 mb-4">
                                <label>Re-Password</label>
                                <input class="form-control" type="password" name="pass2" >
                            </div>

                            <div class="clearfix"></div>
                        </div>
                        <div class="row mb-10">
                            <div class="col-md-12">
                            <button class="btn btn-primary" type="submit" name="submit_new_admin"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>
          
        
        </div>
        </div>
      </div>
    </main>

    <script src="../includes/js/jquery-3.2.1.min.js"></script>
    <script src="../includes/js/popper.min.js"></script>
    <script src="../includes/js/bootstrap.min.js"></script>
    <script src="../includes/js/main.js"></script>
    <script src="../includes/js/plugins/pace.min.js"></script>
    <script src="../includes/js/plugins/bootstrap-notify.min.js"></script>
	<script src="../includes/js/plugins/sweetalert.min.js"></script>
    