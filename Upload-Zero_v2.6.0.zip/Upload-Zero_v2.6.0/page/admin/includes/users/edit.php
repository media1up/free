<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-user"></i> Edit User</h1>
        </div>
        
    </div>
    <?php
      if(isset($_POST['submit'])){
        $data = array($_POST['email'],$_POST['balance_ref'],$_POST['balance'],$_POST['balance_today'],$_POST['balance_month'],$_POST['plan'],$_POST['expiration']);
        $admin->EditUser($_GET['id'],$data);
      }
    ?>
    <div class="row">
        <div class="col-md-12">
            <form method="post">
              <div class="tile">
                  <?php $admin->showEditUser($_GET['id']);?>
              </div>
            </form>
        </div>
    </div>
</main>