    
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-user"></i> All Referrals</h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Referred By</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                      $admin->allReferrals();
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</main>
<script>
      

      function block(id) {
          var r = confirm("Are you sure?");
          if (r == true) {
              var xhttp = new XMLHttpRequest();
              xhttp.open("GET", "../../ajax.php?blockuser="+id, true);
              xhttp.send();
              window.location.href=window.location.href;
          }
      }

      function dlt(id) {
          var r = confirm("Are you sure?");
          if (r == true) {
              var xhttp = new XMLHttpRequest();
              xhttp.open("GET", "../../ajax.php?dltuser="+id, true);
              xhttp.send();
              window.location.href=window.location.href;
          }
      }
      
</script>
    
    