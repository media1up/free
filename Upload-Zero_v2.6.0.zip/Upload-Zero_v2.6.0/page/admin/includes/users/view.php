    
<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-user"></i> View User</h1>
        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
          <div class="tile">
              <?php $admin->showUser($_GET['id']);?>
            </table>
          </div>
        </div>
    </div>
</main>

    
    