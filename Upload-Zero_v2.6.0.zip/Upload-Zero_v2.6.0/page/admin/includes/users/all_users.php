

<main class="app-content">
    <div class="app-title">
        <div>
          <h1><i class="fa fa-user"></i> Manage Users</h1>
        </div>
        
    </div>
    <div class="row">
    <?php if(isset($_GET['activeuser']))$admin->ActiveUser($_GET['activeuser']);
      if(isset($_GET['dlt_user'])) $admin->deleteUser($_GET['dlt_user']);
    ?>
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Balance</th>
                    <th>Earnings Today</th>
                    <th>Last Login</th>
                    <th>Login IP</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                      $admin->showAllUsers();
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</main>

    
    