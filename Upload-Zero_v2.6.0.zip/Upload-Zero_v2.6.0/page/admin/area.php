<?php
 include 'init.php';
 $page = isset($_GET['page']) ? $_GET['page'] : "Error";
 include 'includes/folder/header.php';

    if(array_key_exists($page,$ar_page)){
        include 'includes/'.$ar_page[$page].'.php';
    }else{
        if($page == "logout"){
            $admin->logout();
        }
        include 'includes/folder/error.php';
    }
    


    
 



 include 'includes/folder/script.php';
 ?>