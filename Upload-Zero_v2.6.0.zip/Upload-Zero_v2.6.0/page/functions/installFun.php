<?php
function ActiveRates($db){
    $test = $db->Query("SELECT * FROM rates");
    $rows = mysqli_num_rows($test);
    if($rows == 0){
        $countryList = array(
            'AF' => 'Afghanistan',
            'AX' => 'Aland Islands',
            'AL' => 'Albania',
            'DZ' => 'Algeria',
            'AS' => 'American Samoa',
            'AD' => 'Andorra',
            'AO' => 'Angola',
            'AI' => 'Anguilla',
            'AQ' => 'Antarctica',
            'AG' => 'Antigua',
            'AR' => 'Argentina',
            'AM' => 'Armenia',
            'AW' => 'Aruba',
            'AU' => 'Australia',
            'AT' => 'Austria',
            'AZ' => 'Azerbaijan',
            'BS' => 'Bahamas the',
            'BH' => 'Bahrain',
            'BD' => 'Bangladesh',
            'BB' => 'Barbados',
            'BY' => 'Belarus',
            'BE' => 'Belgium',
            'BZ' => 'Belize',
            'BJ' => 'Benin',
            'BM' => 'Bermuda',
            'BT' => 'Bhutan',
            'BO' => 'Bolivia',
            'BA' => 'Bosnia Herzegovina',
            'BW' => 'Botswana',
            'BV' => 'Bouvet Island',
            'BR' => 'Brazil',
            'IO' => 'British Indian Ocean Territory ',
            'VG' => 'British Virgin Islands',
            'BN' => 'Brunei Darussalam',
            'BG' => 'Bulgaria',
            'BF' => 'Burkina Faso',
            'BI' => 'Burundi',
            'KH' => 'Cambodia',
            'CM' => 'Cameroon',
            'CA' => 'Canada',
            'CV' => 'Cape Verde',
            'KY' => 'Cayman Islands',
            'CF' => 'Central African Republic',
            'TD' => 'Chad',
            'CL' => 'Chile',
            'CN' => 'China',
            'CX' => 'Christmas Island',
            'CC' => 'Cocos Islands',
            'CO' => 'Colombia',
            'KM' => 'Comoros the',
            'CD' => 'Congo',
            'CG' => 'Congo the',
            'CK' => 'Cook Islands',
            'CR' => 'Costa Rica',
            'CI' => 'Cote d Ivoire',
            'HR' => 'Croatia',
            'CU' => 'Cuba',
            'CY' => 'Cyprus',
            'CZ' => 'Czech Republic',
            'DK' => 'Denmark',
            'DJ' => 'Djibouti',
            'DM' => 'Dominica',
            'DO' => 'Dominican Republic',
            'EC' => 'Ecuador',
            'EG' => 'Egypt',
            'SV' => 'El Salvador',
            'GQ' => 'Equatorial Guinea',
            'ER' => 'Eritrea',
            'EE' => 'Estonia',
            'ET' => 'Ethiopia',
            'FO' => 'Faroe Islands',
            'FK' => 'Falkland Islands ',
            'FJ' => 'Fiji the Fiji Islands',
            'FI' => 'Finland',
            'FR' => 'France',
            'GF' => 'French Guiana',
            'PF' => 'French Polynesia',
            'TF' => 'French Southern Territories',
            'GA' => 'Gabon',
            'GM' => 'Gambia the',
            'GE' => 'Georgia',
            'DE' => 'Germany',
            'GH' => 'Ghana',
            'GI' => 'Gibraltar',
            'GR' => 'Greece',
            'GL' => 'Greenland',
            'GD' => 'Grenada',
            'GP' => 'Guadeloupe',
            'GU' => 'Guam',
            'GT' => 'Guatemala',
            'GG' => 'Guernsey',
            'GN' => 'Guinea',
            'GW' => 'Guinea Bissau',
            'GY' => 'Guyana',
            'HT' => 'Haiti',
            'HM' => 'Heard Island',
            'VA' => 'Holy See ',
            'HN' => 'Honduras',
            'HK' => 'Hong Kong',
            'HU' => 'Hungary',
            'IS' => 'Iceland',
            'IN' => 'India',
            'ID' => 'Indonesia',
            'IR' => 'Iran',
            'IQ' => 'Iraq',
            'IE' => 'Ireland',
            'IM' => 'Isle of Man',
            'IT' => 'Italy',
            'JM' => 'Jamaica',
            'JP' => 'Japan',
            'JE' => 'Jersey',
            'JO' => 'Jordan',
            'KZ' => 'Kazakhstan',
            'KE' => 'Kenya',
            'KI' => 'Kiribati',
            'KP' => 'Korea',
            'KR' => 'Korea',
            'KW' => 'Kuwait',
            'KG' => 'Kyrgyz Republic',
            'LA' => 'Lao',
            'LV' => 'Latvia',
            'LB' => 'Lebanon',
            'LS' => 'Lesotho',
            'LR' => 'Liberia',
            'LY' => 'Libyan Arab Jamahiriya',
            'LI' => 'Liechtenstein',
            'LT' => 'Lithuania',
            'LU' => 'Luxembourg',
            'MO' => 'Macao',
            'MK' => 'Macedonia',
            'MG' => 'Madagascar',
            'MW' => 'Malawi',
            'MY' => 'Malaysia',
            'MV' => 'Maldives',
            'ML' => 'Mali',
            'MT' => 'Malta',
            'MH' => 'Marshall Islands',
            'MQ' => 'Martinique',
            'MR' => 'Mauritania',
            'MU' => 'Mauritius',
            'YT' => 'Mayotte',
            'MX' => 'Mexico',
            'FM' => 'Micronesia',
            'MD' => 'Moldova',
            'MC' => 'Monaco',
            'MN' => 'Mongolia',
            'ME' => 'Montenegro',
            'MS' => 'Montserrat',
            'MA' => 'Morocco',
            'MZ' => 'Mozambique',
            'MM' => 'Myanmar',
            'NA' => 'Namibia',
            'NR' => 'Nauru',
            'NP' => 'Nepal',
            'AN' => 'Netherlands Antilles',
            'NL' => 'Netherlands the',
            'NC' => 'New Caledonia',
            'NZ' => 'New Zealand',
            'NI' => 'Nicaragua',
            'NE' => 'Niger',
            'NG' => 'Nigeria',
            'NU' => 'Niue',
            'NF' => 'Norfolk Island',
            'MP' => 'Northern Mariana Islands',
            'NO' => 'Norway',
            'OM' => 'Oman',
            'PK' => 'Pakistan',
            'PW' => 'Palau',
            'PS' => 'Palestinian Territory',
            'PA' => 'Panama',
            'PG' => 'Papua New Guinea',
            'PY' => 'Paraguay',
            'PE' => 'Peru',
            'PH' => 'Philippines',
            'PN' => 'Pitcairn Islands',
            'PL' => 'Poland',
            'PT' => 'Portugal',
            'PR' => 'Puerto Rico',
            'QA' => 'Qatar',
            'RE' => 'Reunion',
            'RO' => 'Romania',
            'RU' => 'Russian Federation',
            'RW' => 'Rwanda',
            'BL' => 'Saint Barthelemy',
            'SH' => 'Saint Helena',
            'KN' => 'Saint Kitts',
            'LC' => 'Saint Lucia',
            'MF' => 'Saint Martin',
            'PM' => 'Saint Pierre',
            'VC' => 'Saint Vincent',
            'WS' => 'Samoa',
            'SM' => 'San Marino',
            'ST' => 'Sao Tome',
            'SA' => 'Saudi Arabia',
            'SN' => 'Senegal',
            'RS' => 'Serbia',
            'SC' => 'Seychelles',
            'SL' => 'Sierra Leone',
            'SG' => 'Singapore',
            'SK' => 'Slovakia',
            'SI' => 'Slovenia',
            'SB' => 'Solomon Islands',
            'SO' => 'Somalia',
            'ZA' => 'South Africa',
            'GS' => 'South Georgia',
            'ES' => 'Spain',
            'LK' => 'Sri Lanka',
            'SD' => 'Sudan',
            'SR' => 'Suriname',
            'SJ' => 'Svalbard ',
            'SZ' => 'Swaziland',
            'SE' => 'Sweden',
            'CH' => 'Switzerland, Swiss Confederation',
            'SY' => 'Syrian Arab Republic',
            'TW' => 'Taiwan',
            'TJ' => 'Tajikistan',
            'TZ' => 'Tanzania',
            'TH' => 'Thailand',
            'TL' => 'TimorLeste',
            'TG' => 'Togo',
            'TK' => 'Tokelau',
            'TO' => 'Tonga',
            'TT' => 'Trinidad Tobago',
            'TN' => 'Tunisia',
            'TR' => 'Turkey',
            'TM' => 'Turkmenistan',
            'TC' => 'Turks',
            'TV' => 'Tuvalu',
            'UG' => 'Uganda',
            'UA' => 'Ukraine',
            'AE' => 'United Arab Emirates',
            'GB' => 'United Kingdom',
            'US' => 'United States of America',
            'UM' => 'United States Minor Outlying Islands',
            'VI' => 'United States Virgin Islands',
            'UY' => 'Uruguay',
            'UZ' => 'Uzbekistan',
            'VU' => 'Vanuatu',
            'VE' => 'Venezuela',
            'VN' => 'Vietnam',
            'WF' => 'Wallis Futuna',
            'EH' => 'Western Sahara',
            'YE' => 'Yemen',
            'ZM' => 'Zambia',
            'ZW' => 'Zimbabwe'
        );
        
        $codeList = array(
            'AF','AX','AL','DZ','AS','AD','AO','AI','AQ','AG','AR',
            'AM','AW','AU','AT','AZ','BS','BH','BD','BB','BY','BE',
            'BZ','BJ','BM','BT','BO','BA','BW','BV','BR','IO','VG',
            'BN','BG','BF','BI','KH','CM','CA','CV','KY','CF','TD',
            'CL','CN','CX','CC','CO','KM','CD','CG','CK','CR','CI',
            'HR','CU','CY','CZ','DK','DJ','DM','DO','EC','EG','SV',
            'GQ','ER','EE','ET','FO','FK','FJ','FI','FR','GF','PF',
            'TF','GA','GM','GE','DE','GH','GI','GR','GL','GD','GP','GU','GT',
            'GG','GN','GW','GY','HT','HM','VA','HN','HK','HU',
            'IS','IN','ID','IR','IQ','IE','IM','IT','JM','JP','JE',
            'JO','KZ','KE',
            'KI','KP','KR','KW','KG','LA','LV','LB','LS','LR',
            'LY','LI','LT','LU','MO','MK','MG','MW','MY','MV',
            'ML','MT','MH','MQ','MR','MU','YT','MX','FM',
            'MD','MC','MN','ME','MS','MA','MZ','MM','NA','NR','NP',
            'AN','NL','NC','NZ','NI','NE','NG','NU','NF','MP',
            'NO','OM','PK','PW','PS','PA','PG','PY','PE','PH','PN',
            'PL','PT','PR','QA','RE',
            'RO','RU','RW','BL','SH','KN','LC','MF','PM','VC','WS','SM',
            'ST','SA','SN','RS','SC','SL','SG','SK','SI',
            'SB','SO','ZA','GS','ES','LK','SD','SR','SJ','SZ','SE','CH',
            'SY','TW','TJ','TZ','TH','TL','TG','TK',
            'TO','TT','TN','TR','TM','TC','TV','UG','UA','AE',
            'GB','US','UM','VI','UY','UZ','VU','VE','VN','WF','EH','YE','ZM','ZW'
        );

        $insert = "INSERT INTO rates (`country`,`code`,`Pub_file`) VALUES  ";
        $val = "2";
        $c = "ZZ";
        $a = "Worldwide Deal(All Countries)";

        $insert .= "('$a','$c','$val')";
        for($i=0;$i<count($countryList);$i++){
            $code = $codeList[$i];
            $insert .= ",('$countryList[$code]','$code','$val')";
        }
        $db->Query($insert);
    }
}

function ActiveSettings($db){
    $test = $db->Query("SELECT * FROM setting");
    $rows = mysqli_num_rows($test);
    if($rows == 0){
        
        $settingName = array("SiteName","SiteMetaTitle","Keywords","Des","chance","Design","favicon","Captcha","CaptchaSiteKey","CaptchaSecretKey","Facebook","Youtube",
        "Twitter","GooglePlus","Background","VisitPerIpParDay","Email","DurationSkipLink","HTTP_s","ReferralRate","AllowAdBlock","ShowAllFiles",
        "paypal","currency","theme","logo_active","logo");


        $settingValue = array("Upload-Zero","Upload-Zero","earn money, upload, get paid, uploader, upload files, files, Upload-Zero",
        "Upload-Zero helps you share, analyze, and earn from your files, you get paid! So, now you can make money from home, when managing and protecting your files.",
        "80","blue","https://image.flaticon.com/icons/svg/12/12313.svg","yes","6LcTdhkTAAAAAEusMck57-zRMEX0d6_ApRkg4t8","6LcTdhkTAAAAAEusMck57-zRMEX0d6_ApRkg4t8","https://www.facebook.com/",
        "https://www.youtube.com/","https://twitter.com","https://plus.google.com/","https://www.everynation.org/wp-content/uploads/2018/02/Monthly-Website-Header-background.jpg",
        "3","example@domaine.com","15","http://ayelscripts.com","15","No","yes","","$","Default","no","");


        $insert = "INSERT INTO setting (`settingName`,`settingvalue`) VALUES  ";
       
        $insert .= "('ScriptVersion','v2.6.0')";
        for($i=0;$i<count($settingName);$i++){
            $insert .= ",('$settingName[$i]','$settingValue[$i]')";
        }
        $db->Query($insert);
    }
}

function ActivePages($db){
    $test = $db->Query("SELECT * FROM pages");
    $rows = mysqli_num_rows($test);
    if($rows == 0){
        
        
        $content = "<p>
        What is Lorem Ipsum?
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s
        when an unknown printer took a galley of type and scrambled it to make a type specimen book It has survived not only five centuries, but also the leap into 
        electronic typesetting remaining essentially unchanged It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages
        and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
        </p>";


        $insert = "INSERT INTO pages (`title`,`content`) VALUES  ";
        $insert .= "('privacy_policy','$content'),";
        $insert .= "('copyright','$content'),";
        $insert .= "('dmca','$content'),";
        $insert .= "('terms_of_use','$content')";
        
        $db->Query($insert);
    }
}

function AddTestCampaign($db){
    $test = $db->Query("SELECT * FROM campaigns");
    $rows = mysqli_num_rows($test);
    if($rows == 0){
        $banner1_1 = '<a href="#"><img src="http://www.ayelscripts.xyz/page/image/banner1.png"></a>';
        $banner2_1 = '<a href="#"><img src="http://www.ayelscripts.xyz/page/image/banner2.png"></a>';
        $banner3_1 = '<a href="#"><img src="http://www.ayelscripts.xyz/page/image/banner3.jpg"></a>';
        
        $insert = "INSERT INTO campaigns (`adsName`,`adsType`,`Url`,`Banner`,`HtmlText`) VALUES  ";
        $insert .= "('ads_01','Member Area ad','--','html code','$banner2_1'),";
        $insert .= "('ads_02','Member Area ad','--','html code','$banner1_1'),";
        $insert .= "('ads_03','Visitor','--','html code','$banner1_1'),";
        $insert .= "('ads_04','Visitor','--','html code','$banner2_1'),";
        $insert .= "('ads_05','Visitor','--','html code','$banner3_1')";
        
        $db->Query($insert);
    }
}

function ActiveFisrtInsert($db){
    $test = $db->Query("SELECT * FROM items where id='1'");
    $rows = mysqli_num_rows($test);
    if($rows == 0){
        //var
        $start_server = date("d-m");
        $dt = date("Y-m-d");

        $q  = "INSERT INTO items (title,item1) VALUES ('script','2.6.0');";
        $q .= "INSERT INTO items (title,item1) VALUES ('time_server','$start_server');";
        $q .= "INSERT INTO reportsnonview (date,download,earnings_download,cpm,total) VALUES ('$dt','0','0','0','0');"; 
        
        mysqli_multi_query($db->con,$q);

        $col = array("title","subject","message","date","icon","color");
        $msg='Thank you for purchasing Upload-Zero <br> Make sure you purchased Script from <span style="text-decoration: underline">Codester</span> <br> If you buy it from another place, contact us <a href="mailto:elkasmi.dev@gmail.com">AyelScripts</a><br>Please rate 5 Start <a href="https://www.codester.com/ayelscripts" target="_blank" >here</a>';
        $val = array("Thank you for purchasing Upload-Zero","Thank you for purchasing Upload-Zero",$msg,date("d-m-Y H:i:s"),"fa-thumbs-up","success");
        $db->Insert("admin_notification",$col,$val);
    }
}

function ActiveMemberShip($db){
    $req = $db->Query("SELECT * FROM membership_plan");
    $rows = mysqli_num_rows($req);
    if($rows == 0){
        
        $insert = "INSERT INTO membership_plan (`month`,`year`,`max_size`,`cpm`,`delete_files`,`remove_ads`,`download_delay`,`captcha`) VALUES  ";
        $insert .= "('0','0','20','1','15','No','No','No'),";
        $insert .= "('2.99','29.99','100','2','120','Yes','No','No'),";
        $insert .= "('9.99','99.99','100','3','0','Yes','Yes','Yes')";

        $db->Query($insert);
    }
}

function UpdateScript($db,$newVersion){
    $test = $db->Query("SELECT * FROM setting where id='1' and settingvalue='$newVersion'");
    $rows = mysqli_num_rows($test);
    if($rows == 0){
        //update ScriptVersion to new version
        if($newVersion == "1.2.0"){
            $q .= "ALTER TABLE users ADD upgrade INT NOT NULL AFTER total_payment;";
            $q .= "ALTER TABLE users ADD upgrade_start VARCHAR(255) NOT NULL AFTER upgrade, ADD upgrade_finish VARCHAR(255) NOT NULL AFTER upgrade_start;";
            $q .= "ALTER TABLE files ADD plan INT NOT NULL AFTER `earnings_total`;"; 
            $q .= "INSERT INTO setting (settingName, settingvalue, status) VALUES ('paypal', 'example@domaine.com', 'on'), ('month_plus', '2.99', 'on'), ('year_plus', '29.99', 'on'), ('month_pro', '9.99', 'on'), ('year_pro', '99.99', 'on');";

            mysqli_multi_query($db->con,$q);
        }

        if($newVersion == "1.3.0"){
            $q  = "UPDATE setting SET settingvalue = '$newVersion' WHERE id = '1';";
            $q .= "UPDATE items SET item1 = '$newVersion' WHERE id = '1';";
            $q .= "RENAME TABLE reportsDay TO reportsday, reportsNonView TO reportsnonview ;"; 
            $q .= "INSERT INTO setting (settingName, settingvalue) VALUES ('currency','$') ;";

            mysqli_multi_query($db->con,$q);
        }

        if($newVersion == "2.0.0"){
            $q  = "UPDATE setting SET settingvalue = '$newVersion' WHERE id = '1';";
            $q .= "UPDATE items SET item1 = '$newVersion' WHERE id = '1';";
            $q .= "INSERT INTO setting (settingName, settingvalue) VALUES ('theme', 'Default'), ('logo_active', 'no'), ('logo', '');";

            mysqli_multi_query($db->con,$q);
        }

        if($newVersion == "2.1.0"){
            $q  = "UPDATE setting SET settingvalue = '$newVersion' WHERE id = '1';";
            $q .= "UPDATE items SET item1 = '$newVersion' WHERE id = '1';";

            mysqli_multi_query($db->con,$q);
        }

        if($newVersion == "2.6.0"){
            $q  = "UPDATE setting SET settingvalue = '$newVersion' WHERE id = '1';";
            $q .= "UPDATE items SET item1 = '$newVersion' WHERE id = '1';";
            $q .= "INSERT INTO `pages` (`id`, `title`, `content`) VALUES (NULL, 'copyright', '<p>\r\n        What is Lorem Ipsum?\r\n        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s\r\n        when an unknown printer took a galley of type and scrambled it to make a type specimen book It has survived not only five centuries, but also the leap into \r\n        electronic typesetting remaining essentially unchanged It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages\r\n        and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\r\n        </p>'), (NULL, 'dmca', '<p>\r\n        What is Lorem Ipsum?\r\n        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s\r\n        when an unknown printer took a galley of type and scrambled it to make a type specimen book It has survived not only five centuries, but also the leap into \r\n        electronic typesetting remaining essentially unchanged It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages\r\n        and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\r\n        </p>');";


            mysqli_multi_query($db->con,$q);
        }

    }else{
        // No Update
        
    }
}
?>