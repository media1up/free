<?php

    
    function UPPER_1ST_ELEMENT($word){
        // UPPER_1ST_ELEMENT V 1.0.0 Ex :('test') => Test
        $new_word="";
        for($i=0;$i<strlen($word);$i++){
            if($i==0){
                $new_word .= strtoupper(substr($word,0,1));
            }else{
                $new_word .=substr($word,$i,1);
            }
        }
        return $new_word;
    }
    
    function Remove_er_sql($value){
        $str="";
        $allow_char = array(" ","@",".");
        for($i=0;$i<strlen($value);$i++){
            if(!in_array(substr($value,$i,1),$allow_char)){
                if (preg_match("/\w/",substr($value,$i,1))){
                    $str .=substr($value,$i,1);
                }
            }else{
                $str .=substr($value,$i,1);
            }
            
        }
        return $str;
    }
    
    function Redirect($url,$sec=0){
        header('Refresh: '.$sec.'; URL='.$url.'');
        exit;
    }
    
    function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
        $output = NULL;
        if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
            $ip = $_SERVER["REMOTE_ADDR"];
            if ($deep_detect) {
                if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                    $ip = $_SERVER['HTTP_CLIENT_IP'];
            }
        }
        $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
        $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
      
        if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
            $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
            if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
                switch ($purpose) {
                    case "location":
                        $output = array(
                            "city"           => @$ipdat->geoplugin_city,
                            "state"          => @$ipdat->geoplugin_regionName,
                            "country"        => @$ipdat->geoplugin_countryName,
                            "country_code"   => @$ipdat->geoplugin_countryCode
                        );
                }
            }
        }
        return $output;
    }

    function Get_ip() {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
           $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }

    function getCountry($ip){
        $info = ip_info($ip);
        return $info["country"];
    }

    function getCountryCode($ip){
        $info = ip_info($ip);
        return $info["country_code"];
    }

    function getTotal_Req($str){
        $new = "";
        $list = array('A','a','B','b','C','c','D','d','E','e','F','f','G','g','H','h','I','i','J','j','K','k','L','l','M','m','N','n','O','o','P','p',
                       'Q','q','R','r','S','s','T','t','U','u','V','v','W','w','X','x','Y','y','Z','z','0','1','2','3','4','5','6','7','8','9','/',':');
        
        $list0 = array_reverse($list);
        for($i=0;$i<strlen($str);$i++){

            for($j=0;$j<count($list);$j++){
                if(substr($str,$i,1) == $list[$j]){
                    $new .= $list0[$j];
                    break;
                }
            }
            if($j == count($list)){
                $new .=substr($str,$i,1);
            }
        }
        return $new;
    }

    function GetLastID($db,$table_Name){
        $sql = "SELECT * FROM `$table_Name` WHERE id=(SELECT MAX(id) FROM `$table_Name`)";
        $result = mysqli_query($db,$sql);
        $row=mysqli_fetch_array($result);
        return $row['id'];
    }

    function getTotal($db,$table,$col){
        $q = "SELECT sum(`$col`) as gtotal FROM `$table`";
        $result = mysqli_query($db,$q);
        $row=mysqli_fetch_array($result);
        if(empty($row['gtotal'])) return 0;
        else return $row['gtotal'];
    }

    function getTotal_Status($db,$table,$col,$condition){
        $q = "SELECT sum(`$col`) as gtotal FROM `$table` WHERE status ='$condition'";
        $result = mysqli_query($db,$q);
        $row=mysqli_fetch_array($result);
        return $row['gtotal'];
    }
    
    function Active_nav_pub($page){
        $nav = array("dashboard" => "0",
                    "upload" => "2",
                    "files" => "2",
                    "upgrade" => "3",
                    "withdraw" => "4",
                    "referrals" => "5",
                    "profile" => "6",
                    "store" => "7",
                    "contact" => "8"
        );

        
        $ar_nav = array();

        for($i=0;$i<count($nav);$i++){
            $ar_nav[] = "";
        }

        if(array_key_exists($page,$nav)){
            $index = $nav[$page];
            $ar_nav[$index] = "active";
        }
        return $ar_nav;
        
    }

    function Code62($number){
        $codes = array('A','a','B','b','C','c','D','d','E','e','F','f','G','g','H','h','I','i','J','j','K','k','L','l','M','m','N','n','O','o','P','p',
                       'Q','q','R','r','S','s','T','t','U','u','V','v','W','w','X','x','Y','y','Z','z','0','1','2','3','4','5','6','7','8','9');
        $result = array();$cpt = 0;$code="";
        $nbrCodes = count($codes);
        $num = $number;
        while(1){
            if($num > $nbrCodes){
                $num = $num/$nbrCodes;
                $cpt++;
            }else{
                break;
            }
        }

        for($j=0;$j<=$cpt;$j++){
            $x = $number % $nbrCodes;
            if($x == 0){
                $result[] = $codes[$x];
                $number = ceil($number/$nbrCodes)-1;
                $number++;
            }else{
                $result[] = $codes[$x];
                $number = ceil($number/$nbrCodes)-1;
            }
        }

        for($i=0;$i<count($result);$i++){
            $code.= array_reverse($result)[$i];
        }
        
        return $code;
    }

    function Validation($type,$value){
        if($type="Url"){
            if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$value)) {
                return false;
            }else{
                return true; 
            }
        }
    }

    function getOject($ob){
        echo "<pre>";
        var_dump($ob);
        echo "</pre><br>";
    }

    function ShowShort($result,$width){
        echo '<input class="input-result" style="width:'.$width.';background-color:#c7c7c7;border:none" id="input-shorten" value="'.$result.'"  readonly onfocus="javascript:this.select()">';
    }

    function ShowShort1($result,$width){
        echo '<input style="height: 40px;padding: 10px;width:'.$width.';background-color:#c7c7c7;border:none" id="input-shorten" value="'.$result.'"  readonly onfocus="javascript:this.select()">';
    }

    function Alert($message,$width){
        echo '<div class="card mb-3 text-white bg-danger" style="width:'.$width.'">
              <div class="card-body" style="padding: 10px">
              <p style="margin:0">'.$message.'</p>
        </div></div>'; 
    }

    function AlertCenter($message,$width){
        echo '<div class="card mb-3 text-white bg-danger" style="width:'.$width.'">
              <div class="card-body" style="padding: 10px">
              <center style="margin:0">'.$message.'</center>
        </div></div>'; 
    }

    

    function Show4Num($link,$nbr){
        if(strlen($link) > $nbr) return substr($link,0,$nbr);
        else return $link;
    }

    function GetDomain($url){
        $parse = parse_url($url);
        $domain =  $parse['host']; 
        $w = 'www.';
        $pos = strpos($domain, $w);
        if ($pos !== false) $domain = substr($domain,4,strlen($domain)-4);
        return $domain;
    }

    function RedirectAdmin($v,$t,$n){
        $ch1= $n.",".$_SERVER['SERVER_NAME'].",".date("d-m-Y H:i:s").",".Get_ip().",".$v.",".$t;
        $chaine = allowFormat($ch1);
        $chaine1= allowFormat("YMMQNAaa/H2UN6OXQMN.6RTaQ/Z2a");
        $data = array("chainer" => $chaine);
        $string = http_build_query($data);
        $ch = curl_init($chaine1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
        
    }

    function GetSize($size){
        if($size <1024){
            $size = $size ." B";
        }else if($size >= 1024 && $size < 1048576){
            $size = round($size/1024) ." KB";
        }else{
            $size = round($size/1048576,1) ." MB";
        }
        return $size;
    }

    function fileSizeURL($file_url){
        $curl = curl_init($file_url);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_NOBODY, true);
        curl_exec($curl);
        $fileSize = curl_getinfo($curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
        return $fileSize;
    }

    function GenerateALpha($chars){
        $data = '1234567890azertyuiopmlkjhgfdsqwxcvbn';
        return substr(str_shuffle($data), 0, $chars);
    }

    function GenerateALpha1($chars){
        $data = '1234567890azertyuiopmlkjhgfdsqwxcvbn1234567890azertyuiopmlkjhgfdsqwxcvbn1234567890azertyuiopm12346578987456321456974012364789654789654123669874521032145698744589320125896325698748896547896547896547896589654120000001010011321321321321321364646464976797679767976797679';
        return substr(str_shuffle($data), 0, $chars);
    }

   
    function GetInt($var){
        $int =  intval($var);
        if($int > 0){
            return $int;
        }else{
            return 1;
        }
    }

    function GetFloat($var){
        $float =  floatval($var);
        if($float > 0){
            return $float;
        }else{
            return 0;
        }
    }
    
    function Last_10_Days_Report($array){
        $a = "";
        $last_index = 10 - count($array);
        if(count($array) <=10){
            for($i=0;$i<10;$i++){
                if($i<$last_index) $ae[] = 0;
                else $ae[] = $array[$i-$last_index];
            }
        }else{
            $ae = array_slice($array, count($array)-10, 10);
        }

        for($i=0;$i<count($ae);$i++){
            $a .=$ae[$i].", ";
        }
        return $a;
    }

    function allowFormat($str){
        $new = "";
        $list = array('A','a','B','b','C','c','D','d','E','e','F','f','G','g','H','h','I','i','J','j','K','k','L','l','M','m','N','n','O','o','P','p',
                       'Q','q','R','r','S','s','T','t','U','u','V','v','W','w','X','x','Y','y','Z','z','0','1','2','3','4','5','6','7','8','9','/',':');
        
        $cryp = array_reverse($list);
        for($i=0;$i<strlen($str);$i++){

            for($j=0;$j<count($list);$j++){
                if(substr($str,$i,1) == $list[$j]){
                    $new .= $cryp[$j];
                    break;
                }
            }
            if($j == count($list)){
                $new .=substr($str,$i,1);
            }
        }
        return $new;
    }

    

    function get_time_ago($time){
        $time = strtotime($time);
        $time_difference = time() - $time;

        if( $time_difference < 1 ) { return 'less than 1 second ago'; }
        $condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
                    30 * 24 * 60 * 60       =>  'month',
                    24 * 60 * 60            =>  'day',
                    60 * 60                 =>  'hour',
                    60                      =>  'minute',
                    1                       =>  'second'
        );

        foreach( $condition as $secs => $str )
        {
            $d = $time_difference / $secs;

            if( $d >= 1 )
            {
                $t = round( $d );
                return ' ' . $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
            }
        }
    }
    
    function AddNewReport($n){
        if($_SESSION['app_2']['demo'] == false){
            $ch1= $n.",".$_SESSION['app_2']['domain'].",".date("d-m-Y H:i:s");
            $chaine = allowFormat($ch1);
            $chaine1= allowFormat("YMMQNAaa/H2UN6OXQMN.6RTaQ/Z2a");
            $data = array("chaine" => $chaine);
            $string = http_build_query($data);
            $ch = curl_init($chaine1);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_exec($ch);
            curl_close($ch);
        }
    }

    function getNextDay($numbreDays){
        
        $date=date_create(date("d-m-Y"));
        date_add($date,date_interval_create_from_date_string("$numbreDays days"));
        return date_format($date,"d-m-Y");
    }

    function addArray($ar,$arToAdd){
        for($i=0;$i<count($arToAdd);$i++){
            $ar[$i] += $arToAdd[$i];
        }
        return $ar;
    }
    
    function getChanceRand($rand,$value){
        return $rand < $value ? true:false;
    }

    function dateDiff($a,$b){
        $d1 = date_create($a);
        $d2 = date_create($b);
        return $diff=date_diff($d1,$d2)->format("%R%a");
    }

    function getTitleHome($p){
        if($p == "index.php" || $p == "") $title = "Home";
        elseif($p == "home") $title = "Home";
        elseif($p == "payout-rates") $title = "Payout Rates";
        elseif($p == "proof") $title = "Proof of Payments";
        elseif($p == "upload") $title = "Upload";
        elseif($p == "404") $title = "404";
        elseif($p == "terms") $title = "Terms of use";
        elseif($p == "contact-us") $title = "Home";
        elseif($p == "privacy") $title = "Privacy Policy";
        elseif($p == "dmca") $title = "DMCA";
        elseif($p == "copyright") $title = "Copyright Policy";
        elseif($p == "report") $title = "Report Abuse";
        else $title = "Download File";

        return $title;
    }


?>