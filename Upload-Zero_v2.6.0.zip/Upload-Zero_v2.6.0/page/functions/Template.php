<?php
    // Items  Links
    function GetLink(){
        //$data = json_encode($data);
        return '<button class="btn btn-info btn-ml" id="btn-wait" disabled>Please Wait</button>
                <form method="post">
                <button class="btn btn-primary btn-ml" id="btn-get-link" type="submit" name="getlink">Get Link</button>
                </form>';
    }

    function CountDown($sec){
        $timer ="<div class='circle'>";
        $timer .= '<span id="countdown">'.$sec.'</span><br><span style="color:#A5A5A5">Seconds</span></div>';
        return $timer;
    }

    function reCaptcha(){
        $captcha = '<form method="POST">';
        if($_SESSION["Captcha"] == "yes"){
            $captcha .= '
                
                <div class="g-recaptcha" data-sitekey="'.$_SESSION["CaptchaSiteKey"].'"></div>
                <br/>

            ';
        }
        $captcha .= "<br/>";
        $captcha .= '<input class="btn btn-primary btn-bl" type="submit" name="submit" value="Click here to continue">';
        $captcha .= "</form><br/>";
        return $captcha;
    }

    //Items Files
    function btnFreeDownload(){
        return '<form method="post" class="inline">
                <input class="btn btn-primary btn-bl" type="submit" name="btn-free" value="Free Download">
        </form>';
        //return '<input class="btn btn-primary btn-ml" type="submit" name="submit" value="Free Download">';
    }
    
    function btnPremiumDownload($offre){
        return '<a class="btn btn-info btn-bl" href="'.$offre.'">Premium Download</a>';
    }
    
    function CountDown30s(){
        GLOBAL $timeleft;
        $timer ="<div class='circle'>";
        $timer .= '<span id="countdown">'.$timeleft.'</span><br><span style="color:#A5A5A5">Seconds</span></div>';
        return $timer;
    }
    
    function reCaptchaDownload(){
        GLOBAL $settings;
        GLOBAL $data;
        $captcha = '<form method="POST">';
        if(applyCaptcha($settings["Captcha"],$settings['plans'][$data[7]]["captcha"])){
            $captcha .= '
                <div class="g-recaptcha" data-sitekey="'.$settings["CaptchaSiteKey"].'"></div>
            ';
        }
        $captcha .= "<br/>";
        $captcha .= '<button class="btn btn-info btn-ml" id="btn-wait" disabled>Please Wait</button>';
        $captcha .= '<input class="btn btn-primary btn-bl" id="btn-get-link" type="submit" name="submit" value="Click here to continue" >';
        $captcha .= "</form>";
        return $captcha;
    }
    
    // Template Files
    function Template_File_1($arrayAds,$arrayInfo,$page,$offre){
        // $arrayInfo = [alias, name, size, downloaded, uploadedBY, plan]
        // Max Ads : 3
        GLOBAL $settings;
        if($page == 0){
            echo '
                <div class="box-content">
                    <br>
                    <center>'.$arrayAds[0].' </center>
                </div>
                
                <center><h6>Download File '.$arrayInfo[1].'</h6></center>
                <span class="font"><center><p>Requested File <span style="color:tomato">: '.$settings["HTTP_s"].'/'.$arrayInfo[0].'</span> ('.$arrayInfo[2].') </p></center></span>
                <center><a href="report?file='.$arrayInfo[0].'" style="text-decoration:none;color:tomato" target="_blank">Report Abuse</a></center>
                
                <div class="box-content">
                    <center>
                        <div class="inline">
                            '.$arrayAds[1].'
                        </div>

                            
                    </center>
                </div>
                <div class="box-content">
                    <center>
                       
                            '.btnFreeDownload().'
                    </center>
                </div>

                
                
            ';
        }
        if($page == 1){
            echo '
                <br>
                <center><div class="font">
                        Download File <br>
                        <span style="color:tomato">'.$arrayInfo[1].' </span> ('.$arrayInfo[2].')
                </div></center>
                <center><a href="report?file='.$arrayInfo[0].'" style="text-decoration:none;color:tomato" target="_blank">Report Abuse</a></center>
                
                <div class="box-content">
                    <center>'.$arrayAds[0].' </center>
                </div>
                
               
                <br>
                <center>
                    <table border="1" style="border-color:#777777">
                        <tr>
                            <td style="width:200px">File Name</td>
                            <td style="width:200px">Size</td>
                            <td style="width:200px">Downloaded</td>
                        </tr>
                         <tr>
                            <td>'.$arrayInfo[1].'</td>
                            <td>'.$arrayInfo[2].'</td>
                            <td>'.$arrayInfo[3].' times</td>
                        </tr>
                       
                        
                    </table>
                </center>

                <br>
                
                <center><h6>Your File is almost ready.</h6>   
                <div class="box-content">
                    <center>'.$arrayAds[1].' </center>
                </div> 
                <br>
                '.CountDown30s().'
                <br>
                '.reCaptchaDownload().'
                <br>
                <div class="box-content">
                    <center>'.$arrayAds[2].' </center>
                </div> 
                
                
                <br><br>
            ';
        }
        if($page == 2){
            echo '
                <br><br>
                <center><h6>File Download Link Generated</h6></center>
                <br>
                <div class="box-content">
                    <center>'.$arrayAds[0].' </center>
                </div>
                <br>
                <div class="box-content">
                    <center>'.$arrayAds[1].' </center>
                </div>
                
                <center>
                    <a class="btn btn-primary btn-bl" href="page/rsc_upload/items.php?file='.$arrayInfo[4].'&name='.$arrayInfo[1].'">Download</a>
                </center>
                <br><br>
            ';
        }
        if($page == 3){
            echo '
            <br><br><br><br>
            <center><h4>Thank you for downloading!</h4></center>
            
            <br><br><br><br>
            ';
        }
    }
?>