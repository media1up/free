<?php


    function Active_nav_admin($page){
        $nav = array("dashboard" => "0",

                    "users" => "1",
                    "adduser" => "1",
                    "referrals" => "1",
                    "block" => "1",

                    "campaigns" => "2",
                    "createads" => "2",

                    "ads" => "3",
                    "files" => "4",
                    "withdraws" => "6",

                    "settings" => "7",
                    "email" => "7",
                    "PagesWithdraw" => "7",

                    "store" => "8",
                    "mailbox" => "9",
                    "reports" => "10",

                    "Privacy" => "11",
                    "Terms" => "11",

                    "plans" => "12",
                    "transactions" => "13"
        );
        
        $ar_nav = array();

        for($i=0;$i<count($nav);$i++){
            $ar_nav[] = "";
        }

        if(array_key_exists($page,$nav)){
            $index = $nav[$page];
            $ar_nav[$index] = "active";
        }
        return $ar_nav;
        
    }

    function time_dif($s,$e){

    }
?>