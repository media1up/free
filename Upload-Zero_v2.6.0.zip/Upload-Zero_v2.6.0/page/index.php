<?php
    include 'functions/gFunction.php';
    Redirect("login.php");
?>