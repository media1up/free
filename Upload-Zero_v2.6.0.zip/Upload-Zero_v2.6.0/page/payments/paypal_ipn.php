<?php
ob_start();
session_start();
include '../classes/database.php';
include '../classes/class.user.php';
$db1 = new database();
$user = new user();

$settings = $_SESSION['app_2'];
$enableSandbox = false;


$email = $settings['paypal'];
//$email = "sb-zesjx243711@business.example.com";
$return_url = $settings['HTTP_s']."/page/member/successful";
$cancel_url = $settings['HTTP_s']."/page/member/cancelled";
$notify_url = $settings['HTTP_s']."/page/payments/paypal_ipn.php";




$paypalUrl = $enableSandbox ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr';
$ipnUrl = $enableSandbox ? 'https://ipnpb.sandbox.paypal.com/cgi-bin/webscr' : 'https://ipnpb.paypal.com/cgi-bin/webscr' ;


if(isset($_POST['plan_plus'])){
    $var_ar = explode('/',$_POST['plan_plus_time']);
    $var = $var_ar[1];
    $itemName = "Plan_Plus-".$var;
    if($var == "Month") $itemAmount = $settings['plans'][1]['month'];
    elseif($var == "Year") $itemAmount = $settings['plans'][1]['year'];
}

if(isset($_POST['plan_pro'])){
    $var_ar = explode('/',$_POST['plan_pro_time']);
    $var = $var_ar[1];
    $itemName = "Plan_Pro-".$var;
    if($var == "Month") $itemAmount = $settings['plans'][2]['month'];
    elseif($var == "Year") $itemAmount = $settings['plans'][2]['year'];
}

// Check if paypal request or response
if (!isset($_POST["txn_id"]) && !isset($_POST["txn_type"])) {
	
	$data = [];
	foreach ($_POST as $key => $value) {
		$data[$key] = stripslashes($value);
	}

	$data['business'] = $email;
	$data['return'] = stripslashes($return_url);
	$data['cancel_return'] = stripslashes($cancel_url);
	$data['notify_url'] = stripslashes($notify_url);
	$data['item_name'] = $itemName;
	$data['amount'] = $itemAmount;
	$data['currency_code'] = $settings['currency_code'];
	$data['custom'] = $settings['username'];

	$queryString = http_build_query($data);

	// Redirect to paypal IPN
	
	header('location:' . $paypalUrl . '?' . $queryString);
	exit();

} else {
	$raw_post_data = file_get_contents('php://input');
    $raw_post_array = explode('&', $raw_post_data);
    $myPost = array();
    foreach ($raw_post_array as $keyval) {
        $keyval = explode ('=', $keyval);
            if (count($keyval) == 2)
            $myPost[$keyval[0]] = urldecode($keyval[1]);
    }
    // read the IPN message sent from PayPal and prepend 'cmd=_notify-validate'
    $req = 'cmd=_notify-validate';
    if (function_exists('get_magic_quotes_gpc')) {
        $get_magic_quotes_exists = true;
    }
    foreach ($myPost as $key => $value) {
        if ($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
            $value = urlencode(stripslashes($value));
        } else {
            $value = urlencode($value);
        }
        $req .= "&$key=$value";
    }

    // Step 2: POST IPN data back to PayPal to validate
    $ch = curl_init($ipnUrl);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));

    if ( !($res = curl_exec($ch)) ) { curl_close($ch);exit;}
    curl_close($ch);

    if (strcmp ($res, "VERIFIED") == 0) {
        
        $custom = $_POST['custom'];
        $payment_amount = $_POST['mc_gross'];
        $payment_date = $_POST['payment_date'];
        $payment_status = $_POST['payment_status'];
        $payer_email = $_POST['payer_email'];
        $txn_id = $_POST['txn_id'];
        $item_name = $_POST['item_name'];

        $user->addPaymentsPaypal($custom,$payment_amount,$payment_date,$payment_status,$payer_email,$txn_id,$item_name);
        $user->GetDataUser($custom);
    }
}

