<?php
    include '../classes/class.upload.php';
    include '../classes/database.php';
    if(isset($_GET['file']) && isset($_GET['name'])){
        $file = new Upload();
        $file->downloadFile($_GET['file'],$_GET['name']);
        $_SESSION['fisrt_ads'] = true;
        $_SESSION['cpt_files'] = 0;

    }
?>